ZGV.Quest_Cache_Accept_Alliance = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13087"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813,12838,12815"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\The Skybreaker Dailies"] = {
		{ids="13336,13333"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11573"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12582,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12689,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886"},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="3765"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4324,3702,3701,4128,4126"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,5526,7488,7441"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="7482"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2923,2928,2925,2924,2922,2927,2930,2929,2926"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527"},
	},
	["DUNGEONS\\Classic\\Maraudon Quests"] = {
		{ids="7070,7041"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="3636"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1221,1100,1101"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="6141,261,1052,1053"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="6141,261,1052,1053,1050"},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="5091,4726"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5214,5251,5281,5282,5542,5543,5544,5742,5781"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="1448,1449,1450"},
	},
	["DUNGEONS\\Classic\\The Deadmines Quests"] = {
		{ids="167,168,2040,65,132,135,141,142,155,166"},
	},
	["DUNGEONS\\Classic\\The Stockade Quests"] = {
		{ids="303,378,386,377,388,373,389,391,387"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4766,4764,4726"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="865,1491,959"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2988"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="10227,10228,10231,10251,10252,10253,10164,9928,9927"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10683"},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9607,9589"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10754,10762,10763,10764"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9575"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="12513,10279,10277,10282,10283,10284,10285"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="10901"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10687"},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="9492"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10265,10262,10205,10266,10267,10268,10269,10275"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10257"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10680,10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10621,10626,10662,10664"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10621,10626,10662,10664,10666,10667,9763,9764,10885"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12210,11984"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="13111,13098"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11900,11910,11941,11943,11905,11911,13094,11946,11951,11957"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11252,13205"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12020"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="12022,11318,11122,12193"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="1468,1479,1558,1687,4822,558,171"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Chronos Turn-Ins (Elwynn Forest)"] = {
		{ids="7881"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Kerri Hicks Turn-Ins (Elwynn Forest)"] = {
		{ids="7889"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Rinling Turn-Ins (Elwynn Forest)"] = {
		{ids="7894"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Spawn of Jubjub (Elwynn Forest)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Yebb Neblegear Turn-Ins (Elwynn Forest)"] = {
		{ids="7899"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Chronos Turn-Ins (Mulgore)"] = {
		{ids="7881"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Kerri Hicks Turn-Ins (Mulgore)"] = {
		{ids="7889"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Rinling Turn-Ins (Mulgore)"] = {
		{ids="7894"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Spawn of Jubjub (Mulgore)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Yebb Neblegear Turn-Ins (Mulgore)"] = {
		{ids="7899"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="7062,7063,7022,7025"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="8373,1658"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11356,11360,12133"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="11356,11131,12135"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="8311"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8149"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8903"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8870,8867,8883,8864,8865,8863,8862"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Bonfires"] = {
		{ids="11816,11832,11801,11808,11781,11814,11583,11822,11810,11768,11766,11820,11813,11828,11804,11764,11819,11776,11827,11826,11784,11580,9326,11786,11774,11772,11935,11811,11824,11806,11809,11834,11803,11805,11765,11783,11770,9324,11780,11812,11769,11817,11773,11831,11800,11833,11802,11785,11815,11771,11777,9325"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11964,11886,11731,11657,11816,11882,11891,12012,11955,11696,11691,11972"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Chest Quest"] = {
		{ids="8562", cond=[[Warrior]]},
		{ids="8627", cond=[[Paladin]]},
		{ids="8622", cond=[[Shaman]]},
		{ids="8638", cond=[[Rogue]]},
		{ids="8633", cond=[[Mage]]},
		{ids="8666", cond=[[Druid]]},
		{ids="8603", cond=[[Priest]]},
		{ids="8656", cond=[[Hunter]]},
		{ids="8661", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Arathi Highlands (33-33)"] = {
		{ids="681"},
	},
	["LEVELING\\Arathi Highlands (39-41)"] = {
		{ids="691,642"},
	},
	["LEVELING\\Ashenvale (22-24)"] = {
		{ids="970,1010,1020,973"},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64028,64031"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Paladin Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64028,64031,64034,64035,64038"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8507,8508"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8507,8508"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8507,8508"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5923"},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6063"},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1860"},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="2998"},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5635"},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="9449"},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1598"},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1638"},
	},
	["LEVELING\\Darkshore (20-22)"] = {
		{ids="26,6121"},
	},
	["LEVELING\\Duskwood (25-27)"] = {
		{ids="66,101"},
	},
	["LEVELING\\Duskwood (30-31)"] = {
		{ids="1179"},
	},
	["LEVELING\\Dustwallow Marsh (33-33)"] = {
		{ids="11126"},
	},
	["LEVELING\\Dustwallow Marsh (34-34)"] = {
		{ids="1220,1259,1319,1285"},
	},
	["LEVELING\\Dustwallow Marsh (41-42)"] = {
		{ids="1286"},
	},
	["LEVELING\\Dustwallow Marsh (44-45)"] = {
		{ids="11160,11161,11217"},
	},
	["LEVELING\\Extra Zones\\Westfall"] = {
		{ids="64,36,151,9,22,38,153,12,102,13,6181"},
	},
	["LEVELING\\Felwood (52-53)"] = {
		{ids="4101,5155,4421"},
	},
	["LEVELING\\Felwood (55-56)"] = {
		{ids="5165,4442"},
	},
	["LEVELING\\Feralas (46-47)"] = {
		{ids="3022,2821,4124,2866,2939,2982,4125,2867,3130,2869,2870"},
	},
	["LEVELING\\Hillsbrad Foothills (32-33)"] = {
		{ids="564,9435,536,555"},
	},
	["LEVELING\\Redridge Mountains (25-25)"] = {
		{ids="94"},
	},
	["LEVELING\\Redridge Mountains (27-28)"] = {
		{ids="128,19,115,91"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Darnassus)"] = {
		{ids="9262,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Ironforge)"] = {
		{ids="9261,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Stormwind)"] = {
		{ids="9260,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (The Exodar)"] = {
		{ids="12817,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Searing Gorge (50-51)"] = {
		{ids="7723,7724,7727,7701,7728,7729,7722,3441,3442,4451,3443"},
	},
	["LEVELING\\Silithus (59-60)"] = {
		{ids="8280,8277,8284,8318"},
	},
	["LEVELING\\Starter Guides (1-11)\\Draenei Starter (1-11)"] = {
		{ids="9279"},
	},
	["LEVELING\\Starter Guides (1-11)\\Dwarf & Gnome Starter (1-11)"] = {
		{ids="179"},
	},
	["LEVELING\\Starter Guides (1-11)\\Human Starter (1-11)"] = {
		{ids="1598"},
	},
	["LEVELING\\Starter Guides (1-11)\\Night Elf Starter (1-11)"] = {
		{ids="456,4495,458,457"},
	},
	["LEVELING\\Stranglethorn Vale (34-35)"] = {
		{ids="1181"},
	},
	["LEVELING\\Stranglethorn Vale (43-44)"] = {
		{ids="1363,1364"},
	},
	["LEVELING\\Stranglethorn Vale (45-46)"] = {
		{ids="609,580,621,587,604,617"},
	},
	["LEVELING\\Swamp of Sorrows (38-39)"] = {
		{ids="1448,1260"},
	},
	["LEVELING\\Tanaris (44-44)"] = {
		{ids="1118,1190,1188,1194,1707,1690,992,3520"},
	},
	["LEVELING\\Tanaris (47-49)"] = {
		{ids="2605,1691,5863,2741,2944,2781,2875,3362,82,8365,8366,2873"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains (67-68)"] = {
		{ids="9794"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group Quests"] = {
		{ids="10119,10288,10140,10254,10160,10482,10483"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11481"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10210,10211,10551,10552"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10407,10410,10409,10243"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10210,10211,10551,10552"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10037,10211,10551,10552"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10051,10898,10842,10877,10923,10033,10035,10922,10929,10930,9982"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,9817,9817,10116,9894,9895"},
	},
	["LEVELING\\Un'Goro Crater (54-55)"] = {
		{ids="4504,4496,3881,3883,3882,4285,4287,4288"},
	},
	["LEVELING\\Western Plaguelands (52-52)"] = {
		{ids="5092,5215,978,4493"},
	},
	["LEVELING\\Western Plaguelands (56-57)"] = {
		{ids="5216,5217,5021,5022,8275"},
	},
	["LEVELING\\Western Plaguelands (58-59)"] = {
		{ids="5225,6186,5904,5153"},
	},
	["LEVELING\\Wetlands (24-25)"] = {
		{ids="484,279,288,463"},
	},
	["LEVELING\\Wetlands (28-30)"] = {
		{ids="281,289,943"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (71-73)"] = {
		{ids="12000,12166,12171,12006,12004,12167"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11228,11243,11244,11255,11273,11333"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (78-80)"] = {
		{ids="13418,13036,13008,13040,13039,13044,13045,13070,13086"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12521,12489,12524,12624,12522,12688,12525"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-78)"] = {
		{ids="12818,12843,12844,12827,12836,12819,12826,12820,12828,12829,12830"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (74-76)"] = {
		{ids="12859,12902,12861,12883,12884,12894,12903,12901,12912,12904,12914,12630"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12593,12619,12842,12848,12636,12641"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="5283,2758,2759"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5284"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnome Engineer Membership Card Renewal"] = {
		{ids="3647"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3632,3640,3641"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineer Membership Card Renewal"] = {
		{ids="3644"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="4181,3639"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5144"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2847,2848,2849,2850,2851,2852,2853,5143"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10551,10554"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9914,9882,9900,9925"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10210,10211,10552,10553"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10210,9983,9888,9889,9890,9891,9906,9907"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10445,10210,10211,10551,10552,10568"},
	},
}
ZGV.Quest_Cache_Turnin_Alliance = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13087"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12692"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12695"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="3702,4128"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Tribute (58-60)"] = {
		{ids="1193"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2925,2923,2927"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520"},
	},
	["DUNGEONS\\Classic\\Razorfen Kraul Quests"] = {
		{ids="1100"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Armory Quests"] = {
		{ids="6141,261,1052"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Cathedral Quests"] = {
		{ids="6141,261,1052"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="6141,261,1052"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5281,5542,5543,5544,5742"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="1448,1449"},
	},
	["DUNGEONS\\Classic\\The Deadmines Quests"] = {
		{ids="65,132,135,141,142,155"},
	},
	["DUNGEONS\\Classic\\The Stockade Quests"] = {
		{ids="303,373,389"},
	},
	["DUNGEONS\\Classic\\Upper Blackrock Spire Quests"] = {
		{ids="4766"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="865"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="10227,10228,10231,10251,10252,10253,10107"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10754,10762,10763,10764"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="10279,10277,10282,10283,10284,10285,12513"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10265,10262,10205,10266,10267,10268,10269"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10680,10458,10480,10481,10513,10514,10515,10519,10521,10522,10523,10527,10528,10537,10540,10546,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10621,10626,10662"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10621,10626,10662,10664,10666,9763,9764,10885,10667"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12210"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="13111,13098"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11941,11900,11910,11943,11946,11951"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="13205,11252"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12420"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12020"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="12022,11318,11122,12193"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="1468,1479,1558,1687,4822,558,171"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="7062,7063,7022"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
	},
	["EVENTS\\Hallow's End\\Achievements\\Rotten Hallow"] = {
		{ids="8373,1658"},
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11356,11360"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="11356"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8870,8867,8883"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11731,11657,11964,11882,11886,11891,12012,11955,11696,11691,11972"},
	},
	["LEVELING\\Arathi Highlands (33-33)"] = {
		{ids="690"},
	},
	["LEVELING\\Ashenvale (22-24)"] = {
		{ids="967,1010,970"},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64028"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Paladin Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64028,64031,64034,64035"},
	},
	["LEVELING\\Burning Steppes (53-54)"] = {
		{ids="4512"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Dustwallow Marsh (33-33)"] = {
		{ids="11126"},
	},
	["LEVELING\\Dustwallow Marsh (34-34)"] = {
		{ids="1219,1220,1284,1252,1253,1259,1285"},
	},
	["LEVELING\\Extra Zones\\Westfall"] = {
		{ids="36,109,12,153"},
	},
	["LEVELING\\Felwood (55-56)"] = {
		{ids="5159,4441,4442"},
	},
	["LEVELING\\Feralas (46-47)"] = {
		{ids="4124,2866,2867,3130,2869"},
	},
	["LEVELING\\Hillsbrad Foothills (32-33)"] = {
		{ids="538"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Darnassus)"] = {
		{ids="9262,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Ironforge)"] = {
		{ids="9261,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Stormwind)"] = {
		{ids="9260,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (The Exodar)"] = {
		{ids="12817,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Searing Gorge (50-51)"] = {
		{ids="3441,3442"},
	},
	["LEVELING\\Silithus (59-60)"] = {
		{ids="8275"},
	},
	["LEVELING\\Starter Guides (1-11)\\Night Elf Starter (1-11)"] = {
		{ids="456"},
	},
	["LEVELING\\Stranglethorn Vale (34-35)"] = {
		{ids="1180"},
	},
	["LEVELING\\Stranglethorn Vale (43-44)"] = {
		{ids="1363"},
	},
	["LEVELING\\Stranglethorn Vale (45-46)"] = {
		{ids="1118"},
	},
	["LEVELING\\Swamp of Sorrows (46-46)"] = {
		{ids="1477"},
	},
	["LEVELING\\Tanaris (44-44)"] = {
		{ids="2864,1117,1137,1187,1190,1194,1188,992,2872,1690,1707"},
	},
	["LEVELING\\Tanaris (47-49)"] = {
		{ids="2941,3520"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group Quests"] = {
		{ids="10119,10288,10140,10254,10160,10482"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10407,10410,10409"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10051,10898,10842,10877,10923,10033,10035,10922,10929,10930"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,10116,9894,9895"},
	},
	["LEVELING\\Un'Goro Crater (54-55)"] = {
		{ids="4493"},
	},
	["LEVELING\\Western Plaguelands (52-52)"] = {
		{ids="5090,5092,5215,3661,2944,162"},
	},
	["LEVELING\\Western Plaguelands (56-57)"] = {
		{ids="6028,5216,5021,5217,3701"},
	},
	["LEVELING\\Western Plaguelands (58-59)"] = {
		{ids="5223,5537,6185,5903,5152"},
	},
	["LEVELING\\Wetlands (24-25)"] = {
		{ids="942"},
	},
	["LEVELING\\Wetlands (28-30)"] = {
		{ids="270"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (71-73)"] = {
		{ids="12171,12000,12166"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11228,11243,11244"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (78-80)"] = {
		{ids="13036,13039,13040,13008,13044,13045,13070,13086"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12521,12489,12524,12624"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-78)"] = {
		{ids="12818,12819,12826,12827,12836"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (74-76)"] = {
		{ids="12770,12902,12859,12861,12883,12894,12904,12901,12912,12903,12884"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12593,12619,12842,12848,12636"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="2758"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3632,3640,3641"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="4181,3639"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5144"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2847,2848,2849,2850,2851,2852,2853,5143"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="10804,10811,10814,10836,10837,10854,10858,10866"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10210,10211"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10210,9888,9889,9890,9891,9906"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10210,10211"},
	},
}
ZGV.Quest_Cache_Accept_Horde = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13089"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Death's Rise Dailies"] = {
		{ids="12813,12838,12815"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Orgrim's Hammer Dailies"] = {
		{ids="13330"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12582,12692,12702"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12654,12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12573,12574,12575,12576,12577,12578,12580,12579,12581,12689,12695,12704"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062,12886"},
	},
	["DUNGEONS\\Classic\\Blackfathom Deeps Quests"] = {
		{ids="6563,6921"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4324,4133,4134,3906,4081,4061,3441,3442,3443"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527,5526,7489,7441"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Quests"] = {
		{ids="7481"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2841,2842,2843"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520,3527"},
	},
	["DUNGEONS\\Classic\\Ragefire Chasm Quests"] = {
		{ids="5723,5722"},
	},
	["DUNGEONS\\Classic\\Razorfen Downs Quests"] = {
		{ids="6522"},
	},
	["DUNGEONS\\Classic\\Scarlet Monastery Library Quests"] = {
		{ids="1049", cond=[[Orc]]},
	},
	["DUNGEONS\\Classic\\Scholomance Quests"] = {
		{ids="5094,4726"},
	},
	["DUNGEONS\\Classic\\Shadowfang Keep Quests"] = {
		{ids="1013,1014,1098"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5214,5251,5281,5282,5542,5543,5544,5742,5781"},
	},
	["DUNGEONS\\Classic\\Stratholme - Undead Side Quests"] = {
		{ids="5382"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="3380,3444,3446,3520,3527,4787,1424,1429"},
	},
	["DUNGEONS\\Classic\\Uldaman Quests"] = {
		{ids="2342,2418,709,2258"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="886,962,870,877"},
	},
	["DUNGEONS\\Classic\\Zul'Farrak Quests"] = {
		{ids="2933"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,10227,10228,10231,10251,10252,10253,10164,9888,9983,9889,9890,9891,9906,9907,9872"},
	},
	["DUNGEONS\\The Burning Crusade\\Black Temple Attunement"] = {
		{ids="10683"},
	},
	["DUNGEONS\\The Burning Crusade\\Blood Furnace Quests"] = {
		{ids="9608,9590"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10755,10756,10757,10758"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9407,10120,10289,10291,10121,10123,10124,9572"},
	},
	["DUNGEONS\\The Burning Crusade\\Karazhan Attunement"] = {
		{ids="11216"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="12513,10279,10277,10282,10283,10284,10285"},
	},
	["DUNGEONS\\The Burning Crusade\\Serpentshrine Cavern Attunement"] = {
		{ids="10901"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Shadow Labyrinth Quests"] = {
		{ids="10687"},
	},
	["DUNGEONS\\The Burning Crusade\\Shattered Halls Quests"] = {
		{ids="9495"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883,10884"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10265,10262,10205,10266,10267,10268,10269,10275"},
	},
	["DUNGEONS\\The Burning Crusade\\The Botanica Quests"] = {
		{ids="10257"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10681,10458,10480,10481,10513,10514,10515,10519,10521,10527,10546,10522,10523,10528,10537,10540,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10623,10627,10663,10664"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10623,10627,10663,10664,10666,10667,9763,9764,10885,11216"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12208,11984"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="12507,12510,12514,12516,12623,12627,12628,12632,12642,12646,12647,12653,12665,12666,12667,12672,12668,12674,12675,12684,12685"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843,12846"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11900,11910,11941,11943,11905,11911,13095,11946,11951,11957"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11272,13206,11262"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12192"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="11409,11412,12194,12191"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="172,1800,910,911,915,925,5502"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Chronos Turn-Ins (Elwynn Forest)"] = {
		{ids="7881"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Kerri Hicks Turn-Ins (Elwynn Forest)"] = {
		{ids="7889"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Rinling Turn-Ins (Elwynn Forest)"] = {
		{ids="7894"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Spawn of Jubjub (Elwynn Forest)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Elwynn Forest\\Yebb Neblegear Turn-Ins (Elwynn Forest)"] = {
		{ids="7899"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Chronos Turn-Ins (Mulgore)"] = {
		{ids="7881"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Kerri Hicks Turn-Ins (Mulgore)"] = {
		{ids="7889"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Rinling Turn-Ins (Mulgore)"] = {
		{ids="7894"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Spawn of Jubjub (Mulgore)"] = {
		{ids="7946"},
	},
	["EVENTS\\Darkmoon Faire\\Mulgore\\Yebb Neblegear Turn-Ins (Mulgore)"] = {
		{ids="7899"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="6964,7061,6961,6962"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11357,11361,12155"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Daily Quests"] = {
		{ids="11357"},
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="8312,11357,8359"},
	},
	["EVENTS\\Harvest Festival\\Harvest Festival Quest"] = {
		{ids="8150"},
	},
	["EVENTS\\Love is in the Air\\Love is in the Air Quests"] = {
		{ids="8904"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8873,8867,8883,8864,8865,8863,8862"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11915,11846,11922,11923,11966,11886,11891,12012,11955,11696,11691,11972"},
	},
	["EVENTS\\Midsummer Fire Festival\\The Fires of Azeroth\\Midsummer Fire Festival Bonfires"] = {
		{ids="11852,11859,11847,11744,11861,11838,11762,11836,11760,11849,11746,11845,11741,11856,11841,11734,11846,11839,11763,11740,9332,11753,11933,11735,11738,11837,11761,11737,11857,11743,11581,11745,9330,11751,11739,11844,11842,11749,11742,9331,11757,11732,11840,11748,11853,11584,11848,11850,11860,11755,11756,11862"},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Cloak Quest"] = {
		{ids="8557", cond=[[Warrior]]},
		{ids="8695", cond=[[Paladin]]},
		{ids="8690", cond=[[Shaman]]},
		{ids="8693", cond=[[Rogue]]},
		{ids="8691", cond=[[Mage]]},
		{ids="8692", cond=[[Druid]]},
		{ids="8689", cond=[[Priest]]},
		{ids="8696", cond=[[Hunter]]},
		{ids="8694", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Ring Quest"] = {
		{ids="8556", cond=[[Warrior]]},
		{ids="8703", cond=[[Paladin]]},
		{ids="8698", cond=[[Shaman]]},
		{ids="8701", cond=[[Rogue]]},
		{ids="8699", cond=[[Mage]]},
		{ids="8700", cond=[[Druid]]},
		{ids="8697", cond=[[Priest]]},
		{ids="8704", cond=[[Hunter]]},
		{ids="8702", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Ruins of Ahn'Qiraj Weapon Quest"] = {
		{ids="8558", cond=[[Warrior]]},
		{ids="8711", cond=[[Paladin]]},
		{ids="8706", cond=[[Shaman]]},
		{ids="8709", cond=[[Rogue]]},
		{ids="8707", cond=[[Mage]]},
		{ids="8708", cond=[[Druid]]},
		{ids="8705", cond=[[Priest]]},
		{ids="8712", cond=[[Hunter]]},
		{ids="8710", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Boots Quest"] = {
		{ids="8559", cond=[[Warrior]]},
		{ids="8655", cond=[[Paladin]]},
		{ids="8621", cond=[[Shaman]]},
		{ids="8637", cond=[[Rogue]]},
		{ids="8634", cond=[[Mage]]},
		{ids="8665", cond=[[Druid]]},
		{ids="8596", cond=[[Priest]]},
		{ids="8626", cond=[[Hunter]]},
		{ids="8660", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Chest Quest"] = {
		{ids="8562", cond=[[Warrior]]},
		{ids="8627", cond=[[Paladin]]},
		{ids="8622", cond=[[Shaman]]},
		{ids="8638", cond=[[Rogue]]},
		{ids="8633", cond=[[Mage]]},
		{ids="8666", cond=[[Druid]]},
		{ids="8603", cond=[[Priest]]},
		{ids="8656", cond=[[Hunter]]},
		{ids="8661", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Helm Quest"] = {
		{ids="8561", cond=[[Warrior]]},
		{ids="8628", cond=[[Paladin]]},
		{ids="8623", cond=[[Shaman]]},
		{ids="8639", cond=[[Rogue]]},
		{ids="8632", cond=[[Mage]]},
		{ids="8667", cond=[[Druid]]},
		{ids="8592", cond=[[Priest]]},
		{ids="8657", cond=[[Hunter]]},
		{ids="8662", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Legs Quest"] = {
		{ids="8560", cond=[[Warrior]]},
		{ids="8629", cond=[[Paladin]]},
		{ids="8624", cond=[[Shaman]]},
		{ids="8640", cond=[[Rogue]]},
		{ids="8631", cond=[[Mage]]},
		{ids="8668", cond=[[Druid]]},
		{ids="8593", cond=[[Priest]]},
		{ids="8658", cond=[[Hunter]]},
		{ids="8663", cond=[[Warlock]]},
	},
	["LEVELING\\Ahn'Qiraj Gear\\Temple of Ahn'Qiraj Shoulder Quest"] = {
		{ids="8544", cond=[[Warrior]]},
		{ids="8630", cond=[[Paladin]]},
		{ids="8602", cond=[[Shaman]]},
		{ids="8641", cond=[[Rogue]]},
		{ids="8625", cond=[[Mage]]},
		{ids="8669", cond=[[Druid]]},
		{ids="8594", cond=[[Priest]]},
		{ids="8659", cond=[[Hunter]]},
		{ids="8664", cond=[[Warlock]]},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64047,64049,64051,64053,64217,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Shaman Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64046,64048,64050,64052,64063,9407"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800,8548"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8731,8732"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8731,8732"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8731,8732"},
	},
	["LEVELING\\Class Quests\\Druid Class Quests"] = {
		{ids="5926"},
	},
	["LEVELING\\Class Quests\\Hunter Class Quests"] = {
		{ids="6062"},
	},
	["LEVELING\\Class Quests\\Mage Class Quests"] = {
		{ids="1883"},
	},
	["LEVELING\\Class Quests\\Paladin Class Quests"] = {
		{ids="9678"},
	},
	["LEVELING\\Class Quests\\Priest Class Quests"] = {
		{ids="5652"},
	},
	["LEVELING\\Class Quests\\Shaman Class Quests"] = {
		{ids="1519"},
	},
	["LEVELING\\Class Quests\\Warlock Class Quests"] = {
		{ids="1485"},
	},
	["LEVELING\\Class Quests\\Warrior Class Quests"] = {
		{ids="1505"},
	},
	["LEVELING\\Classic (12-58)\\Alterac Mountains (37-38)"] = {
		{ids="544,556"},
	},
	["LEVELING\\Classic (12-58)\\Arathi Highlands (36-37)"] = {
		{ids="1164"},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (25-26)"] = {
		{ids="6641,25"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (46-47)"] = {
		{ids="5535,5536"},
	},
	["LEVELING\\Classic (12-58)\\Azshara (50-50)"] = {
		{ids="3517"},
	},
	["LEVELING\\Classic (12-58)\\Burning Steppes (54-54)"] = {
		{ids="4061,3821,4726,4296,4022"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (38-39)"] = {
		{ids="1201,11213,1322,11225,1177"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (43-44)"] = {
		{ids="1166,1169,1168,1273,11184,11158,11217"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (48-49)"] = {
		{ids="1172,626,1173"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (56-56)"] = {
		{ids="5157"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (45-46)"] = {
		{ids="2973,2975,2987,2862,2822,3121"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (49-49)"] = {
		{ids="3380,7734,3062,3063,4120"},
	},
	["LEVELING\\Classic (12-58)\\Silithus (58-59)"] = {
		{ids="1004,1123"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (15-16)"] = {
		{ids="1062,6548"},
	},
	["LEVELING\\Classic (12-58)\\Stonetalon Mountains (23-24)"] = {
		{ids="1087,6301,5881,6282"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (35-36)"] = {
		{ids="1181,605,201,189,213,1182,568,570,9436,581,596,629"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (39-39)"] = {
		{ids="595,606,1116,572,629,1261,571"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (42-43)"] = {
		{ids="604,587,600,621"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (47-47)"] = {
		{ids="608"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (44-45)"] = {
		{ids="2781,2875,1707,1690"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (49-50)"] = {
		{ids="3362,4504,5863"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (12-15)"] = {
		{ids="842"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (21-23)"] = {
		{ids="1095"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (27-29)"] = {
		{ids="1197"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (31-32)"] = {
		{ids="1145,1362"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (38-38)"] = {
		{ids="1205"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (55-56)"] = {
		{ids="8464,4842,5082,3783,6029,4809"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (59-60)"] = {
		{ids="5087,5121"},
	},
	["LEVELING\\Extra Zones\\Ghostlands"] = {
		{ids="9148"},
	},
	["LEVELING\\Scepter of the Shifting Sands"] = {
		{ids="8286"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Orgrimmar)"] = {
		{ids="9263,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Silvermoon City)"] = {
		{ids="12816,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Thunder Bluff)"] = {
		{ids="9264,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Undercity)"] = {
		{ids="9265,9154,9153,9085,9300,9302,9304,9295,9301,9299,12616"},
	},
	["LEVELING\\Starter Guides (1-12)\\Durotar (1-12) [Orc & Troll Starter]"] = {
		{ids="4641,1485"},
	},
	["LEVELING\\Starter Guides (1-12)\\Eversong Woods (1-13) [Blood Elf Starter]"] = {
		{ids="8325,8326,9393"},
	},
	["LEVELING\\Starter Guides (1-12)\\Mulgore (1-12) [Tauren Starter]"] = {
		{ids="3091", cond=[[Tauren Warrior]]},
		{ids="3092", cond=[[Tauren Hunter]]},
		{ids="3093", cond=[[Tauren Shaman]]},
		{ids="3094", cond=[[Tauren Druid]]},
		{ids="747,752,753,750"},
	},
	["LEVELING\\Starter Guides (1-12)\\Tirisfal Glades (1-12) [Undead Starter]"] = {
		{ids="363,364,1470"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10718,10614,10709,10714"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group"] = {
		{ids="9407,10120,10289,10450,10449,10242,10538,10835"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Isle of Quel'danas"] = {
		{ids="11481"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10210,10211,10551,10552"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10407,10410,10409,10243"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10210,10211,10551,10552,11047"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10037,10211,10551,10552"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10052,10898,10842,10877,10923,10034,10036,10922,10929,10930,9983"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9747,9802,9895,9716,9778"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,9817,9817,10117,9894,9895"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-72)"] = {
		{ids="11585,11596"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (72-74)"] = {
		{ids="12181,12182,12303,12209,12205,12206,12211"},
	},
	["LEVELING\\Northrend (69-80)\\Howling Fjord (69-71)"] = {
		{ids="11167"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13419,13036,13008,13040,13039,13044,13045,13070,13086"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12521,12489,12524,12624,12522,12688,12525"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-79)"] = {
		{ids="12818,12843,12844,12827,12836,12819,12826,12820,12828,12829,12830"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (75-76)"] = {
		{ids="12763,12859,12902,12861,12883,12884,12894,12903,12901,12912,12904,12914,12630"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12593,12619,12842,12848,12636,12641"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="5301,2756,2757"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Weaponsmith\\Weaponsmith Questline"] = {
		{ids="5302"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnome Engineer Membership Card Renewal"] = {
		{ids="3645"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Gnomish Engineering\\Gnomish Engineering Questline"] = {
		{ids="3637"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineer Membership Card Renewal"] = {
		{ids="3644"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="3633,3639"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5145"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5146"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2854,2855,2856,2857,2858,2859,2860"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2379,2382,2381"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="10804,10811,10814,10836,10837,10854,10858,10866,10870"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211,10551,10554"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913,9914,9882,9900,9925"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Mag'har"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,9442,9447"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10210,10211,10552,10553"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10210,9983,9888,9889,9890,9891,9906,9907"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Champion of the Naaru"] = {
		{ids="10680"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10445,10210,10211,10551,10552,10568"},
	},
}
ZGV.Quest_Cache_Turnin_Horde = {
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 1, Capturing Sanctum)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Activating Portal)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 2, Capturing Armory, Portal Activated)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Forge Rebuilt)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 3, Recovering Harbor, Rebuilding Forge)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Alchemy Lab Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Fully Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, Monument Built)"] = {
	},
	["DAILIES\\The Burning Crusade\\Shattered Sun Offensive\\Shattered Sun Dailies (Phase 4, No Alchemy Lab or Monument)"] = {
	},
	["DAILIES\\Wrath of the Lich King\\Dalaran Cooking Dailies"] = {
		{ids="13089"},
	},
	["DAILIES\\Wrath of the Lich King\\Icecrown\\Shadowvault Dailies"] = {
		{ids="12995,13069,13071"},
	},
	["DAILIES\\Wrath of the Lich King\\Jewelcrafting Dailies"] = {
		{ids="13041"},
	},
	["DAILIES\\Wrath of the Lich King\\The Kalu'ak Dailies"] = {
		{ids="11504,11507,11508,11509,11469,11472,11945,11960"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\Frenzyheart Tribe Dailies"] = {
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12692"},
	},
	["DAILIES\\Wrath of the Lich King\\The Oracles/Frenzyheart Dailies\\The Oracles Dailies"] = {
		{ids="12528,12529,12530,12533,12534,12532,12531,12535,12536,12537,12538,12539,12540,12570,12571,12572,12654,12573,12574,12575,12576,12577,12578,12580,12579,12581,12695"},
	},
	["DAILIES\\Wrath of the Lich King\\The Sons of Hodir\\The Sons of Hodir Dailies"] = {
		{ids="12843,12846,12841,12905,12906,12907,12908,12921,12969,12970,12971,12972,12851,12856,13063,12900,12983,12989,12996,12997,13061,13062"},
	},
	["DUNGEONS\\Classic\\Blackrock Depths Quests"] = {
		{ids="4133,3441,3442"},
	},
	["DUNGEONS\\Classic\\Dire Maul East Quests"] = {
		{ids="5527"},
	},
	["DUNGEONS\\Classic\\Dire Maul North Tribute (58-60)"] = {
		{ids="1193"},
	},
	["DUNGEONS\\Classic\\Gnomeregan Quests"] = {
		{ids="2842,2843"},
	},
	["DUNGEONS\\Classic\\Lower Blackrock Spire Quests"] = {
		{ids="3520"},
	},
	["DUNGEONS\\Classic\\Stratholme - Live Side Quests"] = {
		{ids="5281,5542,5543,5544,5742"},
	},
	["DUNGEONS\\Classic\\Temple of Atal'Hakkar Quests"] = {
		{ids="3380,3444,3520,3527,1424"},
	},
	["DUNGEONS\\Classic\\Wailing Caverns Quests"] = {
		{ids="886,870"},
	},
	["DUNGEONS\\The Burning Crusade\\Auchenai Crypts Quests"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,10227,10228,10231,10251,10252,10253,9888,9889,9890,9891,9906"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Citadel Attunement"] = {
		{ids="10755,10756,10757,10758"},
	},
	["DUNGEONS\\The Burning Crusade\\Hellfire Ramparts Quests"] = {
		{ids="9407,10120,10289,10291,10121,10123,10124"},
	},
	["DUNGEONS\\The Burning Crusade\\Mana-Tombs Quests"] = {
		{ids="10216,10165,10218"},
	},
	["DUNGEONS\\The Burning Crusade\\Old Hillsbrad Foothills Quests"] = {
		{ids="10279,10277,10282,10283,10284,10285,12513"},
	},
	["DUNGEONS\\The Burning Crusade\\Sethekk Halls Quests"] = {
		{ids="10180,10097,10098"},
	},
	["DUNGEONS\\The Burning Crusade\\Tempest Keep Attunement"] = {
		{ids="10883"},
	},
	["DUNGEONS\\The Burning Crusade\\The Arcatraz Quests"] = {
		{ids="10265,10262,10205,10266,10267,10268,10269"},
	},
	["DUNGEONS\\The Burning Crusade\\The Cipher of Damnation"] = {
		{ids="10681,10458,10480,10481,10513,10514,10515,10519,10521,10522,10523,10527,10528,10537,10540,10546,10541,10547,10550,10570,10576,10577,10578,10579,10588"},
	},
	["DUNGEONS\\The Burning Crusade\\The Mechanar Quests"] = {
		{ids="10623,10627,10663"},
	},
	["DUNGEONS\\The Burning Crusade\\The Slave Pens Quests"] = {
		{ids="9738"},
	},
	["DUNGEONS\\The Burning Crusade\\The Steamvault Quests"] = {
		{ids="10623,10627,10663,10664,10666,9763,9764,10885,10667"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Ahn'kahet: The Old Kingdom Quests"] = {
		{ids="13187,13204"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Azjol-Nerub Quests"] = {
		{ids="13167,13182"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Drak'Tharon Keep Quests"] = {
		{ids="12208"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Gundrak Quests"] = {
		{ids="12507,12510,12514,12516,12623,12627,12628,12632,12642,12646,12647,12653,12665,12666,12667,12672,12668,12674,12675,12684"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Lightning Quests"] = {
		{ids="12843"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Halls of Stone Quests"] = {
		{ids="13207"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Culling of Stratholme Quests"] = {
		{ids="13149,13151"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Nexus Quests"] = {
		{ids="11733,11941,11900,11910,11943,11946,11951"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Oculus Quests"] = {
		{ids="13124,13126,13127,13128"},
	},
	["DUNGEONS\\Wrath of the Lich King\\The Violet Hold Quests"] = {
		{ids="13158,13159"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Keep Quests"] = {
		{ids="11272,13206,11262"},
	},
	["DUNGEONS\\Wrath of the Lich King\\Utgarde Pinnacle Quests"] = {
		{ids="13131,13132"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Month"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Brew of the Year"] = {
		{ids="12306"},
	},
	["EVENTS\\Brewfest\\Achievements\\Direbrewfest"] = {
		{ids="12062"},
	},
	["EVENTS\\Brewfest\\Achievements\\Down With The Dark Iron"] = {
		{ids="12192"},
	},
	["EVENTS\\Brewfest\\Brewfest Quests"] = {
		{ids="11409,11412,12191,12194"},
	},
	["EVENTS\\Children's Week\\Children's Week Main Questline"] = {
		{ids="172,1800,910,911,915,925,5502"},
	},
	["EVENTS\\Feast of Winter Veil\\Feast of Winter Veil Quest"] = {
		{ids="6964,7061,6961"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Hallowed Be Thy Name"] = {
	},
	["EVENTS\\Hallow's End\\Achievements\\The Savior of Hallow's End"] = {
		{ids="11357,11361"},
	},
	["EVENTS\\Hallow's End\\Achievements\\Tricks and Treats of Azeroth"] = {
	},
	["EVENTS\\Hallow's End\\Hallow's End Quests"] = {
		{ids="8359"},
	},
	["EVENTS\\Lunar Festival\\Lunar Festival Main Questline"] = {
		{ids="8873,8867,8883"},
	},
	["EVENTS\\Midsummer Fire Festival\\Midsummer Fire Festival Quests"] = {
		{ids="11915,11922,11923,11886,11891,12012,11966,11955,11696,11691,11972"},
	},
	["LEVELING\\Boosted Characters\\Boosted Druid Intro"] = {
		{ids="64047,64049,64051,64053,64217"},
	},
	["LEVELING\\Boosted Characters\\Boosted Hunter Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Mage Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Priest Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Rogue Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Shaman Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warlock Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Boosted Characters\\Boosted Warrior Intro"] = {
		{ids="64046,64048,64050,64052,64063"},
	},
	["LEVELING\\Cenarion Battlegear"] = {
		{ids="8800"},
	},
	["LEVELING\\Cenarion Field Duty Combat Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Logistics Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Cenarion Field Duty Tactical Assignments"] = {
		{ids="8507"},
	},
	["LEVELING\\Classic (12-58)\\Ashenvale (25-26)"] = {
		{ids="6641"},
	},
	["LEVELING\\Classic (12-58)\\Blasted Lands (51-52)"] = {
		{ids="1444"},
	},
	["LEVELING\\Classic (12-58)\\Burning Steppes (54-54)"] = {
		{ids="4324,4022"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (43-44)"] = {
		{ids="1273"},
	},
	["LEVELING\\Classic (12-58)\\Dustwallow Marsh (48-49)"] = {
		{ids="625,1172,1173"},
	},
	["LEVELING\\Classic (12-58)\\Felwood (56-56)"] = {
		{ids="4521,5155,5156,4102"},
	},
	["LEVELING\\Classic (12-58)\\Feralas (49-49)"] = {
		{ids="3122"},
	},
	["LEVELING\\Classic (12-58)\\Silithus (58-59)"] = {
		{ids="1004"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (35-36)"] = {
		{ids="1180,1181"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (39-39)"] = {
		{ids="1115,1240,572"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (42-43)"] = {
		{ids="1116"},
	},
	["LEVELING\\Classic (12-58)\\Stranglethorn Vale (47-47)"] = {
		{ids="1118,2874"},
	},
	["LEVELING\\Classic (12-58)\\Tanaris (44-45)"] = {
		{ids="2864"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (12-15)"] = {
		{ids="840,809"},
	},
	["LEVELING\\Classic (12-58)\\The Barrens (21-23)"] = {
		{ids="1094,1069"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (27-29)"] = {
		{ids="1196"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (31-32)"] = {
		{ids="1361"},
	},
	["LEVELING\\Classic (12-58)\\Thousand Needles (38-38)"] = {
		{ids="1436,1136"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (55-56)"] = {
		{ids="8465,980,3908,4808"},
	},
	["LEVELING\\Classic (12-58)\\Winterspring (59-60)"] = {
		{ids="5086,5087"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Orgrimmar)"] = {
		{ids="9263,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Silvermoon City)"] = {
		{ids="12816,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Thunder Bluff)"] = {
		{ids="9264,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Scourge Invasion\\Scourge Invasion Event (Undercity)"] = {
		{ids="9265,9154,9153,9085,9300,9302,9304,9295,9301,9299"},
	},
	["LEVELING\\Starter Guides (1-12)\\Eversong Woods (1-13) [Blood Elf Starter]"] = {
		{ids="8325"},
	},
	["LEVELING\\Starter Guides (1-12)\\Mulgore (1-12) [Tauren Starter]"] = {
		{ids="752,747,3093"},
	},
	["LEVELING\\Starter Guides (1-12)\\Tirisfal Glades (1-12) [Undead Starter]"] = {
		{ids="363"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Blade's Edge Mountains Group Quests"] = {
		{ids="10718,10614,10709"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Hellfire Peninsula Group"] = {
		{ids="9407,10120,10289,10450,10449,10242,10538"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm (68-70)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Netherstorm Group Quests"] = {
		{ids="10407,10410,10409"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Shadowmoon Valley (70-70)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest (63-65)"] = {
		{ids="10210,10211"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Terokkar Forest Group Quests"] = {
		{ids="10052,10898,10842,10877,10923,10034,10036,10922,10929,10930"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh (62-63)"] = {
		{ids="9912"},
	},
	["LEVELING\\The Burning Crusade (58-70)\\Zangarmarsh Group Quests"] = {
		{ids="9730,10117,9894,9895"},
	},
	["LEVELING\\Northrend (69-80)\\Borean Tundra (70-72)"] = {
		{ids="11585"},
	},
	["LEVELING\\Northrend (69-80)\\Dragonblight (72-74)"] = {
		{ids="12181,12206"},
	},
	["LEVELING\\Northrend (69-80)\\Icecrown (79-80)"] = {
		{ids="13036,13039,13040,13008,13044,13045,13070,13086"},
	},
	["LEVELING\\Northrend (69-80)\\Sholazar Basin (76-77)"] = {
		{ids="12521,12489,12524,12624"},
	},
	["LEVELING\\Northrend (69-80)\\The Storm Peaks (77-79)"] = {
		{ids="12818,12819,12826,12827,12836"},
	},
	["LEVELING\\Northrend (69-80)\\Zul'Drak (75-76)"] = {
		{ids="12763,12902,12859,12861,12883,12894,12904,12901,12912,12903,12884"},
	},
	["LEVELING\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)"] = {
		{ids="12593,12619,12842,12848,12636"},
	},
	["PROFESSIONS\\Blacksmithing\\Specialization\\Armorsmith\\Armorsmith Questline"] = {
		{ids="2756"},
	},
	["PROFESSIONS\\Engineering\\Specialization\\Goblin Engineering\\Goblin Engineering Questline"] = {
		{ids="3633,3639"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Dragonscale Leatherworking\\Dragonscale Leatherworking Questline"] = {
		{ids="5145"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Elemental Leatherworking\\Elemental Leatherworking Questline"] = {
		{ids="5146"},
	},
	["PROFESSIONS\\Leatherworking\\Specialization\\Tribal Leatherworking\\Tribal Leatherworking Questline"] = {
		{ids="2854,2855,2856,2857,2858,2859,2860"},
	},
	["PROFESSIONS\\Lockpicking\\Lockpicking (1-300)"] = {
		{ids="2379,2382"},
	},
	["REPUTATIONS\\The Burning Crusade\\Keepers of Time"] = {
		{ids="10279,10277,10282,10283,10284,10285,10296,10297,10298"},
	},
	["REPUTATIONS\\The Burning Crusade\\Netherwing"] = {
		{ids="10804,10811,10814,10836,10837,10854,10858,10866"},
	},
	["REPUTATIONS\\The Burning Crusade\\Sporeggar"] = {
		{ids="9739,9743"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Aldor"] = {
		{ids="10210,10211"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Consortium"] = {
		{ids="9913"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Mag'har"] = {
		{ids="9400,9401,9405,9410,9406,9438,9441,9442,9447"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Scryers"] = {
		{ids="10210,10211"},
	},
	["REPUTATIONS\\The Burning Crusade\\The Sha'tar"] = {
		{ids="10210,9888,9889,9890,9891,9906"},
	},
	["TITLES\\Burning Crusade Titles\\Dungeons & Raids\\Hand of A'dal"] = {
		{ids="10210,10211"},
	},
}
