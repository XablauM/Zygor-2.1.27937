local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if UnitFactionGroup("player")~="Alliance" then return end
if ZGV:DoMutex("LevelingALK") then return end
ZygorGuidesViewer.GuideMenuTier = "TRI"
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Starter Guides (1-12) & Death Knight (55-58)\\Death Knight Starter (55-58)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Death Knight",
condition_valid=function() return raceclass('DeathKnight') end,
condition_valid_msg="Death Knight only.",
condition_suggested=function() return (raceclass('DeathKnight') and not completedq(13188)) end,
condition_suggested_exclusive=true,
condition_end=function() return completedq(13188) end,
},[[
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
accept In Service Of The Lich King##12593 |goto Plaguelands: The Scarlet Enclave 51.34,35.18
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin In Service Of The Lich King##12593 |goto 48.27,28.38
accept The Emblazoned Runeblade##12619 |goto 48.27,28.38
step
click Battle-worn Sword##190584+
|tip They look like swords leaning up against objects around this area.
|tip On the upper floor of the floating building.
collect Battle-worn Sword##38607 |goto 47.82,27.77 |q 12619
step
use the Battle-worn Sword##38607
|tip Next to a Runeforge.
|tip They look like large skulls with grey metal pipes connected to them, next to the wall around this area.
|tip On the upper floor of the floating building.
collect Runebladed Sword##38631 |q 12619/1 |goto 47.88,27.54
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin The Emblazoned Runeblade##12619 |goto 48.27,28.38
accept Runeforging: Preparation For Battle##12842 |goto 48.27,28.38
step
cast Runeforging##53428
|tip Next to a Runeforge.
|tip They look like large skulls with grey metal pipes connected to them, next to the wall around this area.
|tip On the upper floor of the floating building.
Engrave the Rune
|tip Choose the rune you prefer and click the "Engrave" button.
|tip Select the sword you received in the previous step.
Emblazon Your Weapon |q 12842/1 |goto 47.88,27.54
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin Runeforging: Preparation For Battle##12842 |goto 48.27,28.38
accept The Endless Hunger##12848 |goto 48.27,28.38
step
click Acherus Soul Prison##8115+
|tip They look like horned skulls on the wall, chaining the prisoners around this area.
|tip On the upper floor of the floating building.
Watch the dialogue
kill Unworthy Initiate##29565
Dominate an Unworthy Initiate |q 12848/1 |goto 48.87,29.67
step
talk Instructor Razuvious##28357
|tip He walks around this area, on the upper floor of the floating building.
turnin The Endless Hunger##12848 |goto 48.27,28.38
accept The Eye Of Acherus##12636 |goto 48.27,28.38
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
turnin The Eye Of Acherus##12636 |goto 51.34,35.18
accept Death Comes From On High##12641 |goto 51.34,35.18
step
click Eye of Acherus Control Mechanism##191609
Take Control of the Eye of Acherus |havebuff spell:51852 |goto 52.13,35.21 |q 12641
step
Watch the dialogue
|tip You will automatically fly away while controlling the Eye of Acherus.
Reach New Avalon |complete subzone("New Avalon") |q 12641
step
_Fly to the Northeast:_
Locate the Blacksmith Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the blacksmith building.
Analyze the New Avalon Forge |q 12641/1
step
_Fly to the South:_
Locate the Fort Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the fort building.
Analyze the Scarlet Hold |q 12641/3
step
_Fly to the West:_
Locate the Town Hall Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the town hall building.
Analyze the New Avalon Town Hall |q 12641/2
step
_Fly to the South:_
Locate the Church Building
|tip Stay floating high, so the soldiers on the ground will not attack you.
Use the _"Siphon of Acherus"_ ability |petaction 1
|tip Near the red arrow bouncing above the church building.
Analyze the Chapel of the Crimson Flame |q 12641/4
step
Use the _"Recall Eye of Acherus"_ ability |petaction 5
Recall the Eye of Acherus |nobuff spell:51852 |q 12641
step
talk The Lich King##25462
|tip On the upper floor of the floating building.
turnin Death Comes From On High##12641 |goto 51.34,35.18
accept The Might Of The Scourge##12657 |goto 51.34,35.18
step
Teleport to the Hall of Command |complete subzone("Hall of Command") |goto 50.49,33.37 |q 12657
|tip Walk onto the teleport pad.
|tip On the upper floor of the floating building.
step
talk Highlord Darion Mograine##28444
|tip On the bottom floor of the floating building.
turnin The Might Of The Scourge##12657 |goto 48.88,29.76
accept Report To Scourge Commander Thalanor##12850 |goto 48.88,29.76
step
talk Lord Thorval##28472
|tip He walks around this area, on the bottom floor of the floating building.
accept The Power Of Blood, Frost And Unholy##12849 |goto 47.48,26.56 |instant
step
talk Scourge Commander Thalanor##28510
|tip He walks around this area on a skeletal bird mount.
|tip On the bottom floor of the floating building.
turnin Report To Scourge Commander Thalanor##12850 |goto 51.10,34.63
accept The Scarlet Harvest##12670 |goto 51.10,34.63
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12670
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12670 |notravel
step
talk Prince Valanar##28377
turnin The Scarlet Harvest##12670 |goto 52.28,33.96
accept If Chaos Drives, Let Suffering Hold The Reins##12678 |goto 52.28,33.96
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
accept Grand Theft Palomino##12680 |goto 52.51,34.61
step
talk Olrun the Battlecaller##29047
|tip She flies close to the ground around this area.
accept Death's Challenge##12733 |goto 54.63,33.95
step
talk Death Knight Initiate##28406+
|tip They look like NPCs wearing brown robes.
|tip You can find them all around the Death's Breach area.
Tell them _"I challenge you, death knight!"_
kill Death Knight Initiate##28392+
|tip They will eventually surrender.
Defeat #5# Death Knights in a Duel |q 12733/1 |goto 52.51,34.46
step
talk Olrun the Battlecaller##29047
|tip She flies around this small area.
turnin Death's Challenge##12733 |goto 54.63,33.95
step
talk Orithos the Sky Darkener##28647
|tip He walks around this area.
accept Tonight We Dine In Havenshire##12679 |goto 52.96,37.27
stickystart "Slay_Scarlet_Crusaders"
stickystart "Citizens_Of_Havenshire"
stickystart "Saronite_Arrows"
step
click Havenshire Horse+
|tip They look like various color horses.
|tip You can find them all around the Havenshire Stables area.
|tip Be careful to avoid Stable Master Kitrik.
|tip He's elite and will pull you off the horse.
Ride the Havenshire Horse |invehicle |goto 55.93,42.21 |q 12680
step
Follow the path up to Death's Breach |goto 51.60,42.66 < 60 |only if walking and not subzone("Death's Breach")
Successfully Steal a Horse |q 12680/1 |goto 52.51,34.61
|tip Use the "Deliver Stolen Horse" ability next to Salanar the Horseman.
|tip He walks back and forth along this path.
stickystop "Slay_Scarlet_Crusaders"
stickystop "Citizens_Of_Havenshire"
stickystop "Saronite_Arrows"
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
turnin Grand Theft Palomino##12680 |goto 52.51,34.61
accept Into the Realm of Shadows##12687 |goto 52.51,34.61
step
kill Dark Rider of Acherus##28768+
|tip They ride around on dark colored horses with horns and white glowing feet.
|tip You can find them all around the Havenshire area.
clicknpc Acherus Deathcharger##28302
|tip The horse next to you that the Dark Rider of Acherus was riding on.
Steal an Acherus Deathcharger |invehicle |goto 54.27,44.54 |q 12687
step
Watch the dialogue
|tip Use the "Horseman's Call" ability on your action bar.
Complete the Horseman's Challenge |q 12687/1 |goto 50.88,41.74
step
talk Salanar the Horseman##28653
|tip He walks back and forth along this path.
turnin Into the Realm of Shadows##12687 |goto 52.51,34.61
step
_NOTE:_
You Can Now Mount Up
|tip You just earned your ground mount.
|tip When you need to travel now, you can use your mount to move faster.
|tip Press Shift+P to open your Mounts window and move your horse to your action bar.
Click Here to Continue |confirm |q 12678
stickystart "Slay_Scarlet_Crusaders"
stickystart "Citizens_Of_Havenshire"
stickystart "Saronite_Arrows"
step
click Abandoned Mail##190917
|tip It looks like a rolled up scroll on top of the mailbox.
accept Abandoned Mail##12711 |goto 55.26,46.15 |instant
step
label "Slay_Scarlet_Crusaders"
Kill Scarlet enemies around this area
|tip They look like human soldiers with red and white armor, or civilians chopping wood.
|tip You can find them all around the northern part of the Havenshire area. |notinsticky
Slay #10# Scarlet Crusaders |q 12678/1 |goto 55.17,43.39
step
label "Citizens_Of_Havenshire"
kill 10 Citizen of Havenshire##28660 |q 12678/2 |goto 57.10,47.55
|tip They look like humans running south.
|tip You can find them all around the southern part of the Havenshire area. |notinsticky
step
label "Saronite_Arrows"
click Saronite Arrow##190691+
|tip They look like green glowing arrows stuck in the ground around this area.
|tip You can find them all around the northern and southern parts of the Havenshire area. |notinsticky
collect 15 Saronite Arrow##39160 |q 12679/1 |goto 57.10,47.55
step
Follow the path up to Death's Breach |goto 51.60,42.66 < 60 |only if walking and not subzone("Death's Breach")
talk Orithos the Sky Darkener##28647
|tip He paces around this area.
turnin Tonight We Dine In Havenshire##12679 |goto 52.96,37.27
step
talk Prince Valanar##28377
turnin If Chaos Drives, Let Suffering Hold The Reins##12678 |goto 52.27,33.97
accept Gothik the Harvester##12697 |goto 52.27,33.97
step
talk Gothik the Harvester##28658
turnin Gothik the Harvester##12697 |goto 54.07,35.03
accept The Gift That Keeps On Giving##12698 |goto 54.07,35.03
step
use the Gift of the Harvester##39253
|tip Use it on Scarlet Miners.
|tip They appear at the entrance of the mine, but you can find them throughout.
Gather _5_ Scarlet Ghouls
|tip The miners have a chance to become a friendly ghoul that will begin following you.
|tip Some of them may turn into ghosts and attack you.
Click Here Once You Have 5 Ghouls |confirm |c |goto 58.29,30.92 |q 12698
step
Leave the mine |goto 58.25,30.97 < 15 |walk |only if subzone("Havenshire Mine") and _G.IsIndoors()
Follow the path up to Death's Breach |goto 55.79,31.11 < 30 |only if not subzone("Death's Breach")
Return #5# Scarlet Ghouls |q 12698/1 |goto 54.07,35.03
|tip Bring the ghouls to this location.
step
talk Gothik the Harvester##28658
turnin The Gift That Keeps On Giving##12698 |goto 54.07,35.03
accept An Attack Of Opportunity##12700 |goto 54.07,35.03
step
talk Hargus the Gimp##28760
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Hargus the Gimp##28760 |goto 52.90,35.21 |q 12700
step
talk Prince Valanar##28377
turnin An Attack Of Opportunity##12700 |goto 52.27,33.97
accept Massacre At Light's Point##12701 |goto 52.27,33.97
step
click Inconspicuous Mine Car##190767
Hide in the Inconspicuous Mine Cart |invehicle |goto 58.52,33.00 |q 12701
step
Watch the dialogue
|tip A Scarlet Miner will bring you down to the beach in the cart.
Ride to the Scarlet Fleet Ship |outvehicle |goto 67.80,38.65 |q 12701 |notravel
step
click Scarlet Cannon##176216
|tip On the deck of the ship.
kill Scarlet Fleet Defender##28834+
|tip Use the abilities on your action bar to kill the soldiers on the beach nearby.
Slay #100# Scarlet Defenders |q 12701/1 |goto 67.73,39.01
step
Call for a Skeletal Gryphon |ontaxi |goto 67.73,39.01 |q 12701
|tip Use the "Skeletal Gryphon Escape" ability on your action bar.
|tip A skeletal gryphon will pick you up and fly you away.
step
Escape to Death's Breach |offtaxi |goto 52.57,34.45 |q 12701 |notravel
step
talk Prince Valanar##28377
turnin Massacre At Light's Point##12701 |goto 52.27,33.97
accept Victory At Death's Breach!##12706 |goto 52.27,33.97
step
clicknpc Scourge Gryphon##29501
Begin Flying to Acherus |ontaxi |goto 53.09,32.48 |q 12706
step
Fly Up to Archerus |offtaxi |goto 51.09,34.63 |q 12706 |notravel
step
talk Highlord Darion Mograine##28444
|tip On the upper floor of the floating building.
turnin Victory At Death's Breach!##12706 |goto 48.87,29.76
accept The Will Of The Lich King##12714 |goto 48.87,29.76
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12714
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12714 |notravel
step
talk Prince Valanar##28907
turnin The Will Of The Lich King##12714 |goto 53.46,36.56
accept The Crypt of Remembrance##12715 |goto 53.46,36.56
step
talk Noth the Plaguebringer##28919
accept The Plaguebringer's Request##12716 |goto 55.89,52.40
step
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin The Crypt of Remembrance##12715 |goto 54.30,57.31
accept Nowhere To Run And Nowhere To Hide##12719 |goto 54.30,57.31
step
talk Baron Rivendare##28910
|tip Downstairs inside the crypt.
accept Lambs To The Slaughter##12722 |goto 54.66,57.43
stickystart "Slay_Scarlet_Crusade_Soldiers"
stickystart "Collect_Crusader_Skulls"
stickystart "Kill_Citizens_Of_New_Avalaon"
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12719
step
Enter the building |goto 53.20,71.01 < 10 |walk |only if not (subzone("New Avalon Town Hall") and _G.IsIndoors())
kill Mayor Quimby##28945 |q 12719/1 |goto 52.24,71.17
|tip Inside the building.
step
click New Avalon Registry##190947
|tip Inside the building.
collect New Avalon Registry##39362 |q 12719/2 |goto 52.45,71.00
step
Leave the building |goto 53.20,71.01 < 10 |walk |only if subzone("New Avalon Town Hall") and _G.IsIndoors()
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin Nowhere To Run And Nowhere To Hide##12719 |goto 54.30,57.31
accept How To Win Friends And Influence Enemies##12720 |goto 54.30,57.31
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12716
step
Enter the building |goto 61.46,60.73 < 15 |walk
click Iron Chain##190938
|tip Inside the building.
collect Iron Chain##39326 |q 12716/2 |goto 62.05,60.24
step
Enter the building |goto 57.68,64.37 < 10 |walk
click Empty Cauldron##190937
|tip Downstairs inside the building.
collect Empty Cauldron##39324 |q 12716/1 |goto 57.86,61.84
step
use the Ornately Jeweled Box##39418
collect Keleseth's Persuader##39371 |q 12720 |only if Frost
collect Keleseth's Persuader##142274 |q 12720 |only if Blood or Unholy
step
Equip Keleseth's Persuaders |equipped Keleseth's Persuader##39371 |q 12720 |only if Frost
Equip Keleseth's Persuader |equipped Keleseth's Persuader##142274 |q 12720 |only if Blood or Unholy
|tip Equip both of Keleseth's Persuaders in your bag. |only if Frost
|tip Equip the Keleseth's Persuader in your bag. |only if Blood or Unholy
step
Leave the building |goto 57.68,64.37 < 10 |walk |only if subzone("New Avalon") and _G.IsIndoors()
Kill Scarlet enemies around this area
|tip They look like soldiers with red and white armor.
|tip You can find them all around the New Avalon area. |notinsticky
|tip Try not to kill them too fast.
|tip Stop attacking when they start talking.
|tip Eventually one of the enemies will give you information.
|tip You must have Keleseth's Persuader weapon(s) equipped to get the enemies to talk to you.
Reveal the "Crimson Dawn" |q 12720/1 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
Equip Your Normal Weapon
Click Here After Equipping Your Normal Weapon |confirm |q 12720
step
label "Slay_Scarlet_Crusade_Soldiers"
Kill Scarlet enemies around this area
|tip They look like soldiers with red and white armor.
|tip You can find them all around the New Avalon area. |notinsticky
Slay #10# Scarlet Crusade Soldiers |q 12722/1 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
label "Collect_Crusader_Skulls"
Kill enemies around this area
|tip You can kill soldiers or civilians.
|tip You can find them all around the New Avalon area. |notinsticky
collect 10 Crusader Skull##39328 |q 12716/3 |goto 56.75,67.50
You can find more around [56.27,75.81]
step
label "Kill_Citizens_Of_New_Avalaon"
kill 15 Citizen of New Avalon##28942 |q 12722/2 |goto 56.75,67.50
|tip They look like human civilians in regular clothes.
|tip They are mostly inside the buildings.
|tip You can find them all around the New Avalon area. |notinsticky
You can find more around [56.27,75.81]
step
talk Noth the Plaguebringer##28919
turnin The Plaguebringer's Request##12716 |goto 55.89,52.40
accept Noth's Special Brew##12717 |goto 55.89,52.40
step
click Plague Cauldron##190936
turnin Noth's Special Brew##12717 |goto 56.15,51.98
step
click Plague Cauldron##190936
|tip Turn in the "More Skulls For Brew!" quest to get more potions of Noth's Special Brew.
|tip Keep doing this until you don't have enough skulls to get more potions.
Create More Noth's Special Brew |complete itemcount(39328) < 20 |goto 56.15,51.98
|only if itemcount(39328) >= 20
step
_Destroy These Items:_
|tip They are no longer needed.
trash Crusader Skull##39328
step
Enter the crypt and run down the stairs |goto 54.11,58.14 < 10 |walk |only if not (subzone("Crypt of Remembrance") and _G.IsIndoors())
talk Prince Keleseth##28911
|tip Downstairs inside the crypt.
turnin How To Win Friends And Influence Enemies##12720 |goto 54.30,57.31
accept Behind Scarlet Lines##12723 |goto 54.30,57.31
step
talk Baron Rivendare##28910
|tip Downstairs inside the crypt.
turnin Lambs To The Slaughter##12722 |goto 54.66,57.43
step
Run up the stairs and leave the crypt |complete not (subzone("Crypt of Remembrance") and _G.IsIndoors()) |goto 54.34,58.13 |q 12716
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin Behind Scarlet Lines##12723 |goto 56.26,79.84
accept The Path Of The Righteous Crusader##12724 |goto 56.26,79.84
step
talk Thassarian##28913
|tip Upstairs inside the building.
accept Brothers In Death##12725 |goto 56.27,80.15
step
Enter the building |goto 61.10,68.06 < 15 |walk |only if not (subzone("Scarlet Hold") and _G.IsIndoors())
Run down the stairs |goto 62.77,68.63 < 7 |walk
talk Koltira Deathweaver##28912
|tip Downstairs in the building.
turnin Brothers In Death##12725 |goto 62.96,67.85
accept Bloody Breakout##12727 |goto 62.96,67.85
step
Kill the enemies that attack in waves
|tip Downstairs in the building.
kill High Inquisitor Valroth##29001
|tip Stay inside the bubble Koltira Deathweaver forms.
|tip It reduces spell damage, so you'll live.
click High Inquisitor Valroth's Remains##191092
|tip It appears on the ground where you killed High Inquisitor Valroth.
collect Valroth's Head##39510 |q 12727/1 |goto 62.91,68.10
step
click New Avalon Patrol Schedule##191084
|tip It looks like a thick book sitting on a long table.
|tip Upstairs inside the building, in a large room.
collect New Avalon Patrol Schedule##39504|q 12724/1 |goto 62.99,68.31
step
Leave the building |goto 61.10,68.06 < 15 |walk |only if subzone("Scarlet Hold") and _G.IsIndoors()
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin The Path Of The Righteous Crusader##12724 |goto 56.26,79.84
step
talk Thassarian##28913
|tip Upstairs inside the building.
turnin Bloody Breakout##12727 |goto 56.27,80.15
accept A Cry For Vengeance!##12738 |goto 56.27,80.15
step
talk Knight Commander Plaguefist##29053
|tip He walks around this area.
turnin A Cry For Vengeance!##12738 |goto 52.97,81.95
accept A Special Surprise##12742 |goto 52.97,81.95 |only Human
accept A Special Surprise##12743 |goto 52.97,81.95 |only NightElf
accept A Special Surprise##12744 |goto 52.97,81.95 |only Dwarf
accept A Special Surprise##12745 |goto 52.97,81.95 |only Gnome
accept A Special Surprise##12746 |goto 52.97,81.95 |only Draenei
accept A Special Surprise##12739 |goto 52.97,81.95 |only Tauren
accept A Special Surprise##12747 |goto 52.97,81.95 |only BloodElf
accept A Special Surprise##12748 |goto 52.97,81.95 |only Orc
accept A Special Surprise##12749 |goto 52.97,81.95 |only Troll
accept A Special Surprise##12750 |goto 52.97,81.95 |only Scourge
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Valok the Righteous##29070 |q 12746/1 |goto 54.55,83.42
|only Draenei
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Yazmina Oakenthorn##29065 |q 12743/1 |goto 54.25,83.91
|only NightElf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Goby Blastenheimer##29068 |q 12745/1 |goto 53.93,83.81
|only Gnome
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Ellen Stanbridge##29061 |q 12742/1 |goto 53.53,83.79
|only Human
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Donovan Pulfrost##29067 |q 12744/1 |goto 54.02,83.28
|only Dwarf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Malar Bravehorn##29032 |q 12739/1 |goto 54.51,83.87
|only Tauren
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Lady Eonys##29074 |q 12747/1 |goto 54.28,83.29
|only BloodElf
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Kug Ironjaw##29072 |q 12748/1 |goto 53.77,83.27
|only Orc
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Iggy Darktusk##29073 |q 12749/1 |goto 53.80,83.77
|only Troll
step
Enter the building |goto 54.47,83.15 < 10 |walk
Watch the dialogue
|tip Inside the building.
kill Antoine Brack##29071 |q 12750/1 |goto 53.54,83.30
|only Scourge
step
talk Knight Commander Plaguefist##29053
|tip He walks around this area.
turnin A Special Surprise##12742 |goto 52.97,81.95 |only Human
turnin A Special Surprise##12743 |goto 52.97,81.95 |only NightElf
turnin A Special Surprise##12744 |goto 52.97,81.95 |only Dwarf
turnin A Special Surprise##12745 |goto 52.97,81.95 |only Gnome
turnin A Special Surprise##12746 |goto 52.97,81.95 |only Draenei
turnin A Special Surprise##28649 |goto 52.97,81.95 |only Worgen
turnin A Special Surprise##12739 |goto 52.97,81.95 |only Tauren
turnin A Special Surprise##12747 |goto 52.97,81.95 |only BloodElf
turnin A Special Surprise##12748 |goto 52.97,81.95 |only Orc
turnin A Special Surprise##12749 |goto 52.97,81.95 |only Troll
turnin A Special Surprise##12750 |goto 52.97,81.95 |only Scourge
turnin A Special Surprise##28650 |goto 52.97,81.95 |only Goblin
accept A Sort Of Homecoming##12751 |goto 52.97,81.95
step
Enter the building |goto 56.14,79.97 < 10 |walk
talk Thassarian##28913
|tip Upstairs inside the building.
turnin A Sort Of Homecoming##12751 |goto 56.27,80.15
step
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
accept Ambush At The Overlook##12754 |goto 56.26,79.84
step
use the Makeshift Cover##39645
Watch the dialogue
|tip A Scarlet Courier walks up to you on a horse.
kill Scarlet Courier##29076
collect Scarlet Courier's Belongings##39646 |q 12754/1 |goto 59.97,78.57
collect Scarlet Courier's Message##39647 |q 12754/2 |goto 59.97,78.57
step
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin Ambush At The Overlook##12754 |goto 56.26,79.84
accept A Meeting With Fate##12755 |goto 56.26,79.84
step
Follow the path down to the beach |goto 60.63,80.73 < 70 |only if walking and not subzone("King's Harbor")
talk High General Abbendis##29077
turnin A Meeting With Fate##12755 |goto 65.65,83.82
accept The Scarlet Onslaught Emerges##12756 |goto 65.65,83.82
step
Follow the path up back to the orchard |goto 62.92,85.10 < 50 |only if walking
Enter the building |goto 56.14,79.97 < 10 |walk
talk Orbaz Bloodbane##28914
|tip Upstairs inside the building.
turnin The Scarlet Onslaught Emerges##12756 |goto 56.26,79.84
accept Scarlet Armies Approach...##12757 |goto 56.26,79.84
step
Watch the dialogue
|tip Orbaz Bloodbane will create a portal.
|tip Upstairs inside the building.
click Portal to Acherus##8046
Return to Acherus |complete subzone("Acherus: The Ebon Hold") |goto 56.18,80.04 |q 12757
step
talk Highlord Darion Mograine##28444
|tip On the bottom floor of the floating building.
turnin Scarlet Armies Approach...##12757 |goto 48.89,29.77
accept The Scarlet Apocalypse##12778 |goto 48.89,29.77
step
clicknpc Scourge Gryphon##29488
|tip On the upper floor of the floating building.
Begin Flying to Death's Breach |ontaxi |goto 50.96,36.15 |q 12778
step
Fly Down to Death's Breach |offtaxi |goto 53.20,31.14 |q 12778 |notravel
step
talk The Lich King##29110
turnin The Scarlet Apocalypse##12778 |goto 53.57,36.85
accept An End To All Things...##12779 |goto 53.57,36.85
step
use the Horn of the Frostbrood##39700
Summon a Frostbrood Vanquisher |invehicle |q 12779
stickystart "Kill_Scarlet_Soldiers_12779"
step
kill Scarlet Ballista##29104+
|tip They look like large brown wooden crossbow machines.
|tip They are up on the walls or on the ground all around the New Avalon area.
|tip Use the abilities on your action bar.
Destroy #10# Scarlet Ballistas |q 12779/2 |goto 57.70,59.97
You can find more around [57.72,70.29]
step
label "Kill_Scarlet_Soldiers_12779"
kill 150 Scarlet Soldier##4286 |q 12779/1 |goto 57.72,70.29
|tip They look like humans wearing red and white armor.
|tip You can find them all around the New Avalon area.
|tip Use the abilities on your action bar.
step
Return to Death's Breach |complete subzone("Death's Breach") |goto 53.57,36.85 |q 12779
|tip Fly back to Death's Breach manually with the dragon.
|tip Don't click the red arrow to stop controlling the dragon until you get back to Death's Breach.
step
Release the Frostbrood Vanquisher |outvehicle |goto 53.57,36.85 |q 12779
|tip Click the red arrow on your action bar.
step
talk The Lich King##29110
turnin An End To All Things...##12779 |goto 53.57,36.85
accept The Lich King's Command##12800 |goto 53.57,36.85
step
talk Hargus the Gimp##28760
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Hargus the Gimp##28760 |goto 52.90,35.21 |q 12800
step
_Destroy These Items:_
|tip They are no longer needed.
trash Crusader Skull##39328
step
Run through the tunnel |goto 49.08,28.31 < 20 |only if walking and not subzone("Browman Mill")
Follow the path down |goto 39.91,19.41 < 30 |only if walking and not subzone("Browman Mill")
talk Scourge Commander Thalanor##31082
|tip He walks around this area.
turnin The Lich King's Command##12800 |goto 33.99,30.36
accept The Light of Dawn##12801 |goto 33.99,30.36
step
talk Highlord Darion Mograine##29173
|tip If he's not here, then another player already started the battle.
|tip You may be able to join the battle.  Skip to the next step, try to do it, and see if it works.
|tip If you're unable to join the battle, skip back to this step and wait for Highlord Darion Mograine to respawn.
Tell him _"I am ready, Highlord.  Let the siege of Light's Hope begin!"_
|tip If he's here, but you can't choose this dialogue, then another player already did it.
|tip Now you just need to wait for the battle to start.
|tip The battle starts 5 minutes after someone initiates this dialogue with him.
Click Here Once the Battle Begins |confirm |c |goto 34.44,31.10 |q 12801
|tip Highlord Darion Mograine will start yelling when the battle is beginning.
step
Kill enemies around this area
|tip Follow your allies into battle and help them fight.
Watch the dialogue
Uncover The Light of Dawn |q 12801/1 |goto 38.79,38.34
step
talk Highlord Darion Mograine##29173
turnin The Light of Dawn##12801 |goto 39.11,39.16
accept Taking Back Acherus##13165 |goto 39.11,39.16
step
cast Death Gate##50977
|tip Click the purple portal that appears nearby.
Return to Acherus |complete subzone("Acherus: The Ebon Hold") |q 13165
step
talk Highlord Darion Mograine##29173
|tip On the bottom floor of the floating building.
turnin Taking Back Acherus##13165 |goto Eastern Plaguelands 83.44,49.46
accept The Battle For The Ebon Hold##13166 |goto Eastern Plaguelands 83.44,49.46
stickystart "Slay_Scourge_13166"
step
Walk onto the teleport pad to go to the upper floor |goto 83.19,48.90 < 7 |walk
kill Patchwerk##31099 |q 13166/1 |goto 81.99,46.37
|tip He looks like a larger abomination that walks around this area.
|tip On the upper floor of the floating building.
step
label "Slay_Scourge_13166"
Kill enemies around this area
|tip On the upper floor of the floating building. |notinsticky
Slay #10# Scourge |q 13166/2 |goto 81.99,46.37
step
Walk onto the teleport pad to go to the bottom floor |goto 83.28,49.12 < 7 |walk
talk Highlord Darion Mograine##31084
|tip On the bottom floor of the floating building.
turnin The Battle For The Ebon Hold##13166 |goto 83.44,49.46
accept Where Kings Walk##13188 |goto 83.44,49.46
step
clicknpc Portal to Stormwind##103186
|tip On the bottom floor of the floating building.
Teleport to Stormwind City |complete zone("Elwynn Forest") |goto 83.66,51.35 |q 13188
step
Enter Stormwind Keep |goto Stormwind City 80.60,37.89 < 15 |walk
talk King Varian Wrynn##29611
|tip Inside the building.
turnin Where Kings Walk##13188 |goto Stormwind City 79.99,38.47
]])
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Northrend (69-80)\\Howling Fjord (69-71)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Howling",
condition_suggested=function() return level >= 69 and level <= 71 and not completedq(11239) end,
next="Leveling Guides\\Northrend (69-80)\\Borean Tundra (70-71)",
},[[
step
talk Macalroy##23547
|tip He walks around this area.
accept Hell Has Frozen Over...##11228 |goto Howling Fjord 61.05,62.60
step
talk Vice Admiral Keller##23546
|tip He walks around this area.
turnin Hell Has Frozen Over...##11228 |goto 60.50,61.19
accept If Valgarde Falls...##11243 |goto 60.50,61.19
step
talk Torik##26901
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Torik##26901 |goto 60.10,61.30 |q 11243
step
Kill Dragonflayer enemies around this area
|tip They look like large humans and wolves.
|tip They continually attack near this location.
Slay #12# Dragonflayer Invaders |q 11243/1 |goto 58.93,59.60
step
talk Vice Admiral Keller##23546
|tip He walks around this area.
turnin If Valgarde Falls...##11243 |goto 60.50,61.19
accept Rescuing the Rescuers##11244 |goto 60.50,61.19
step
click Ceremonial Dragonflayer Harpoon##186565+
|tip They look like poles sticking out of the ground around this area.
Rescue #8# Valgarde Scouts |q 11244/1 |goto 58.40,56.21
step
talk Vice Admiral Keller##23546
|tip He walks around this area.
turnin Rescuing the Rescuers##11244 |goto 60.50,61.19
accept Prisoners of Wyrmskull##11255 |goto 60.50,61.19
step
talk Beltrand McSorf##23548
|tip He walks around this area.
accept The Human League##11273 |goto 60.17,61.03
step
talk Thoralius the Wise##23975
|tip He walks around this area.
accept Into the World of Spirits##11333 |goto 59.80,61.48
step
Enter the building |goto 58.62,62.94 < 10 |walk
talk Innkeeper Hazel Lagras##23731
|tip Inside the building.
home Valgarde |goto 58.39,62.45
step
Leave the building |goto 58.62,62.94 < 10 |walk |only if subzone("Valgarde") and _G.IsIndoors()
talk Pricilla Winterwind##23736
fpath Valgarde Port |goto 59.79,63.24
step
talk Guard Captain Zorek##23728
accept The Path to Payback##11420 |goto 60.12,62.43
step
click Reagent Pouch##186662
|tip Underwater, on the deck of the ship.
collect Reagent Pouch##6652 |q 11333/1 |goto 62.06,57.62
step
talk Thoralius the Wise##23975
|tip He walks around this area.
turnin Into the World of Spirits##11333 |goto 59.80,61.48
accept The Echo of Ymiron##11343 |goto 59.80,61.48
stickystart "Rescue_Captured_Valgarde_Prisoners"
step
Enter the building |goto 58.91,54.41 < 10 |walk
talk Pulroy the Archaeologist##24122
|tip Inside the building.
turnin The Human League##11273 |goto 59.18,54.57
accept Zedd's Probably Dead##11274 |goto 59.18,54.57
step
use the Incense Burner##33637
|tip Use it in the doorway of the building.
Enter the Spirit World |havebuff Echo of Ymiron##135867 |goto 60.25,51.33 |q 11343
step
Watch the dialogue
|tip Inside the building.
Uncover the Secrets of the Wyrmskull |q 11343/1 |goto 60.16,50.87
step
label "Rescue_Captured_Valgarde_Prisoners"
Kill Dragonflayer enemies around this area
collect Dragonflayer Cage Key##33308+ |n
click Dragonflayer Cages
|tip They look like metal cages on the ground and inside buildings around this area.
Rescue #3# Captured Valgarde Prisoners |q 11255/1 |goto 58.26,52.96
step
talk Vice Admiral Keller##23546
|tip He walks around this area.
turnin Prisoners of Wyrmskull##11255 |goto 60.47,61.13
accept Dragonflayer Battle Plans##11290 |goto 60.47,61.13
step
talk Torik##26901
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Torik##26901 |goto 60.10,61.30 |q 11290
step
talk Thoralius the Wise##23975
turnin The Echo of Ymiron##11343 |goto 59.80,61.48
accept Anguish of Nifflevar##11344 |goto 59.80,61.48
step
talk Zedd##24145
turnin Zedd's Probably Dead##11274 |goto 56.63,52.38
accept And Then There Were Two...##11276 |goto 56.63,52.38
step
Enter the cave |goto 56.24,52.72 < 15 |walk
click Dragonflayer Battle Plans##186618
|tip Inside the cave.
collect Dragonflayer Battle Plans##33488 |q 11290/1 |goto 55.68,52.58
step
Jump up the rocks and jump across to the gap near the bridge |goto 56.14,52.50 < 7 |only if walking and not subzone("Utgarde Catacombs")
Enter the cave and follow the spiral path down |goto 56.60,48.95 < 15 |walk |only if not subzone("Utgarde Catacombs")
talk Glorenfeld##24150
|tip Inside the cave, on the top level.
turnin And Then There Were Two...##11276 |goto 56.94,53.75
accept The Depths of Depravity##11277 |goto 56.94,53.75
stickystart "Collect_Wyrmskull_Tablets"
step
Follow the path |goto 57.13,55.67 < 10 |walk
click Harpoon Operation Manual##186828
|tip Inside the cave, on the top level.
collect Harpoon Operation Manual##34031 |q 11420/1 |goto 59.26,55.38
step
talk Ares the Oathbound##24189
|tip Inside the cave, on the top level.
accept The Shining Light##11288 |goto 59.34,55.42
step
Run down the stairs to the bottom level of the cave |goto 56.97,56.32 < 15 |walk
click Sacred Artifact##186607
|tip Downstairs inside the cave, on the bottom level.
|tip You can run through the ghouls, they won't attack you, since you have the "Shining Light" buff.
|tip HURRY, this quest is timed!
collect Sacred Artifact##33485 |q 11288/1 |goto 56.65,53.43
step
Run up the stairs to the top level of the cave |goto 57.06,56.85 < 15 |walk
talk Ares the Oathbound##24189
|tip Inside the cave, on the top level.
|tip HURRY, this quest is timed!
turnin The Shining Light##11288 |goto 59.34,55.42
accept Guided by Honor##11289 |goto 59.34,55.42
step
label "Collect_Wyrmskull_Tablets"
click Wyrmskull Tablet##186595
|tip They look like broken stone tablets laying on the ground all around inside this cave.
|tip They are only on the top and middle levels of the cave.
collect 10 Wyrmskull Tablet##33355 |q 11277/1 |goto 57.32,56.36
step
Follow the path |goto 57.14,55.75 < 10 |walk
talk Glorenfeld##24150
|tip Inside the cave, on the top level.
turnin The Depths of Depravity##11277 |goto 56.94,53.75
accept The Ring of Judgement##11299 |goto 56.94,53.75
step
Run down the stairs to the middle level of the cave |goto 56.98,56.32 < 15 |walk
talk Daegarn##24151
|tip Inside the cave, on the middle level.
turnin The Ring of Judgement##11299 |goto 55.70,57.37
accept Stunning Defeat at the Ring##11300 |goto 55.70,57.37
step
Kill the enemies that attack in waves
|tip Inside the cave, on the middle level.
kill Oluf the Violent##23931
click Ancient Cipher##186640
|tip It looks like a green stone block that appears on the ground after you kill Oluf the Violent.
collect Ancient Cipher##33545 |q 11300/1 |goto 55.02,57.49
step
Run up the stairs to the top level of the cave |goto 56.41,56.55 < 15 |walk
talk Glorenfeld##24150
|tip Inside the cave, on the top level.
turnin Stunning Defeat at the Ring##11300 |goto 56.94,53.75
accept Return to Valgarde##11278 |goto 56.94,53.75
step
use the Hearthstone##6948
Hearth to Valgarde |goto 58.39,62.51 < 30 |noway |c |q 11278
|only if subzone("Utgarde Catacombs")
step
talk Lord Irulon Trueblade##24191
turnin Guided by Honor##11289 |goto 59.74,62.43
step
talk Guard Captain Zorek##23728
turnin The Path to Payback##11420 |goto 60.11,62.43
accept Locating the Mechanism##11426 |goto 60.11,62.43
step
talk Vice Admiral Keller##23546
|tip He walks around this area.
turnin Dragonflayer Battle Plans##11290 |goto 60.47,61.07
accept To Westguard Keep!##11291 |goto 60.47,61.07
step
talk Beltrand McSorf##23548
|tip He walks around this area.
turnin Return to Valgarde##11278 |goto 60.18,61.03
accept The Explorers' League Outpost##11448 |goto 60.18,61.03
step
talk Torik##26901
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Torik##26901 |goto 60.10,61.30 |q 11448
step
kill Dragonflayer Harpooner##24635+
collect Harpoon Control Mechanism##34032 |q 11426/1 |goto 60.16,53.40
step
talk Guard Captain Zorek##23728
turnin Locating the Mechanism##11426 |goto 60.12,62.42
accept Meet Lieutenant Icehammer...##11427 |goto 60.12,62.42
step
talk Guard Captain Zorek##23728
Tell him _"Take me to Lieutenant Icehammer, Zorek!"_
Begin Flying to Lieutenant Icehammer |ontaxi |goto 60.12,62.42 |q 11427
step
Fly to Lieutenant Icehammer |offtaxi |goto 64.88,46.29 |q 11427 |notravel
step
talk Lieutenant Icehammer##24634
|tip Inside the building.
turnin Meet Lieutenant Icehammer...##11427 |goto 64.43,46.95
accept Drop It then Rock It!##11429 |goto 64.43,46.95
step
use the Alliance Banner##34051
Place the Alliance Banner |q 11429/1 |goto 64.89,40.10
step
Kill the enemies that attack in waves
Defend the Alliance Banner |q 11429/2 |goto 64.89,40.10
step
talk Lieutenant Icehammer##24634
|tip Inside the building.
turnin Drop It then Rock It!##11429 |goto 64.43,46.95
accept Harpoon Master Yavus##11430 |goto 64.43,46.95
step
Enter the building |goto 66.48,55.61 < 20 |walk
kill Harpoon Master Yavus##24644 |q 11430/1 |goto 65.15,56.58
|tip Inside the building.
step
use the Incense Burner##33774
Enter the Spirit World |havebuff Echo of Ymiron##135867 |goto 68.81,54.85 |q 11344
step
Watch the dialogue
Uncover the Secrets of Nifflevar |q 11344/1 |goto 68.81,54.85
step
talk Stanwad##24717
turnin The Explorers' League Outpost##11448 |goto 74.95,65.41
accept Problems on the High Bluff##11474 |goto 74.95,65.41
step
talk Everett McGill##26934
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Everett McGill##26934 |goto 75.00,65.19 |q 11474
step
talk Walt##24807
turnin Problems on the High Bluff##11474 |goto 75.05,65.51
accept Tools to Get the Job Done##11475 |goto 75.05,65.51
step
talk Hidalgo the Master Falconer##24750
accept Trust is Earned##11460 |goto 75.27,64.97
step
click Loose Rock##250424+
|tip They look like flat grey stones on the ground around this area.
collect Fjord Grub##34102 |q 11460 |goto 75.81,64.56
step
clicknpc Rock Falcon##24752
|tip Inside the cage.
Choose _<Feed the grub to the rock falcon.>_
Feed the Fjord Rock Falcon |q 11460/1 |goto 75.27,64.91
step
talk Hidalgo the Master Falconer##24750
turnin Trust is Earned##11460 |goto 75.27,64.97
accept The Ransacked Caravan##11465 |goto 75.27,64.97
step
talk Donny##24811
|tip On the wooden platform.
accept Out of My Element?##11477 |goto 78.81,48.87
stickystart "Kill_Iron_Rune_Laborers"
stickystart "Kill_Iron_Rune_Sages"
stickystart "Kill_Iron_Rune_Destroyers"
step
click Building Tools##186950
|tip On the wooden platform.
collect Building Tools##34131 |q 11475/1 |goto 79.00,47.56
step
label "Kill_Iron_Rune_Laborers"
kill 5 Iron Rune Laborer##23711 |q 11477/2 |goto 79.20,47.79
step
label "Kill_Iron_Rune_Sages"
kill 2 Iron Rune Sage##23674 |q 11477/3 |goto 79.20,47.79
step
label "Kill_Iron_Rune_Destroyers"
Follow the path up |goto 79.52,48.66 < 30 |only if walking
kill 10 Iron Rune Destroyer##23676 |q 11477/1 |goto 77.19,48.44
|tip There are many of them along the top of the cliff here. |notinsticky
step
talk Donny##24811
turnin Out of My Element?##11477 |goto 78.81,48.87
step
talk Everett McGill##26934
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Everett McGill##26934 |goto 75.00,65.19 |q 11475
step
talk Walt##24807
turnin Tools to Get the Job Done##11475 |goto 75.05,65.51
accept We Can Rebuild It##11483 |goto 75.05,65.51
accept We Have the Technology##11484 |goto 75.05,65.51
stickystart "Collect_Fjord_Grubs"
step
Kill Shoveltusk enemies around this area
collect Pristine Shoveltusk Hide##34136 |q 11484/1 |goto 70.96,64.09
step
label "Collect_Fjord_Grubs"
click Loose Rock##250424+
|tip They look like flat grey stones on the ground around this area.
collect 5 Fjord Grub##34102 |q 11465 |goto 75.51,65.77
You can find more around:
[75.51,65.76]
[75.54,66.77]
[74.46,66.32]
[75.96,67.46]
step
use the Trained Rock Falcon##34111
|tip Use it on Fjord Turkeys around this area.
|tip You will be attacked each time you capture a turkey.
collect 5 Fjord Turkey##34112 |q 11465/1 |goto 68.84,68.76
step
talk Lieutenant Icehammer##24634
|tip Inside the building.
turnin Harpoon Master Yavus##11430 |goto 64.43,46.95
accept It Goes to 11...##11421 |goto 64.43,46.95
stickystart "Collect_Steel_Ribbing"
step
click Industrial Strength Rope##186955
|tip Outside the building.
collect Industrial Strength Rope##34134 |q 11483/2 |goto 64.74,40.97
step
label "Collect_Steel_Ribbing"
Kill Winterskorn enemies around this area
collect Steel Ribbing##34137 |q 11484/2 |goto 65.17,40.23
step
click Large Barrel##186954
|tip Outside the building.
collect Large Barrel##34133 |q 11483/1 |goto 67.58,52.25
step
use the Harpoon Control Mechanism##34032
|tip Use it next to the big metal harpoon gun.
Control the Harpoon |invehicle |goto 64.77,52.67 |q 11421
stickystart "Kill_Dragonflayer_Defenders"
step
Destroy the Dragonflayer Longhouse |q 11421/2 |goto 64.8,52.7
|tip Use the Fiery Harpoon ability on your action bar.
|tip It's the building farthest to the left across the water.
step
Destroy the Dragonflayer Dockhouse |q 11421/3 |goto 64.8,52.7
|tip Use the Fiery Harpoon ability on your action bar.
|tip It's the middle building across the water.
step
Destroy the Dragonflayer Storage Facility |q 11421/4 |goto 64.8,52.7
|tip Use the Fiery Harpoon ability on your action bar.
|tip It's the building to the left across the water.
step
label "Kill_Dragonflayer_Defenders"
kill 8 Dragonflayer Defender##24533 |q 11421/1 |goto 64.8,52.7
|tip Use the Fiery Lance ability on your action bar on Dragonflayer Defenders.
|tip They will attack you after you destroy each building.
step
Stop Controlling the Harpoon |outvehicle |q 11421
|tip Click the yellow arrow on your action bar.
step
talk Lieutenant Icehammer##24634
|tip Inside the building.
turnin It Goes to 11...##11421 |goto 64.43,46.95
accept Let's Go Surfing Now##11436 |goto 64.43,46.95
step
click Large Harpoon Lever##186894
Go Harpoon Surfing |q 11436/1 |goto 65.23,57.20
step
talk Guard Captain Zorek##23728
turnin Let's Go Surfing Now##11436 |goto 60.12,62.43
step
talk Thoralius the Wise##23975
turnin Anguish of Nifflevar##11344 |goto 59.80,61.49
step
talk Torik##26901
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Torik##26901 |goto 60.10,61.30 |q 11448
step
talk McGoyver##24040
|tip He walks around this area.
Tell him _"Walt sent me to pick up some dark iron ingots."_
collect Dark Iron Ingots##34135 |q 11483/3 |goto 60.78,61.53
step
talk McGoyver##24040
|tip He walks around this area.
Tell him _"Official Explorers' League business, McGoyver. Take me to the Explorers' League Outpost!"_
Begin Flying to the Explorers' League Outpost |ontaxi |goto 60.77,61.52 |q 11483
step
Fly to the Explorers' League Outpost |offtaxi |goto 74.68,65.31 |q 11483
step
talk Walt##24807
turnin We Can Rebuild It##11483 |goto 75.05,65.51
turnin We Have the Technology##11484 |goto 75.05,65.51
accept Iron Rune Constructs and You: Rocket Jumping##11485 |goto 75.05,65.51
step
click Work Bench##186958
Choose _<Get on the work bench and let Walt put you in the golem suit.>_
Wear the Golem Suit |invehicle |goto 75.11,65.51 |q 11485
step
Master the Rocket Jump |q 11485/1 |goto 75.15,65.43
|tip Use the Rocket Jump ability on your action bar.
step
Stop Wearing the Golem Suit |outvehicle |q 11485
|tip Click the yellow arrow on your action bar.
step
talk Hidalgo the Master Falconer##24750
turnin The Ransacked Caravan##11465 |goto 75.27,64.97
accept Falcon Versus Hawk##11468 |goto 75.27,64.97
step
talk Walt##24807
turnin Iron Rune Constructs and You: Rocket Jumping##11485 |goto 75.05,65.51
accept Iron Rune Constructs and You: Collecting Data##11489 |goto 75.05,65.51
step
click Work Bench##186958
Choose _<Get on the work bench and let Walt put you in the golem suit.>_
Wear the Golem Suit |invehicle |goto 75.11,65.51 |q 11489
step
Collect Test Data |q 11489/1 |goto 74.81,65.74
|tip Use the Collect Data ability on your action bar next to the blue crystal.
step
Stop Wearing the Golem Suit |outvehicle |q 11489
|tip Click the yellow arrow on your action bar.
step
talk Walt##24807
turnin Iron Rune Constructs and You: Collecting Data##11489 |goto 75.05,65.51
accept Iron Rune Constructs and You: The Bluff##11491 |goto 75.05,65.51
step
click Work Bench##186958
Choose _<Get on the work bench and let Walt put you in the golem suit.>_
Wear the Golem Suit |invehicle |goto 75.11,65.51 |q 11491
step
Watch the dialogue
|tip Walk to this location and stand on the rug on the ground.
Bluff Lebronski |q 11491/1 |goto 74.8,65.3
|tip Use the Bluff ability on your action bar on Lebronski when he starts talking.
step
Stop Wearing the Golem Suit |outvehicle |q 11491
|tip Click the yellow arrow on your action bar.
step
talk Walt##24807
turnin Iron Rune Constructs and You: The Bluff##11491 |goto 75.05,65.51
accept Lightning Infused Relics##11494 |goto 75.05,65.51
accept The Delicate Sound of Thunder##11495 |goto 75.05,65.51
step
click Work Bench##186958
Choose _<Get on the work bench and let Walt put you in the golem suit.>_
Wear the Golem Suit |invehicle |goto 75.11,65.51 |q 11494
stickystart "Collect_Iron_Rune_Data"
step
Follow the path down into Bael'gun's Excavation Site |goto 72.71,67.68 < 30 |walk
Rocket Jump on the Middle Rune |goto 72.12,70.39
|tip On the wooden platform.
|tip Use the Rocket Jump ability on your action bar on the middle rune on the ground.
Rocket Jump to the Lower Level |goto 74.33,70.82 < 15 |noway |c |q 11495
step
Enter the cave |goto 73.40,70.47 < 15 |walk
Watch the dialogue
|tip Inside the cave.
|tip This quest seems a little buggy.
|tip Run around this small area inside the cave, trying every spot, until the dialogue starts.
Investigate the Thundering Cave |q 11495/1 |goto 71.56,69.37
step
label "Collect_Iron_Rune_Data"
Follow the path up toward the cave exit |goto 71.25,69.83 < 10 |walk |only if subzone("Bael'gun's Excavation Site") and _G.IsIndoors()
Leave the cave |goto 71.45,72.38 < 15 |walk |only if subzone("Bael'gun's Excavation Site") and _G.IsIndoors()
Collect #15# Iron Rune Data |q 11494/1 |goto 73.46,73.05
|tip You can jump down to the ground in the golem suit without dying.
|tip Use the Collect Data ability on your action bar next to the blue crystals on the ground around this area.
|tip Use the Bluff ability on your action bar to get rid of any suspicious dwarves you encounter.
step
Rocket Jump on the Rune |goto 73.19,73.38
|tip On the wooden platform.
|tip Use the Rocket Jump ability on your action bar on the middle rune on the ground.
Return to the Top of the Excavation Site |goto 72.12,70.41 < 15 |noway |c |q 11494
step
Stop Wearing the Golem Suit |outvehicle |q 11494
|tip Get to a safe spot first.
|tip Click the yellow arrow on your action bar.
step
click Loose Rock##250424
|tip They look like grey stones on the ground around this area.
collect 10 Fjord Grub##34102 |q 11468 |goto 69.06,69.95
step
use the Trained Rock Falcon##34121
|tip Use it on Fjord Hawks around this area.
|tip Most of them are flying above you around this area.
collect 10 Fjord Hawk##34120 |q 11468/1 |goto 70.40,66.75
Hawks rest near the ground at these locations:
[73.89,56.55]
[70.89,63.23]
[74.21,59.52]
[68.04,63.88]
[68.59,68.71]
[69.30,72.19]
step
talk Hidalgo the Master Falconer##24750
turnin Falcon Versus Hawk##11468 |goto 75.27,64.97
accept There Exists No Honor Among Birds##11470 |goto 75.27,64.97
step
talk Everett McGill##26934
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Everett McGill##26934 |goto 75.00,65.19 |q 11470
step
talk Walt##24807
turnin Lightning Infused Relics##11494 |goto 75.05,65.51
turnin The Delicate Sound of Thunder##11495 |goto 75.05,65.51
accept News From the East##11501 |goto 75.05,65.51
step
use the Trained Rock Falcon##34124
Control a Trained Falcon Hawk |havebuff 132210 |goto 76.66,67.67 |q 11470
step
collect 8 Fjord Hawk Egg##34123 |q 11470/1 |goto 76.7,67.7
|tip Use the Scavenge ability on your action bar.
|tip Use it next to the big white eggs in bird nests on the side of the cliff in front of your character.
|tip If your falcon gets killed by eagles, use the Trained Rock Falcon item again next to the Vrykul Hawk Roost, to control another one.
step
Stop Controlling a Trained Falcon Hawk |nobuff 132210 |q 11470
|tip Right-click the "Hawk Hunting" buff near your minimap.
step
talk Hidalgo the Master Falconer##24750
turnin There Exists No Honor Among Birds##11470 |goto 75.27,64.97
step
talk Everett McGill##26934
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Everett McGill##26934 |goto 75.00,65.19 |q 11501
step
talk Walt##24807
Tell him _"I'm ready to go, Walt."_
Begin Flying to Westguard Keep |invehicle |goto 75.05,65.51 |q 11501
step
Fly to Westguard Keep |outvehicle |goto 30.84,42.82 |q 11501 |notravel
step
Enter the building |goto 30.90,41.91 < 10 |walk
talk Chef Kettleblack##23773
|tip Inside the building.
accept Shoveltusk Soup Again?##11155 |goto 31.17,40.84
step
Leave the building |goto 30.90,41.91 < 10 |walk |only if subzone("Westguard Inn")
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.00 < 10 |walk
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin To Westguard Keep!##11291 |goto 28.84,44.13
turnin News From the East##11501 |goto 28.84,44.13
accept The Clutches of Evil##11157 |goto 28.84,44.13
step
Leave the building |goto 29.61,44.00 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
talk Greer Orehammer##23859
fpath Westguard Keep |goto 31.26,43.98
step
Leave the Westguard Keep |goto 32.66,43.36 < 30 |only if walking and subzone("Westguard Keep")
talk Cannoneer Ely##23770
accept One Size Does Not Fit All##11190 |goto 33.98,43.80
stickystart "Collect_Shoveltusk_Meat"
step
click Westguard Cannonball##186427+
|tip They look like grey round rocks on the ground around this area.
collect 10 Westguard Cannonball##33123 |q 11190/1 |goto 36.09,42.94
You can find more around:
[35.61,43.79]
[36.69,45.48]
[36.12,44.57]
[34.95,41.41]
[35.55,40.59]
[36.70,40.61]
[37.89,43.93]
[38.32,44.68]
[35.10,47.96]
step
label "Collect_Shoveltusk_Meat"
Kill Shoveltusk enemies around this area
|tip They look like buffalo.
collect 6 Shoveltusk Meat##33120 |q 11155/1 |goto 35.82,42.81
stickystart "Destroy_Proto_Drake_Eggs"
stickystart "Kill_Proto_Whelps"
step
talk Ember Clutch Ancient##23870+
|tip They look like large trees that walks around this area.
accept Root Causes##11182 |goto 41.18,49.34
stickystart "Kill_Dragonflayer_Handlers"
step
Enter the building |goto 41.35,52.85 < 10 |walk
kill Skeld Drakeson##23940 |q 11182/2 |goto 41.46,52.35
|tip Inside the building.
step
label "Kill_Dragonflayer_Handlers"
kill 5 Dragonflayer Handler##23871 |q 11182/1 |goto 41.44,53.87
step
talk Ember Clutch Ancient##23870+
|tip They look like large trees that walks around this area.
turnin Root Causes##11182 |goto 41.18,49.34
step
label "Destroy_Proto_Drake_Eggs"
kill Proto-Drake Egg##23777+
|tip They look like large white eggs.
|tip You can find them all around the Ember Clutch area.
Destroy #15# Proto-Drake Eggs |q 11157/1 |goto 38.72,49.54
step
label "Kill_Proto_Whelps"
kill 15 Proto-Whelp##23688 |q 11157/2 |goto 38.72,49.54
step
talk Cannoneer Ely##23770
turnin One Size Does Not Fit All##11190 |goto 33.98,43.79
step
Enter the building |goto 30.90,41.91 < 10 |walk
talk Chef Kettleblack##23773
|tip Inside the building.
turnin Shoveltusk Soup Again?##11155 |goto 31.17,40.84
step
Leave the building |goto 30.90,41.91 < 10 |walk |only if subzone("Westguard Inn")
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11501
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.00 < 10 |walk
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin The Clutches of Evil##11157 |goto 28.84,44.13
accept Mage-Lieutenant Malister##11187 |goto 28.84,44.13
step
talk Mage-Lieutenant Malister##23888
|tip Upstairs inside the building.
turnin Mage-Lieutenant Malister##11187 |goto 28.94,44.19
accept Two Wrongs...##11188 |goto 28.94,44.19
step
Leave the building |goto 29.61,44.00 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
Leave the Westguard Keep |goto 32.66,43.36 < 30 |only if walking and subzone("Westguard Keep")
use Malister's Frost Wand##33119
|tip Use it on Proto-Drakes.
|tip They look like dragons flying in the sky around this area.
kill 3 Proto-Drake##23689 |q 11188/1 |goto 38.86,50.35
step
Enter Westguard Keep |goto 32.70,43.38 < 30 |only if walking and not subzone("Westguard Keep")
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.00 < 10 |walk
talk Mage-Lieutenant Malister##23888
|tip Upstairs inside the building.
turnin Two Wrongs...##11188 |goto 28.94,44.19
step
talk Captain Adams##23749
|tip He walks around this small area upstairs inside the building.
accept Report to Scout Knowles##11199 |goto 28.84,44.13
step
Leave the building |goto 29.61,44.00 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
talk Sapper Steelring##23976
accept Danger! Explosives!##11218 |goto 29.11,41.78
step
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11218
step
Leave the Westguard Keep |goto 32.66,43.36 < 30 |only if walking and subzone("Westguard Keep")
talk Lunk-tusk##25233
accept Orfus of Kamagua##11573 |goto 32.28,46.79
step
talk Orfus of Kamagua##23804
turnin Orfus of Kamagua##11573 |goto 40.29,60.25
accept The Dead Rise!##11504 |goto 40.29,60.25
step
talk Scout Knowles##23906
turnin Report to Scout Knowles##11199 |goto 44.47,57.59
accept Mission: Eternal Flame##11202 |goto 44.47,57.59
step
use the Ever-burning Torches##33164
Destroy the Southwest Plague Tank |q 11202/1 |goto 48.26,55.94
step
use the Ever-burning Torches##33164
Destroy the Northwest Plague Tank |q 11202/2 |goto 47.95,52.96
step
use the Ever-burning Torches##33164
|tip Up on the cliff.
|tip Follow the path on the outskirts of Halgrind.
Destroy the Northeast Plague Tank |q 11202/3 |goto 51.29,50.09
step
use the Ever-burning Torches##33164
|tip Up on the cliff.
|tip Follow the path on the outskirts of Halgrind.
Destroy the Southeast Plague Tank |q 11202/4 |goto 51.55,57.73
step
talk Scout Knowles##23906
turnin Mission: Eternal Flame##11202 |goto 44.47,57.59
accept Mission: Package Retrieval##11327 |goto 44.47,57.59
step
click Apothecary's Package##186679
collect Apothecary's Package##33620 |q 11327/1 |goto 50.75,53.89
step
Follow the path to leave Halgrind |goto 48.85,57.63 < 30 |only if walking and subzone("Halgrind")
talk Scout Knowles##23906
turnin Mission: Package Retrieval##11327 |goto 44.47,57.59
accept Mission: Forsaken Intel##11328 |goto 44.47,57.59
step
Avoid New Agamand |goto 50.27,69.64 < 150 |only if walking and not subzone("Shield Hill")
click Mound of Debris##187022
|tip It looks like a pile of dirt.
collect Fengir's Clue##34222 |q 11504/1 |goto 57.68,77.52
step
click Unlocked Chest##187023
|tip It looks like a small brown metal and wooden chest.
collect Rodin's Clue##34223 |q 11504/2 |goto 59.23,76.98
step
click Long Tail Feather##187026
|tip It looks like a blue feather.
collect Isuldof's Clue##34224 |q 11504/3 |goto 59.79,79.39
step
click Cannonball##187027
|tip It looks like a grey boulder.
collect Windan's Clue##34225 |q 11504/4 |goto 61.97,80.06
step
talk Orfus of Kamagua##23804
turnin The Dead Rise!##11504 |goto 40.29,60.25
accept Elder Atuik and Kamagua##11507 |goto 40.29,60.25
step
Ride the sky lift |goto Howling Fjord/0 40.07,60.19 < 10
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Elder Atuik and Kamagua##11507 |goto 25.02,56.97
accept Grezzix Spindlesnap##11508 |goto 25.02,56.97
accept Feeding the Survivors##11456 |goto 25.02,56.97
step
talk Kip Trawlskip##28197
fpath Kamagua |goto 24.66,57.77
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11456
step
kill Island Shoveltusk##24681+
|tip They look like buffalo.
|tip The grey wolves will kill nearby Shoveltusks, so kill those too, if you need to.
|tip You can find them all around the Isle of Spears area.
collect 6 Island Shoveltusk Meat##36776 |q 11456/1 |goto 30.53,60.03
You can find more around:
[29.21,58.55]
[27.24,63.61]
[28.62,64.69]
[32.64,66.28]
[36.38,53.29]
[29.16,66.53]
[30.95,62.43]
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Feeding the Survivors##11456 |goto 25.02,56.97
accept Arming Kamagua##11457 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11457
step
kill Frostwing Chimaera##24673+
|tip They look like blue and white two-headed dragons.
collect 3 Chimaera Horn##34101 |q 11457/1 |goto 28.12,54.71
You can find more around [27.52,67.05]
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Arming Kamagua##11457 |goto 25.02,56.97
accept Avenge Iskaal##11458 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11458
step
Enter the underground building |goto 25.34,59.35 < 10 |walk
talk Caregiver Iqniq##27148
|tip Inside the building.
home Kamagua |goto 25.39,59.85
step
talk Grezzix Spindlesnap##24643
|tip On the small boat.
turnin Grezzix Spindlesnap##11508 |goto 23.08,62.66
accept Street "Cred"##11509 |goto 23.08,62.66
step
talk Lou the Cabin Boy##24896
|tip On the small canoe.
Tell him _"I don't have time for chit-chat, Lou. Take me to Scalawag Point."_
Begin Traveling to Scalawag Point |invehicle |goto 23.10,62.58 |q 11509
step
Watch the dialogue
|tip You will eventually travel to this location.
Travel to Scalawag Point |outvehicle |goto 35.51,82.40 |q 11509 |notravel
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
turnin Street "Cred"##11509 |goto 35.09,80.94
accept "Scoodles"##11510 |goto 35.09,80.94
step
talk Handsome Terry##24537
accept Forgotten Treasure##11434 |goto 35.60,80.22
step
Board the ship |goto 37.21,78.96 < 10 |only if walking
talk Scuttle Frostprow##24784
accept Swabbin' Soap##11469 |goto 37.75,79.58
step
kill "Scoodles"##24899
|tip It looks like an orca that swims in the water around this area.
collect Sin'dorei Scrying Crystal##34235 |q 11510/1 |goto 38.85,84.12
step
use the Fish Bladder##34076
|tip This will allow you to breathe underwater for 3 minutes.
Gain Water Breathing |havebuff spell:44235 |q 11434
step
Swim through the small window underwater |goto 38.15,84.45 < 7 |walk
click Eagle Figurine##186886
|tip It looks like a small grey and blue stone bird statue.
|tip Underwater, inside the ship.
collect Eagle Figurine##34070 |q 11434/2 |goto 37.77,84.62
step
click Amani Vase##186885
|tip It looks like a grey stone jar.
|tip Underwater, inside the broken boat.
collect Amani Vase##34069 |q 11434/1 |goto 37.15,85.49
step
talk Handsome Terry##24537
turnin Forgotten Treasure##11434 |goto 35.60,80.22
accept The Fragrance of Money##11455 |goto 35.60,80.22
step
talk Taruk##24541
accept Gambling Debt##11464 |goto 36.32,80.48
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
turnin "Scoodles"##11510 |goto 35.09,80.94
accept The Staff of Storm's Fury##11511 |goto 35.09,80.94
accept The Frozen Heart of Isuldof##11512 |goto 35.09,80.94
accept The Lost Shield of the Aesirites##11519 |goto 35.09,80.94
accept The Ancient Armor of the Kvaldir##11567 |goto 35.09,80.94
step
talk "Silvermoon" Harry##24539
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor "Silvermoon" Harry##24539 |goto 35.09,80.94 |q 11511
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
Tell him _"Taruk sent me to collect what you owe."_
kill "Silvermoon" Harry##24539
|tip Don't kill him, just get him to low health.
|tip You will eventually be able to talk to him again.
talk "Silvermoon" Harry##24539
Tell him _"Pay up, Harry!"_
collect "Silvermoon" Harry's Debt##34115 |q 11464/1 |goto 35.09,80.94
step
talk Taruk##24541
turnin Gambling Debt##11464 |goto 36.32,80.48
accept Jack Likes His Drink##11466 |goto 36.32,80.48
step
Enter the building |goto 35.28,80.22 < 10 |walk
talk Olga, the Scalawag Wench##24639
|tip Inside the building.
Tell her _"I'd like to buy Jack a drink. Perhaps something... extra strong."_
Click Here After You Buy Jack Adams a Drink |confirm |goto 35.31,79.59 |q 11466
step
Watch the dialogue
|tip Jack Adams will pass out on the table.
|tip Inside the building.
talk Jack Adams##24788
Choose _<Discreetly search the pirate's pockets for Taruk's payment.>_
collect Jack Adams' Debt##34116 |q 11466/1 |goto 35.49,79.38
step
Leave the building |goto 35.28,80.22 < 10 |walk |only if subzone("Scalawag Point") and _G.IsIndoors()
talk Taruk##24541
turnin Jack Likes His Drink##11466 |goto 36.32,80.48
accept Dead Man's Debt##11467 |goto 36.32,80.48
step
Follow the road to leave Scalawag Point |goto 36.51,77.46 < 40 |only if walking and subzone("Scalawag Point")
kill Rabid Brown Bear##24633+
|tip They look like brown bears.
|tip You can find them all around the Garvan's Reef area.
collect 4 Bear Musk##34084 |q 11455/1 |goto 34.09,77.91
step
kill Big Roy##24785
|tip He looks like a big seal that swims in the water around this area.
collect Big Roy's Blubber##34122 |q 11469/1 |goto 31.40,78.62
step
talk Handsome Terry##24537
turnin The Fragrance of Money##11455 |goto 35.60,80.22
accept A Traitor Among Us##11473 |goto 35.60,80.22
step
talk Zeh'gehn##24525
turnin A Traitor Among Us##11473 |goto 35.56,80.63
accept Zeh'gehn Sez##11459 |goto 35.56,80.63
step
talk Handsome Terry##24537
turnin Zeh'gehn Sez##11459 |goto 35.60,80.22
accept A Carver and a Croaker##11476 |goto 35.60,80.22
step
talk "Silvermoon" Harry##24539
|tip Inside the tent.
buy Shiny Knife##35813 |n
collect Shiny Knife##35813 |q 11476/2 |goto 35.1,80.9
step
talk "Silvermoon" Harry##24539
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor "Silvermoon" Harry##24539 |goto 35.09,80.94 |q 11476
step
clicknpc Scalawag Frog##26503
|tip They look like blue and green frogs that hop around on the ground around this area.
collect Scalawag Frog##35803 |q 11476/1 |goto 35.56,81.81
step
talk Zeh'gehn##24525
turnin A Carver and a Croaker##11476 |goto 35.56,80.63
step
Watch the dialogue
talk Zeh'gehn##24525
accept "Crowleg" Dan##11479 |goto 35.56,80.63
step
Board the ship |goto 35.85,82.26 < 10 |only if walking
talk "Crowleg" Dan##24713
Tell him _"Ummm... the frog says you're a traitor, "matey.""_
kill "Crowleg" Dan##24713 |q 11479/1 |goto 35.95,83.60
step
talk Handsome Terry##24537
turnin "Crowleg" Dan##11479 |goto 35.60,80.22
accept Meet Number Two##11480 |goto 35.60,80.22
step
Enter the building |goto 35.27,80.21 < 10 |walk
talk Annie Bonn##24741
|tip She walks around this area.
|tip Upstairs inside the building.
turnin Meet Number Two##11480 |goto 35.44,79.42
accept The Jig is Up##11471 |goto 35.44,79.42
step
Leave the building |goto 35.27,80.21 < 10 |walk |only if subzone("Scalawag Point") and _G.IsIndoors()
Board the ship |goto 37.21,78.96 < 10 |only if walking
talk Scuttle Frostprow##24784
turnin Swabbin' Soap##11469 |goto 37.75,79.58
step
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
|tip Board the ship when it stops at this location.
turnin The Lost Shield of the Aesirites##11519 |goto 37.85,74.79
accept Mutiny on the Mercy##11527 |goto 37.85,74.79
step
_Downstairs Inside the Ship:_
kill Mutinous Sea Dog##25026+
|tip Downstairs, on the bottom deck, inside the pirate ship that sails around this area.
collect 5 Barrel of Blasting Powder##34387 |q 11527/1
step
_On the Ship Desk:_
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
turnin Mutiny on the Mercy##11527
accept Sorlof's Booty##11529
step
clicknpc The Big Gun##24992
|tip At the front of the ship, on the top deck of the pirate ship that sails around this area.
|tip Keep clicking it repeatedly until Sorlof is dead on the shore.
kill Sorlof##24914
|tip He looks like a large tree that walks along the shore around this area.
click Sorlof's Booty##187238
|tip It looks like a yellow pile of gold that appears on the ground after Sorlof dies.
|tip Jump off the ship to loot it.
collect Sorlof's Booty##34468 |q 11529/1
step
Enter the cave |goto 33.57,75.64 < 10 |walk
kill "Mad" Jonah Sterling##24742
|tip He looks like a human wearing a red coat.
|tip He walks around this small area inside the cave.
|tip He eventually runs away and gets eaten by a large white bear on the bottom level of the cave.
|tip He is a level 70 elite enemy, but you should be able to kill him at this level.
|tip If you have trouble, try to find someone to help you, or skip the quest.
Click Here After Killing "Mad" Jonah Sterling |confirm |goto 33.78,78.02 |q 11471
step
kill Hozzer##24547
|tip He looks like a large white bear.
|tip Downstairs inside the cave.
|tip He is a level 71 elite enemy, but you should be able to kill him at this level.
|tip If you have trouble, try to find someone to help you, or skip the quest.
collect Jonah Sterling's Spyglass##34128 |q 11471/1 |goto 33.39,78.30
step
Follow the path up |goto 32.99,78.18 < 10 |walk
click The Frozen Heart of Isuldof##187032
|tip Downstairs inside the cave.
collect The Frozen Heart of Isuldof##34237 |q 11512/1 |goto 32.34,78.68
step
Follow the path back up and leave the cave |goto 33.57,75.64 < 10 |walk |only if subzone("Garvan's Reef") and _G.IsIndoors()
Follow the path up |goto 28.85,60.99 < 30 |only if walking
Cross the hanging bridge |goto 29.83,60.87 < 10 |only if walking
click Dirt Mound##186944
|tip If another player interacted with it recently, you may have to wait for it to respawn.
Watch the dialogue
Kill the enemies that attack
kill Black Conrad's Ghost##24790
collect Black Conrad's Treasure##34118 |q 11467/1 |goto 32.69,60.21
step
kill 8 Crazed Northsea Slaver##24676 |q 11458/1 |goto 33.71,63.84
step
Board the ship while being careful to avoid Abdul the Insane |goto 34.94,63.68 < 10 |only if walking
Wait for Adbul the Insane to walk to the top deck of the ship, then enter the ship here |goto 35.39,64.68 < 7 |walk
click The Staff of Storm's Fury##187033
|tip Downstairs inside the ship, on the bottom level.
collect The Staff of Storm's Fury##34236 |q 11511/1 |goto 35.26,64.84
step
use the Hearthstone##6948
Hearth to Kamagua |complete subzone("Kamagua") |q 11511
|only if subzone("Iskaal")
step
Enter the building |goto 25.09,57.20 < 15 |walk
talk Elder Atuik##24755
|tip Inside the building.
turnin Avenge Iskaal##11458 |goto 25.02,56.97
step
talk Deniigi##27151
|tip In the doorway of the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Deniigi##27151 |goto 25.65,57.44 |q 11511
step
talk Anuniaq##24810
accept Travel to Moa'ki Harbor##12117 |goto 24.59,58.86 |or
accept Travel to Moa'ki Harbor##12118 |goto 24.59,58.86 |or
|tip These will not be available if you have quested in Dragonblight or have quests in your log from the zone.
Click Here to Continue |confirm
step
talk Lou the Cabin Boy##24896
|tip On the small canoe.
Tell him _"I don't have time for chit-chat, Lou. Take me to Scalawag Point."_
Begin Traveling to Scalawag Point |ontaxi |goto 23.10,62.58 |q 11471
step
talk Taruk##24541
turnin Dead Man's Debt##11467 |goto 36.32,80.48
step
Enter the building |goto 35.27,80.21 < 10 |walk
talk Annie Bonn##24741
|tip Upstairs inside the building.
turnin The Jig is Up##11471 |goto 35.41,79.43
step
talk Alanya##27933
Tell her _"Harry said I could take his bomber to Bael'gun's. I'm ready to go!"_
Begin Flying to Bael'gun's |invehicle |goto 36.09,81.60 |q 11567
step
Fly to Bael'gun's |outvehicle |goto 80.87,75.10 |q 11567 |notravel
step
Enter the ship |goto 82.26,74.77 < 10 |walk
click The Ancient Armor of the Kvaldir##187381
|tip It looks like a floating metal chest armor.
|tip Downstairs inside the ship.
collect The Ancient Armor of the Kvaldir##34239 |q 11567/1 |goto 81.78,73.91
step
clicknpc Harry's Bomber##28277
Choose _<Get in the bomber and return to Scalawag Point.>_
Begin Flying Back to Scalawag Point |invehicle |goto 80.89,75.10 |q 11567 |or
step
Return to Scalawag Point |outvehicle |goto 36.07,81.68 |q 11567 |notravel
step
talk Captain Ellis##24910
|tip He's on the top deck of a pirate ship that sails around this area.
|tip Board the ship when it stops at this location.
turnin Sorlof's Booty##11529 |goto 37.85,74.79
accept The Shield of the Aesirites##11530 |goto 37.85,74.79
step
Ride the lift up |goto 42.07,67.71 < 15 |only if walking and (subzone("Scalawag Point") or subzone("Garvan's Reef") or subzone("Sorlof's Strand"))
talk Orfus of Kamagua##23804
turnin The Shield of the Aesirites##11530 |goto 40.29,60.25
turnin The Staff of Storm's Fury##11511 |goto 40.29,60.25
turnin The Frozen Heart of Isuldof##11512 |goto 40.29,60.25
turnin The Ancient Armor of the Kvaldir##11567 |goto 40.29,60.25
accept A Return to Resting##11568 |goto 40.29,60.25
step
use the Bundle of Vrykul Artifacts##34624
Return the Shield of Aesirites |q 11568/1 |goto 57.64,77.41
step
use the Bundle of Vrykul Artifacts##34624
Return the Staff of Storm's Fury |q 11568/2 |goto 59.30,77.20
step
use the Bundle of Vrykul Artifacts##34624
Return the Frozen Heart of Isuldof |q 11568/3 |goto 59.78,79.40
step
use the Bundle of Vrykul Artifacts##34624
Return the Ancient Armor of the Kvaldir |q 11568/4 |goto 61.89,80.14
step
talk Orfus of Kamagua##23804
turnin A Return to Resting##11568 |goto 40.29,60.25
accept Return to Atuik##11572 |goto 40.29,60.25
step
Ride the lift |goto Howling Fjord/0 40.07,60.19 < 10
talk Elder Atuik##24755
|tip Inside the building.
turnin Return to Atuik##11572 |goto 25.02,56.97
step
talk Tipvigut##27145
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tipvigut##27145 |goto 24.87,57.70 |q 11218
step
Enter the building |goto 30.90,41.91 < 10 |walk
talk Peppy Wrongnozzle##24283
|tip Inside the building.
turnin Mission: Forsaken Intel##11328 |goto 30.77,41.61
accept Absholutely... Thish Will Work!##11330 |goto 30.77,41.61
step
Leave the building |goto 30.90,41.91 < 10 |walk |only if subzone("Westguard Inn")
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11330
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Click the Gate to open it and run down the stairs |goto 29.39,44.03 < 10 |walk
use Peppy's Special Mix##33627
|tip Use it on the Dragonflayer Vrykul Prisoner.
|tip Downstairs inside the building.
Administer Peppy's Mix to the Vrykul Prisoner |q 11330/1 |goto 29.46,43.40
step
Run up the stairs and leave the building |goto 29.18,43.75 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
Enter the building |goto 30.90,41.91 < 10 |walk
talk Peppy Wrongnozzle##24283
|tip Inside the building.
turnin Absholutely... Thish Will Work!##11330 |goto 30.77,41.61
accept You Tell Him ...Hic!##11331 |goto 30.77,41.61
step
talk Innkeeper Celeste Goodhutch##23937
|tip Inside the building.
home Westguard Inn |goto 30.86,41.45
step
Leave the building |goto 30.90,41.91 < 10 |walk |only if subzone("Westguard Inn")
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.01 < 10 |walk
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin You Tell Him ...Hic!##11331 |goto 28.84,44.13
accept Mission: Plague This!##11332 |goto 28.84,44.13
step
Leave the building |goto 29.61,44.01 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
talk Greer Orehammer##23859
Tell him _"Greer, I need a gryphon to ride and some bombs to drop on New Agamand!"_
Begin Flying on the Bombing Mission |ontaxi |goto 31.26,43.98 |q 11332
step
use Orehammer's Precision Bombs##33634
|tip Use them on Plague Tanks as you fly.
|tip They look like large green carts on the ground around New Agamand.
Hit #5# Plague Tanks |q 11332/1 |goto 52.43,68.08 |notravel
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.01 < 10 |walk
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin Mission: Plague This!##11332 |goto 28.84,44.13
accept Operation: Skornful Wrath##11248 |goto 28.84,44.13
step
Leave the building |goto 29.61,44.01 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
talk Quartermaster Brevin##24494
accept Everything Must Be Ready##11406 |goto 30.63,42.79
step
talk Explorer Abigail##23978
accept Send Them Packing##11224 |goto 31.62,41.50
step
Cross the bridge |goto 32.16,38.78 < 20 |only if walking and (subzone("Westguard Keep") or subzone("Whisper Gulch"))
talk Watcher Moonleaf##24273
|tip On the wooden platform.
accept The Cleansing##11322 |goto 30.06,28.59
step
talk Engineer Feknut##24227
|tip He walks around this area.
|tip On the wooden platform.
accept Scare the Guano Out of Them!##11154 |goto 30.16,28.77
step
talk Overseer Irena Stonemantle##23891
|tip On the wooden platform.
accept See to the Operations##11176 |goto 30.28,28.64
accept Where is Explorer Jaren?##11393 |goto 30.28,28.64
step
talk Steel Gate Chief Archaeologist##24399
turnin See to the Operations##11176 |goto 30.81,28.56
accept I've Got a Flying Machine!##11390 |goto 30.81,28.56
step
clicknpc Steel Gate Flying Machine##24418
Borrow the Steel Gate Flying Machine |invehicle |goto 30.88,28.19 |q 11390
step
Deliver #3# Sacks of Relics |q 11390/1 |goto 30.86,26.43
|tip Use the Grappling Hook ability on your action bar near Sacks of Relics on the ground.
|tip They look like huge white bags with yellow stuff in them on the ground around this area.
Deliver the Sacks of Relics to [30.74,27.75]
|tip Bring them up onto the hanging wooden scale above the dig site.
step
Stop Flying in the Steel Gate Flying Machine |outvehicle |goto 30.89,28.46 |q 11390
|tip Click the yellow arrow on your action bar.
step
talk Steel Gate Chief Archaeologist##24399
turnin I've Got a Flying Machine!##11390 |goto 30.81,28.56
accept Steel Gate Patrol##11391 |goto 30.81,28.56
step
_NOTE:_
Check For Gjalerbron Gargoyles
|tip Make sure there are gargoyles flying above the Steel Gate dig site nearby.
|tip They only appear when an event happens.
|tip If they are not there, you can't complete the "Steel Gate Patrol" quest.
|tip You can either wait for them to appear, or abandon the quest and skip it.
Click Here to Continue |confirm |q 11391
step
clicknpc Steel Gate Flying Machine##24418
Borrow the Steel Gate Flying Machine |invehicle |goto 30.88,28.19 |q 11391
step
kill 8 Gjalerbron Gargoyle##24440 |q 11391/1 |goto 30.86,26.43
|tip Use the abilities on your action bar.
|tip If they're not appearing, try to fly down closer to the ground inside the quarry.
|tip They appear as red dots on your minimap.
step
Stop Flying in the Steel Gate Flying Machine |outvehicle |goto 30.89,28.46 |q 11391
|tip Click the yellow arrow on your action bar.
step
talk Steel Gate Chief Archaeologist##24399
turnin Steel Gate Patrol##11391 |goto 30.81,28.56
stickystart "Collect_Whisper_Gulch_Gems"
stickystart "Send_Abandoned_Pack_Mules_Packing"
step
Follow the path down into Whisper Gulch |goto 33.83,33.80 < 30 |only if walking and not subzone("Whisper Gulch")
use Steelring's Foolproof Dynamite##33190
|tip Use it on Whisper Gulch Ore.
|tip They look like large dark colored mining nodes on the ground around this area in the canyon.
click Whisper Gulch Ore Fragment##186468+
|tip They appear after you use Steelring's Foolproof Dynamite on a mining node.
collect 6 Whisper Gulch Ore Fragment##33188 |q 11218/1 |goto 33.87,37.98
step
label "Collect_Whisper_Gulch_Gems"
use Steelring's Foolproof Dynamite##33190
|tip Use it on Whisper Gulch Ore.
|tip They look like large dark colored mining nodes on the ground around this area in the canyon.
click Whisper Gulch Gem##186467
|tip They appear after you use Steelring's Foolproof Dynamite on a mining node.
collect 18 Whisper Gulch Gem##33187 |q 11218/2 |goto 33.87,37.98
step
label "Send_Abandoned_Pack_Mules_Packing"
Perform the "Raise" Emote |script DoEmote("RAISE")
|tip Perform it on Abandoned Pack Mules around this area in the canyon.
|tip They look like donkeys with a bunch of supplies tied to them around this area in the canyon.
Send #10# Abandoned Pack Mules Packing |q 11224/1 |goto 33.5,36.1
step
Jump down carefully to leave Whisper Gulch |goto 30.36,36.55 < 10 |only if walking and subzone("Whisper Gulch")
Follow the shore to leave Whisper Gulch |goto 28.39,38.00 < 40 |only if walking and subzone("Whisper Gulch")
talk Explorer Jaren##23833
turnin Where is Explorer Jaren?##11393 |goto 24.25,32.46
accept And You Thought Murlocs Smelled Bad!##11394 |goto 24.25,32.46
stickystart "Kill_Chillmere_Coast_Scourge"
step
Kill enemies around this area
collect Scourge Device##33961 |n
use the Scourge Device##33961
accept It's a Scourge Device##11395 |goto 22.73,31.08
step
talk Explorer Jaren##23833
turnin It's a Scourge Device##11395 |goto 24.25,32.46
accept Bring Down Those Shields##11396 |goto 24.25,32.46
step
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11396/1 |goto 22.69,31.17 |count 1
step
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11396/1 |goto 21.91,28.78 |count 2
step
use the Scourging Crystal Controller##33960
|tip Use it near the Scourge Crystal.
|tip It looks like a large floating purple crystal.
kill Scourging Crystal##24464
|tip Attack the crystal when the purple bubble shield disappears.
|tip If you have a pet, make you you get the killing blow, not your pet, or you won't get credit.
Destroy the Scourging Crystal |q 11396/1 |goto 21.51,24.63 |count 3
step
talk Old Icefin##24544
accept Trident of the Son##11422 |goto 19.78,22.21
step
label "Kill_Chillmere_Coast_Scourge"
Kill enemies around this area
|tip You can find them all around the Chillmere Coast area.
Kill #15# Chillmere Coast Scourge |q 11394/1 |goto 21.50,25.10
step
kill Rotgill##24546
|tip He looks like a white murloc that walks along the coast around this area.
collect Rotgill's Trident##34035 |q 11422/1 |goto 22.89,33.81
step
talk Explorer Jaren##23833
turnin And You Thought Murlocs Smelled Bad!##11394 |goto 24.25,32.46
turnin Bring Down Those Shields##11396 |goto 24.25,32.46
step
talk Old Icefin##24544
turnin Trident of the Son##11422 |goto 19.78,22.21
step
use the Hearthstone##6948
Hearth to Westguard Keep |complete subzone("Westguard Inn") |q 11218
|only if subzone("Chillmere Coast")
step
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11218
step
talk Sapper Steelring##23976
turnin Danger! Explosives!##11218 |goto 29.11,41.78
accept Leader of the Deranged##11240 |goto 29.11,41.78
step
talk Explorer Abigail##23978
turnin Send Them Packing##11224 |goto 31.62,41.50
step
Cross the bridge |goto 32.16,38.78 < 20 |only if walking and (subzone("Westguard Keep") or subzone("Whisper Gulch"))
Follow the path down into Whisper Gulch |goto 33.83,33.80 < 30 |only if walking
Enter the mine in Whisper Gulch |goto 31.35,35.38 < 20 |walk
kill Squeeg Idolhunter##24048 |q 11240/1 |goto 31.89,33.49
|tip He walks around this area inside the mine.
step
Jump onto the Ore Node |goto 31.58,33.26
|tip Inside the mine.
|tip Stand on this exact spot, on top of the ore node.
|tip Logout to your character selection screen, and then login with your character again.
|tip Logging out on this ore node will teleport you out of Whisper Gulch when you login again.
|tip You should be on the next step after logging back in.
Teleport Out of Whisper Gulch |goto 37.78,28.73 < 50 |noway |c |q 11240
|only if subzone("Whisper Gulch") and haveq(11240)
step
talk Christopher Sloan##24056
accept I'll Try Anything!##11329 |goto 60.27,18.69
step
click Water Plant##186661+
|tip They look like brown-ish green bushes on the ground underwater around this area.
kill Northern Barbfish##24285+
|tip Not all of them will contain Northern Barbfish.
collect 5 Northern Barbfish##33628 |q 11329/1 |goto 62.39,19.26
step
talk Christopher Sloan##24056
turnin I'll Try Anything!##11329 |goto 60.27,18.69
accept The One That Got Away##11410 |goto 60.27,18.69
step
talk Lieutenant Maeve##24282
accept The Enigmatic Frost Nymphs##11302 |goto 61.82,17.19
step
talk James Ormsby##24061
fpath Fort Wildervar |goto 60.06,16.11
step
talk Foreman Colbey##24176
accept The Yeti Next Door##11284 |goto 60.18,15.62
step
talk Eldrim Mounder##24052
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Eldrim Mounder##24052 |goto 61.01,17.08 |q 11284
step
talk Trapper Jethan##24131
accept Preying Upon the Weak##11292 |goto 62.66,16.80
step
talk Gil Grisert##24139
turnin Everything Must Be Ready##11406 |goto 62.59,16.81
accept Down to the Wire##11269 |goto 62.59,16.81
step
talk Prospector Belvar##24328
accept The Book of Runes##11346 |goto 62.27,17.22
step
use the Fresh Barbfish Bait##34013
|tip Use it next to the Sunken Boat underwater.
kill Frostfin##24500 |q 11410/1 |goto 63.92,19.57
stickystart "Collect_Book_Of_Runes_Chapter_2"
stickystart "Collect_Book_Of_Runes_Chapter_3"
stickystart "Collect_Spotted_Hippogryph_Down"
step
Kill Iron Rune enemies around this area
|tip They look like dwarves wearing dark colored armor.
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 1##33778 |goto 65.04,28.94 |q 11346
You can find more around [67.78,28.95]
step
label "Collect_Book_Of_Runes_Chapter_2"
Kill Iron Rune enemies around this area |notinsticky
|tip They look like dwarves wearing dark colored armor. |notinsticky
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 2##33779 |goto 65.04,28.94 |q 11346
You can find more around [67.78,28.95]
step
label "Collect_Book_Of_Runes_Chapter_3"
Kill Iron Rune enemies around this area |notinsticky
|tip They look like dwarves wearing dark colored armor. |notinsticky
|tip You can find them all around the Giant's Run area. |notinsticky
collect Book of Runes - Chapter 3##33780 |goto 65.04,28.94 |q 11346
You can find more around [67.78,28.95]
step
use the Book of Runes - Chapter 1##33778
collect The Book of Runes##33781 |q 11346/1
step
talk Lurielle##24117
turnin The Enigmatic Frost Nymphs##11302 |goto 61.48,22.86
accept Spirits of the Ice##11313 |goto 61.48,22.86
stickystop "Collect_Spotted_Hippogryph_Down"
step
kill Ice Elemental##23919+
|tip They look like small grey rock elementals.
|tip You can find them all around the Frozen Glade area.
collect 15 Icy Core##33605 |q 11313/1 |goto 60.85,22.08
step
talk Lurielle##24117
turnin Spirits of the Ice##11313 |goto 61.48,22.86
accept The Fallen Sisters##11314 |goto 61.48,22.86
accept Wild Vines##11315 |goto 61.48,22.86
stickystart "Collect_Spotted_Hippogryph_Down"
stickystart "Collect_Trapped_Prey"
stickystart "Kill_Scarlet_Ivy"
step
kill Chill Nymph##23678+
|tip Don't kill them, just weaken them to about half health.
use Lurielle's Pendant##33606
|tip Use it on weakened Chill Nymphs.
|tip They look like female centaurs.
|tip You can find them all around the Vibrant Glade area.
Free #7# Chill Nymphs |q 11314/1 |goto 51.57,27.61
step
label "Kill_Scarlet_Ivy"
kill 8 Scarlet Ivy##23763 |q 11315/1 |goto 51.57,27.61
|tip They look like large walking flowers.
|tip You can find them all around the Vibrant Glade area. |notinsticky
step
talk Lurielle##24117
turnin The Fallen Sisters##11314 |goto 61.48,22.86
turnin Wild Vines##11315 |goto 61.48,22.86
accept Spawn of the Twisted Glade##11316 |goto 61.48,22.86
accept Seeds of the Blacksouled Keepers##11319 |goto 61.48,22.86
stickystop "Collect_Spotted_Hippogryph_Down"
stickystop "Collect_Trapped_Prey"
step
talk Christopher Sloan##24056
turnin The One That Got Away##11410 |goto 60.27,18.69
step
talk Prospector Belvar##24328
turnin The Book of Runes##11346 |goto 62.28,17.21
accept Mastering the Runes##11349 |goto 62.28,17.21
step
Enter the building |goto 62.34,17.15 < 10 |walk
talk Helga Rumsbane##24053
|tip Inside the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Helga Rumsbane##24053 |goto 62.49,17.23 |q 11349
stickystart "Collect_Spotted_Hippogryph_Down"
stickystart "Collect_Trapped_Prey"
stickystart "Kill_Thornvine_Creepers"
step
kill Spore##23876+
|tip They look like orange spikey balls.
|tip You can find them all around the Twisted Glade area.
use the Enchanted Ice Core##33607
|tip Use it on their corpses.
Freeze #8# Spores |q 11319/1 |goto 54.05,17.75
step
label "Kill_Thornvine_Creepers"
kill 10 Thornvine Creeper##23874+ |q 11316/1 |goto 54.05,17.75
|tip They look like black and purple swmap elementals.
|tip You can find them all around the Twisted Glade area. |notinsticky
step
talk Lurielle##24117
turnin Spawn of the Twisted Glade##11316 |goto 61.48,22.86
turnin Seeds of the Blacksouled Keepers##11319 |goto 61.48,22.86
accept Keeper Witherleaf##11428 |goto 61.48,22.86
step
click Iron Rune Carving Tools##186684
|tip It looks like a small metal chest.
|tip It can spawn in multiple locations.
collect Iron Rune Carving Tools##33794 |q 11349/1 |goto 67.54,23.33
It can also be located at: |notinsticky
[72.40,17.80]
[69.10,22.80]
[67.50,29.20]
[71.20,28.70]
[73.30,24.89]
step
kill Keeper Witherleaf##24638 |q 11428/1 |goto 53.79,17.46
|tip He looks like a green and brown centaur that walks around this area.
step
label "Collect_Spotted_Hippogryph_Down"
click Spotted Hippogryph Down##186591+
|tip They look like brown feathers on the ground around this area.
|tip You can find them all around this area. |notinsticky
collect 10 Spotted Hippogryph Down##33348 |q 11269/1 |goto 52.80,18.98
step
label "Collect_Trapped_Prey"
click Sprung Trap##186619+
|tip They look like small animals stuck in silver metal traps on the ground around this area.
kill Prowling Worg##24206+
|tip They sometimes appear after you click the Sprung Traps.
collect 8 Trapped Prey##33487 |q 11292/1 |goto 52.80,18.98
step
kill Frosthorn Ram##23740+
collect 4 Tough Ram Meat##33352 |goto 56.96,15.74 |q 11284
You can find more around: |notinsticky
[52.58,10.15]
[50.97,3.19]
step
use the Tough Ram Meat##33352
collect Giant Yeti Meal##33477 |q 11284
step
Follow the path to the top of the mountain |goto 54.30,8.23 < 30 |only if walking
click Frostblade Shrine##186649
|tip At the top of the mountain.
Watch the dialogue
kill Your Inner Turmoil##27959
Become Cleansed of Your Inner Turmoil |q 11322/1 |goto 61.12,2.02
step
Jump off the mountain, float down, and enter the mine |goto 59.73,13.72 < 10 |walk
use the Giant Yeti Meal##33477
|tip Use it near Shatterhorn inside the mine.
|tip You can use it from decently far away.
|tip He will wake up and attack you.
kill Shatterhorn##24178	|q 11284/1 |goto 60.50,11.85
step
Leave the mine |goto 59.69,13.82 < 10 |walk |only if subzone("Wildervar Mine")
talk Foreman Colbey##24176
turnin The Yeti Next Door##11284 |goto 60.18,15.61
step
talk Eldrim Mounder##24052
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Eldrim Mounder##24052 |goto 61.01,17.08 |q 11284
step
talk Prospector Belvar##24328
turnin Mastering the Runes##11349 |goto 62.28,17.21
accept The Rune of Command##11348 |goto 62.28,17.21
step
talk Gil Grisert##24139
turnin Down to the Wire##11269 |goto 62.60,16.82
accept We Call Him Steelfeather##11418 |goto 62.60,16.82
step
talk Trapper Jethan##24131
turnin Preying Upon the Weak##11292 |goto 62.66,16.80
step
use the Feathered Charm##34026
|tip Use it on Steelfeather.
|tip She looks like a hippogryph flies in the sky above Fort Wildevar around this area.
|tip You can easily find and select Steelfeather by typing "/tar Steelfeather" into your chat.
Watch the dialogue
Learn Steelfeather's Secret |q 11418/1 |goto 62.66,16.80
step
talk Gil Grisert##24139
turnin We Call Him Steelfeather##11418 |goto 62.60,16.82
step
talk Lurielle##24117
turnin Keeper Witherleaf##11428 |goto 61.48,22.86
step
use the Rune of Command##33796
|tip Use it on a neutral Stone Giant around this area.
|tip It will not work on a Runed Stone Giant.
Test the Rune of Command |q 11348/1 |goto 70.41,23.92
step
kill Binder Murdis##24334 |q 11348/2 |goto 71.85,24.56
|tip Your Captive Stone Giant minion from the previous step will help you fight.
step
talk Prospector Belvar##24328
turnin The Rune of Command##11348 |goto 62.28,17.21
step
Enter the building |goto 62.34,17.15 < 10 |walk
talk Helga Rumsbane##24053
|tip Inside the building.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Helga Rumsbane##24053 |goto 62.49,17.23 |q 11349
step
Enter the building |goto 60.61,15.89 < 10 |walk
talk Christina Daniels##24057
|tip Inside the building.
home Fort Wildervar |goto 60.48,15.86
step
Enter the building |goto 30.90,41.91 < 10 |walk
talk Innkeeper Celeste Goodhutch##23937
|tip Inside the building.
home Westguard Inn |goto 30.86,41.45
step
talk Sapper Steelring##23976
turnin Leader of the Deranged##11240 |goto 29.11,41.78
step
Cross the bridge |goto 32.16,38.78 < 20 |only if walking and (subzone("Westguard Keep") or subzone("Whisper Gulch"))
talk Watcher Moonleaf##24273
|tip On the wooden platform.
turnin The Cleansing##11322 |goto 30.05,28.59
accept In Worg's Clothing##11325 |goto 30.05,28.59
step
use Feknut's Firecrackers##33129
|tip Use them on the ground near Darkclaw Bats.
|tip They look like bats that fly in the air around this area.
click Darkclaw Guano##186325+
|tip It appears on the ground after Feknut's Firecrackers.
collect 10 Darkclaw Guano##33084|q 11154/1 |goto 30.95,18.60
step
use the Worg Disguise##33618
Wear the Worg Disguise |havebuff spell:68347 |goto 29.21,7.56 |q 11325
step
Enter the cave |goto 29.30,6.01 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin In Worg's Clothing##11325 |goto 29.69,5.67
accept Brother Betrayers##11414 |goto 29.69,5.67
step
kill Bjomolf##24516 |q 11414/1 |goto 27.47,21.50
|tip He looks like a larger brown wolf that walks around this area.
step
talk Engineer Feknut##24227
|tip He walks around this area.
|tip On the wooden platform.
turnin Scare the Guano Out of Them!##11154 |goto 30.16,28.77
step
kill Varg##24517 |q 11414/2 |goto 34.12,30.42
|tip He looks like a larger grey wolf that walks around this area.
step
use the Worg Disguise##33618
Wear the Worg Disguise |havebuff spell:68347 |goto 29.21,7.56 |q 11414
step
Enter the cave |goto 29.30,6.01 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin Brother Betrayers##11414 |goto 29.69,5.67
accept Eyes of the Eagle##11416 |goto 29.69,5.67
step
use the Westguard Command Insignia##33311
talk Westguard Sergeant##24060
|tip He appears next to you.
turnin Operation: Skornful Wrath##11248 |goto 44.40,26.40
accept Towers of Certain Doom##11245 |goto 44.40,26.40
accept Gruesome, But Necessary##11246 |goto 44.40,26.40
accept Burn Skorn, Burn!##11247 |goto 44.40,26.40
stickystart "Dismember_Winterskorn_Vrykul"
stickystart "Accept_Stop_The_Ascension"
step
Enter the building |goto 43.73,28.31 < 10 |walk
use the Sergeant's Torch##33321
|tip Use it inside this building.
Set the Northwest Longhouse Ablaze |q 11247/1 |goto 43.66,28.57
step
use the Sergeant's Flare##33323
Target the Northwest Tower |q 11245/1 |goto 43.66,28.57
step
Enter the building |goto 46.18,28.36 < 10 |walk
use the Sergeant's Torch##33321
|tip Use it inside this building.
Set the Northeast Longhouse Ablaze |q 11247/2 |goto 46.33,28.21
step
Enter the building |goto 45.74,30.38 < 10 |walk
use the Sergeant's Torch##33321
|tip Use it inside this building.
Set the Barracks Ablaze |q 11247/3 |goto 45.93,30.71
step
_Next to you:_
use the Westguard Command Insignia##33311
talk Westguard Sergeant##24060
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Burn Skorn, Burn!##11247
step
Follow the path up |goto 44.90,32.14 < 30 |only if walking
use the Sergeant's Flare##33323
Target the East Tower |q 11245/2 |goto 46.44,33.21
step
use the Sergeant's Flare##33323
Target the Southeast Tower |q 11245/4 |goto 46.95,36.37
step
label "Accept_Stop_The_Ascension"
Kill Winterskorn enemies around this area
collect Vrykul Scroll of Ascension##33314 |n
use the Vrykul Scroll of Ascension##33314
accept Stop the Ascension!##11249 |goto 44.86,35.07
step
use the Vrykul Scroll of Ascension##33339
Watch the dialogue
|tip Halfdan the Ice-Hearted appears nearby.
kill Halfdan the Ice-Hearted##23671 |q 11249/1 |goto 44.86,35.07
step
label "Dismember_Winterskorn_Vrykul"
Kill Winterskorn enemies around this area
use The Sergeant's Machete##33310
|tip Use it on their corpses.
Dismember #20# Winterskorn Vrykul |q 11246/1 |goto 44.86,35.07
step
_Next to you:_
use the Westguard Command Insignia##33311
talk Westguard Sergeant##24060
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Gruesome, But Necessary##11246
step
use the Sergeant's Flare##33323
Target the Southwest Tower |q 11245/3 |goto 43.30,35.93
step
_Next to you:_
use the Westguard Command Insignia##33311
talk Westguard Sergeant##24060
|tip He should already be next to you.
|tip Use the item if he's not there.
turnin Towers of Certain Doom##11245
accept All Hail the Conqueror of Skorn!##11250
step
Jump down carefully |goto 43.39,36.77 < 10 |only if walking and subzone("Skorn")
click Talonshrike's Egg##190283
|tip At the bottom of the waterfall.
kill Talonshrike##24518
|tip It flies down to you.
collect Eyes of the Eagle##34027 |q 11416/1 |goto 41.46,37.69
step
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11250
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.01 < 10 |walk
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin All Hail the Conqueror of Skorn!##11250 |goto 28.84,44.13
accept Dealing With Gjalerbron##11235 |goto 28.84,44.13
step
talk Father Levariol##24038
|tip Upstairs inside the building.
turnin Stop the Ascension!##11249 |goto 28.86,43.98
accept Of Keys and Cages##11231 |goto 28.86,43.98
stickystart "Kill_Gjalerbron_Warriors"
stickystart "Kill_Gjalerbron_Rune_Casters"
stickystart "Kill_Gjalerbron_Sleep_Watchers"
stickystart "Accept_Gjalerbron_Attack_Plans"
step
Leave the building |goto 29.61,44.01 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
Cross the bridge |goto 32.16,38.78 < 20 |only if walking and (subzone("Westguard Keep") or subzone("Whisper Gulch"))
Kill Gjalerbron enemies around this area
|tip They look like large humans.
|tip You can find them all around the Gjalerbron area.
collect Gjalerbron Cage Key##33284+ |n
collect Large Gjalerbron Cage Key##33290 |n
|tip This key is rare to find.
|tip It can be used to open the Large Gjalerbron Cage at this location.
|tip The Large Gjalerbron Cage at this location contains multiple prisoners.
click Gjalerbron Cage+
|tip They look like wood and metal cages.
Free #10# Gjalerbron Prisoners |q 11231/1 |goto 35.80,11.46
step
label "Kill_Gjalerbron_Warriors"
kill 15 Gjalerbron Warrior##23991 |q 11235/1 |goto 35.37,11.30
|tip They look like large humans with an axe and a shield.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Kill_Gjalerbron_Rune_Casters"
kill 8 Gjalerbron Rune-Caster##23990 |q 11235/2 |goto 33.64,13.20
|tip They look like large humans wearing white robes.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Kill_Gjalerbron_Sleep_Watchers"
kill 8 Gjalerbron Sleep-Watcher##23989 |q 11235/3 |goto 35.37,11.30
|tip They look like large humans wearing brown robes.
|tip You can find them all around the Gjalerbron area. |notinsticky
step
label "Accept_Gjalerbron_Attack_Plans"
Kill Gjalerbron enemies around this area
|tip They look like large humans. |notinsticky
|tip You can find them all around the Gjalerbron area. |notinsticky
collect Gjalerbron Attack Plans##33289 |n
use the Gjalerbron Attack Plans##33289
accept Gjalerbron Attack Plans##11237 |goto 33.69,13.12
step
Leave Gjalerbron and run around the mountain |goto 31.39,13.03 < 70 |only if walking and subzone("Gjalerbron")
use the Worg Disguise##33618
Wear the Worg Disguise |havebuff spell:68347 |goto 29.21,7.56 |q 11416
step
Enter the cave |goto 29.33,5.97 < 15 |walk
talk Ulfang##24261
|tip Inside the small cave.
turnin Eyes of the Eagle##11416 |goto 29.69,5.67
accept Alpha Worg##11326 |goto 29.69,5.67
step
kill Garwal##24277 |q 11326/1 |goto 27.32,15.39
|tip He looks like a larger grey wolf that walks around this area.
step
talk Watcher Moonleaf##24273
turnin Alpha Worg##11326 |goto 30.05,28.59
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.01 < 10 |walk
talk Mage-Lieutenant Malister##23888
|tip Upstairs inside the building.
turnin Gjalerbron Attack Plans##11237 |goto 28.94,44.19
step
talk Captain Adams##23749
|tip He walks around this area.
|tip Upstairs inside the building.
turnin Dealing With Gjalerbron##11235 |goto 28.84,44.12
accept Necro Overlord Mezhen##11236 |goto 28.84,44.12
step
talk Father Levariol##24038
|tip Upstairs inside the building.
turnin Of Keys and Cages##11231 |goto 28.86,43.97
accept In Service to the Light##11239 |goto 28.86,43.97
step
talk Mage-Lieutenant Malister##23888
|tip Upstairs inside the building.
accept Sleeping Giants##11432 |goto 28.94,44.19
step
Leave the building |goto 29.61,44.01 < 10 |walk |only if subzone("Westguard Keep") and _G.IsIndoors()
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11432
stickystart "Kill_Deathless_Watchers"
stickystart "Collect_Awakening_Rods"
stickystart "Kill_Putrid_Wights"
step
Run up the ramp |goto 34.77,14.09 < 30 |only if walking
Follow the path up |goto 38.33,10.88 < 15 |only if walking
kill Necro Overlord Mezhen##24018 |q 11236/1 |goto 38.79,13.08
collect Mezhen's Writings##34090 |goto 38.79,13.08 |q 11452 |future
step
use Mezhen's Writings##34090
accept The Slumbering King##11452
step
Enter the building |goto 39.77,7.61 < 15 |walk
kill Queen Angerboda##24023 |q 11452/1 |goto 40.89,6.48
|tip Inside the building.
|tip Follow the path around inside the building to get to her.
step
label "Kill_Deathless_Watchers"
Leave the building |goto 39.77,7.61 < 15 |walk |only if subzone("Winter's Terrace")
kill 10 Deathless Watcher##24013 |q 11239/1 |goto 33.72,9.96
You can find more around: |notinsticky
[36.40,15.73]
[36.87,8.19]
step
label "Collect_Awakening_Rods"
kill Necrolord##24014+
collect 5 Awakening Rod##34083 |goto 38.50,12.53 |q 11432
You can find more around [33.25,9.33]
step
label "Kill_Putrid_Wights"
kill 2 Putrid Wight##23992 |q 11239/3 |goto 33.72,9.96
You can find more around: |notinsticky
[36.40,15.73]
[36.87,8.19]
stickystart "Kill_Fearsome_Horrors"
step
Enter the building |goto 34.43,13.16 < 15 |walk
use the Awakening Rod##34083+
|tip Use them on Dormant Vrykul.
|tip They look like vrykul sleeping upright inside the walls like mummies around this area inside the building.
kill 5 Dormant Vrykul##24669 |q 11432/1 |goto 35.12,11.70
step
label "Kill_Fearsome_Horrors"
kill 4 Fearsome Horror##24073 |q 11239/2 |goto 35.35,12.19
|tip Inside the building.
|tip They can be spread out in all of the rooms in this underground building.
step
talk Finlay Fletcher##23862
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Finlay Fletcher##23862 |goto 30.69,41.84 |q 11432
step
Enter the courtyard of the building |goto 29.91,43.27 < 15 |only if walking
Enter the building |goto 29.61,44.01 < 10 |walk
talk Mage-Lieutenant Malister##23888
|tip Upstairs inside the building.
turnin Sleeping Giants##11432 |goto 28.94,44.19
step
talk Captain Adams##23749
|tip He walks around this small area upstairs inside the building.
turnin Necro Overlord Mezhen##11236 |goto 28.84,44.12
turnin The Slumbering King##11452 |goto 28.84,44.12
step
talk Father Levariol##24038
|tip Upstairs inside the building.
turnin In Service to the Light##11239 |goto 28.86,43.97
]])
ZygorGuidesViewer:RegisterGuide("Leveling Guides\\Northrend (69-80)\\Borean Tundra (70-71)",{
author="support@zygorguides.com",
image=ZGV.IMAGESDIR.."Borean",
condition_suggested=function() return level >= 70 and level <= 72 and not completedq(11723) end,
next="Leveling Guides\\Northrend (69-80)\\Dragonblight (71-73)",
},[[
step
talk Tomas Riverwell##26879
fpath Valiance Keep |goto Borean Tundra 58.96,68.29
step
Enter the building |goto 58.53,68.34 < 10 |walk
talk James Deacon##25245
|tip Inside the building.
home Valiance Keep |goto 58.28,68.05
step
Leave the building |goto 58.53,68.34 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Recruitment Officer Blythe##25307
accept Enlistment Day##11672 |goto 57.85,67.60
step
talk Broff Bombast##27011
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Broff Bombast##27011 |goto 57.83,66.04 |q 11672
step
Enter the courtyard of the building |goto 56.96,70.88 < 15 |only if walking
Enter the building |goto 57.09,71.78 < 10 |walk
talk General Arlos##25250
|tip Upstairs inside the building.
turnin Enlistment Day##11672 |goto 56.67,72.64
accept A Time for Heroes##11727 |goto 56.67,72.64
step
Leave the building |goto 57.09,71.78 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Sergeant Hammerhill##25816
turnin A Time for Heroes##11727 |goto 56.36,69.58
accept The Siege##11797 |goto 56.36,69.58
step
talk Medic Hawthorn##25825
accept A Soldier in Need##11789 |goto 55.00,68.93
step
kill 6 Crypt Crawler##25227 |q 11797/1 |goto 53.20,70.58
step
talk Sergeant Hammerhill##25816
turnin The Siege##11797 |goto 56.36,69.58
accept Death From Above##11889 |goto 56.36,69.58
step
Enter the ship |goto 56.99,68.77 < 7 |walk
click First Aid Supplies##187980
|tip It's a small brown chest, downstairs in this ship, next to a candle shrine.
collect Hawthorn's Anti-Venom##35119 |q 11789/1 |goto 57.50,69.28
step
click Cultist Shrine##187851
|tip It looks like a small candle shrine on the ground downstairs in this ship, next to the wall.
accept Cultists Among Us##11920 |goto 57.55,69.13
step
talk Captain "Lefty" Lugsail##25298
|tip On the top deck of the ship.
turnin Cultists Among Us##11920 |goto 57.83,69.20
step
talk Admiral Cantlebree##25299
accept Notify Arlos##11791 |goto 57.79,69.19
step
Enter the courtyard of the building |goto 56.96,70.88 < 15 |only if walking
Enter the building |goto 57.09,71.78 < 10 |walk
talk General Arlos##25250
|tip Upstairs inside the building.
turnin Notify Arlos##11791 |goto 56.67,72.64
step
talk Counselor Talbot##25301
|tip Upstairs inside the building.
accept A Diplomatic Mission##12141 |goto 56.71,72.62
step
talk Harbinger Vurenn##25285
|tip Upstairs inside the building.
accept Enemies of the Light##11792 |goto 56.60,72.47
step
Leave the building |goto 57.09,71.78 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Medic Hawthorn##25825
turnin A Soldier in Need##11789 |goto 55.00,68.93
step
use the Reinforced Net##35278
|tip Use it on Scourged Flamespitters flying above you.
kill 6 Scourged Flamespitter##25582 |q 11889/1 |goto 54.77,70.41
step
talk Sergeant Hammerhill##25816
turnin Death From Above##11889 |goto 56.36,69.58
accept Plug the Sinkholes##11897 |goto 56.36,69.58
stickystart "Collect_Cultist_Communique"
step
use the Incendiary Explosives##35704
|tip Use it while standing on the edge of the sinkhole.
Set the Explosives at the Northern Sinkhole |q 11897/2 |goto 54.82,63.27
step
label "Collect_Cultist_Communique"
kill Cultist Necrolyte##25651+
collect Cultist Communique##35122 |q 11792/1 |goto 55.25,63.42
You can find more around: |notinsticky
[54.05,62.44]
[53.85,60.34]
step
use the Incendiary Explosives##35704
|tip Use it while standing on the edge of the sinkhole.
Set the Explosives at the Southern Sinkhole |q 11897/1 |goto 50.46,71.19
step
talk Karuk##25435
turnin A Diplomatic Mission##12141 |goto 47.13,75.48
accept Karuk's Oath##11613 |goto 47.13,75.48
stickystart "Kill_Skadir_Raiders"
stickystart "Kill_Skadir_Longboatsmen"
step
kill Riplash Myrmidon##24576
|tip Kill the cheering npc's nearby as well.
talk Captured Tuskarr Prisoner##25636
|tip Shortly after killing the attacking Myrmidon, he will have dialogue followed by a quest.
|tip The window to which you can accept the quest is short, so be ready.
|tip If he's not here, wait for him to respawn, or skip the quest.
|tip The quest becomes available to accept a few minutes after he spawns.
accept Cruelty of the Kvaldir##12471 |goto 44.09,77.90
step
label "Kill_Skadir_Raiders"
kill 6 Skadir Raider##25522 |q 11613/1 |goto 46.70,78.05
|tip They look like large green humans holding spears.
|tip You can find them all around the Riplash Strand area. |notinsticky
step
label "Kill_Skadir_Longboatsmen"
kill 5 Skadir Longboatsman##25521 |q 11613/2 |goto 46.70,78.05
|tip They look like large green humans holding wooden mallets.
|tip You can find them all around the Riplash Strand area. |notinsticky
step
talk Karuk##25435
turnin Karuk's Oath##11613 |goto 47.13,75.48
accept Gamel the Cruel##11619 |goto 47.13,75.48
turnin Cruelty of the Kvaldir##12471 |goto 47.13,75.48
step
Enter the cave |goto 46.15,79.32 < 20 |walk
kill Gamel the Cruel##26449 |q 11619/1 |goto 46.42,78.23
|tip Inside the small cave.
step
Leave the cave |goto 46.15,79.32 < 20 |walk |only if subzone("Riplash Strand") and _G.IsIndoors()
talk Karuk##25435
turnin Gamel the Cruel##11619 |goto 47.13,75.48
accept A Father's Words##11620 |goto 47.13,75.48
step
talk Veehja##25450
turnin A Father's Words##11620 |goto 43.61,80.52
step
use the Hearthstone##6948
Hearth to Valiance Keep |goto 58.35,68.09 < 50 |noway |c |q 11897
|only if (subzone("Shrine of Scales") or subzone("Riplash Strand"))
step
talk Broff Bombast##27011
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Broff Bombast##27011 |goto 57.83,66.04 |q 11897
step
Enter the courtyard of the building |goto 56.96,70.88 < 15 |only if walking
Enter the building |goto 57.09,71.78 < 10 |walk
talk Harbinger Vurenn##25285
|tip Upstairs inside the building.
turnin Enemies of the Light##11792 |goto 56.61,72.46
accept Further Investigation##11793 |goto 56.61,72.46
step
Leave the building |goto 57.09,71.78 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Sergeant Hammerhill##25816
turnin Plug the Sinkholes##11897 |goto 56.36,69.58
accept Farshire##11928 |goto 56.36,69.58
step
talk Mark Hanes##26155
accept Word on the Street##11927 |goto 56.77,69.51
step
Enter the building |goto 58.53,68.34 < 10 |walk
talk Midge##25249
|tip Inside the building.
accept Nick of Time##11575 |goto 58.41,67.79
step
talk Leryssa##25251
|tip Upstairs on the balcony of the building.
turnin Word on the Street##11927 |goto 58.75,68.36
accept Thassarian, My Brother##11599 |goto 58.75,68.36
step
talk Vindicator Yaala##25826
|tip Upstairs inside the building.
turnin Further Investigation##11793 |goto 58.55,67.31
accept The Hunt is On##11794 |goto 58.55,67.31
step
use the Oculus of the Exorcist##35125
|tip Use it on "Salty" John Thorpe.
talk "Salty" John Thorpe##25248
|tip Inside the building.
Tell him _"I have reason to believe you're involved in cultist activity."_
Watch the dialogue
kill "Salty" John Thorpe##25248
Defeat the Cultist in the Kitchen |q 11794/3 |goto 58.58,67.14
step
Leave the building |goto 58.53,68.34 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Airman Skyhopper##25737
accept Distress Call##11707 |goto 58.84,68.72
step
use the Oculus of the Exorcist##35125
|tip Use it on Tom Hegger.
talk Tom Hegger##25827
|tip He walks around this area.
Ask him _"What do you know about the Cult of the Damned?"_
Watch the dialogue
kill Tom Hegger##25827
Defeat the Cultist on the Docks |q 11794/1 |goto 59.21,68.39
step
Enter the courtyard of the building |goto 56.96,70.88 < 15 |only if walking
Run down the stairs |goto 56.85,72.16 < 10 |walk
use the Oculus of the Exorcist##35125
|tip Use it on Guard Mitchells.
talk Guard Mitchells##25828
|tip Downstairs inside the building.
Ask him _"How long have you worked for the Cult of the Damned?"_
Watch the dialogue
kill Guard Mitchells##25828
Defeat the Cultist in the Jail |q 11794/2 |goto 56.72,71.83
step
Leave the building |goto 56.96,70.88 < 15 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
Enter the building |goto 58.53,68.34 < 10 |walk
talk Vindicator Yaala##25826
|tip Upstairs inside the building.
turnin The Hunt is On##11794 |goto 58.55,67.30
step
Leave the building |goto 58.53,68.34 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
Run down the stairs to leave Valiance Keep |goto 57.50,65.79 < 20 |only if walking and subzone("Valiance Keep")
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin Farshire##11928 |goto 58.21,62.82
accept Military? What Military?##11901 |goto 58.21,62.82
step
Enter the mine |goto 56.66,57.41 < 10 |walk
click Plagued Grain##188085
|tip Inside the mine.
turnin Military? What Military?##11901 |goto 56.81,55.56
accept Pernicious Evidence##11902 |goto 56.81,55.56
step
Leave the mine |goto 56.66,57.41 < 10 |walk |only if subzone("Farshire Mine")
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin Pernicious Evidence##11902 |goto 58.21,62.82
accept It's Time for Action##11903 |goto 58.21,62.82
step
talk Wendy Darren##26085
accept Take No Chances##11913 |goto 58.28,62.77
step
talk Jeremiah Hawning##26084
accept Reference Material##11908 |goto 58.19,62.98
stickystart "Burn_Farshire_Grain"
stickystart "Kill_Plagued_Scavengers"
step
click Fields, Factories and Workshops##188120
|tip It looks like a small red book inside the burning building.
collect Fields, Factories and Workshops##35481|q 11908/1 |goto 55.75,58.32
step
label "Burn_Farshire_Grain"
use Wendy's Torch##35491
|tip Use it next to Farshire Grain.
|tip They look like bags with patches on the ground around this area.
Burn #8# Farshire Grain |q 11913/1 |goto 55.79,60.83
step
label "Kill_Plagued_Scavengers"
kill 14 Plagued Scavenger##25650 |q 11903/1 |goto 55.79,60.83
step
talk Wendy Darren##26085
turnin Take No Chances##11913 |goto 58.28,62.77
step
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin It's Time for Action##11903 |goto 58.22,62.82
accept Fruits of Our Labor##11904 |goto 58.22,62.82
step
talk Jeremiah Hawning##26084
turnin Reference Material##11908 |goto 58.19,62.98
accept Repurposed Technology##12035 |goto 58.19,62.98
step
kill Harvest Collector##25623+
use Jeremiah's Tools##35943
|tip Use it on their corpses.
Rewire #5# Harvest Collectors |q 12035/1 |goto 58.25,60.95
You can find more around [56.47,62.19]
step
Enter the mine |goto 56.66,57.41 < 10 |walk
clicknpc William Allerton##25385
|tip Inside the mine.
turnin Thassarian, My Brother##11599 |goto 56.05,55.42
accept The Late William Allerton##11600 |goto 56.05,55.42
step
kill Captain Jacobs##26252
|tip He walks around this area inside the mine.
collect Cart Release Key##35705 |goto 57.95,53.67 |q 11904
step
click Cart Release##188104
|tip Inside the mine.
Release the Ore Cart |q 11904/1 |goto 57.19,54.64
step
Leave the mine |goto 56.66,57.41 < 10 |walk |only if subzone("Farshire Mine")
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin Fruits of Our Labor##11904 |goto 58.22,62.82
accept One Last Delivery##11962 |goto 58.22,62.82
step
talk Jeremiah Hawning##26084
turnin Repurposed Technology##12035 |goto 58.19,62.98
step
talk Hilda Stoneforge##25235
|tip She walks around this area.
turnin One Last Delivery##11962 |goto 57.32,66.64
accept Weapons for Farshire##11963 |goto 57.32,66.64
step
talk Broff Bombast##27011
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Broff Bombast##27011 |goto 57.83,66.04 |q 11600
step
Enter the building |goto 58.53,68.35 < 10 |walk
talk Leryssa##25251
|tip Outside on the balcony of the building.
turnin The Late William Allerton##11600 |goto 58.75,68.36
accept Lost and Found##11601 |goto 58.75,68.36
step
talk James Deacon##25245
|tip Inside the building.
turnin Lost and Found##11601 |goto 58.29,68.05
accept In Wine, Truth##11603 |goto 58.29,68.05
step
Leave the building |goto 58.53,68.34 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
Run down the stairs to leave Valiance Keep |goto 57.50,65.79 < 20 |only if walking and subzone("Valiance Keep")
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin Weapons for Farshire##11963 |goto 58.22,62.82
accept Call to Arms!##11965 |goto 58.22,62.82
step
Enter the building |goto 57.29,59.49 < 10 |walk
click Bell Rope##188163
|tip It looks like a huge long rope hanging in this stairwell inside the building.
Ring the Farshire Bell |q 11965/1 |goto 57.32,59.43
step
talk Gerald Green##26083
|tip He walks around this area.
|tip If he's not here, wait for him to respawn.
turnin Call to Arms!##11965 |goto 58.22,62.82
step
talk Arch Druid Lathorius##25809
accept A Mission Statement##11864 |goto 57.05,44.32 |instant
step
talk Arch Druid Lathorius##25809
accept Ears of Our Enemies##11866 |goto 57.05,44.32
accept Help Those That Cannot Help Themselves##11876 |goto 57.05,44.32
step
talk Hierophant Cenius##25810
accept Happy as a Clam##11869 |goto 57.32,44.08
step
talk Zaza##25811
accept Unfit for Death##11865 |goto 56.80,44.03
step
use the Pile of Fake Furs##35127
|tip Use it next to Caribou Traps.
|tip They look like metal spiked traps on the ground around this area.
Trap #8# Nesingwary Trappers |q 11865/1 |goto 56.86,49.77
stickystart "Kill_Lootcrazed_Divers"
step
kill Loot Crazed Diver##25836+
|tip They look like human scuba divers.
|tip You can find them underwater all around the Lake Kum'uya area.
collect 15 Nesingwary Lackey Ear##35188 |q 11866/1 |goto 51.13,44.68
step
label "Kill_Lootcrazed_Divers"
kill 10 Loot Crazed Diver##25836 |q 11869/1 |goto 51.13,44.68
|tip They look like human scuba divers. |notinsticky
|tip You can find them underwater all around the Lake Kum'uya area. |notinsticky
step
Follow the path up to Amber Ledge |goto 49.10,39.12 < 30 |only if walking and not subzone("Amber Ledge")
talk Surristrasz##24795
fpath Amber Ledge |goto 45.33,34.50
step
talk Librarian Donathan##25262
turnin Nick of Time##11575 |goto 45.26,33.35
accept Prison Break##11587 |goto 45.26,33.35
step
talk Librarian Garren##25291
accept Monitoring the Rift: Cleftcliff Anomaly##11576 |goto 44.98,33.38
step
talk Librarian Hamilton##27141
|tip He walks around this area.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Librarian Hamilton##27141 |goto 45.27,33.94 |q 11576
step
talk Etaruk##25292
accept Reclaiming the Quarry##11612 |goto 54.29,36.10
step
click Elder Atkanok##187565
accept The Honored Ancestors##11605 |goto 54.60,36.00
step
use the D.E.H.T.A. Trap Smasher##35228
|tip Use it next to Trapped Mammoth Calves.
|tip They look like baby elephants stuck in metal traps on the ground around this area.
|tip Avoid killing any mammoths, since you'll get a debuff that will cause druid guards to attack you.
Free #8# Mammoth Calves |q 11876/1 |goto 54.72,28.92
You can find more around: |notinsticky
[55.79,32.94]
[56.38,39.08]
step
talk Zaza##25811
turnin Unfit for Death##11865 |goto 56.80,44.04
accept The Culler Cometh##11868 |goto 56.80,44.04
step
talk Arch Druid Lathorius##25809
turnin Ears of Our Enemies##11866 |goto 57.05,44.32
turnin Help Those That Cannot Help Themselves##11876 |goto 57.05,44.32
step
talk Hierophant Cenius##25810
turnin Happy as a Clam##11869 |goto 57.33,44.09
accept The Abandoned Reach##11870 |goto 57.33,44.09
step
kill Karen "I Don't Caribou" the Culler##25803 |q 11868/1 |goto 57.26,56.45
|tip She walks around this area.
|tip Two enemies will appear and help her fight after you attack her.
|tip If you have trouble, try to find someone to help you, or skip the quest.
step
talk Hierophant Liandra##25838
turnin The Abandoned Reach##11870 |goto 57.80,55.11
accept Not On Our Watch##11871 |goto 57.80,55.11
step
kill Northsea Thug##25843+
|tip They look like humans carrying tan bags over their shoulders.
click Shipment of Animal Parts##188018+
|tip They look like brown bags and crates on the ground.
|tip You can find them all around the Abandoned Reach area.
collect 12 Shipment of Animal Parts##35222 |q 11871/1 |goto 59.53,58.66
step
talk Hierophant Liandra##25838
turnin Not On Our Watch##11871 |goto 57.80,55.11
accept The Nefarious Clam Master...##11872 |goto 57.80,55.11
step
kill Clam Master K##25800 |q 11872/1 |goto 61.72,66.42
|tip He walks east and west underwater around this area.
|tip Beware of Great Reef Sharks that will attack while you are fighting him.
|tip He respawns quickly.
step
click Wine Crate##188131
|tip Underwater.
collect Kul Tiras Wine##34714 |q 11603/1 |goto 61.90,65.68
step
Enter the building |goto 58.53,68.35 < 10 |walk
talk Old Man Colburn##25302
|tip Inside the building.
turnin In Wine, Truth##11603 |goto 58.53,68.09
accept A Deserter##11604 |goto 58.53,68.09
step
Leave the building |goto 58.53,68.34 < 10 |walk |only if subzone("Valiance Keep") and _G.IsIndoors()
talk Broff Bombast##27011
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Broff Bombast##27011 |goto 57.83,66.04 |q 11604
step
Enter the courtyard of the building |goto 56.96,70.88 < 15 |only if walking
Run down the stairs |goto 56.85,72.16 < 10 |walk
talk Private Brau##25395
|tip Downstairs inside the building..
turnin A Deserter##11604 |goto 56.68,71.45
accept Cowards and Fools##11932 |goto 56.68,71.45
step
kill Beryl Mage Hunter##25585+
collect Beryl Prison Key##34688 |goto 42.46,37.14 |q 11587
You can find more around [41.81,41.59]
step
click Arcane Prison##187561+
|tip They look like large boxes hovering above circular blue rune platforms around this area.
|tip If the Arcane Prison doesn't complete the quest goal, click others.
|tip It seems random as to which Arcane Prison contains the prisoners.
Rescue the Arcane Prisoners |q 11587/1 |goto 40.44,39.16
You can find more Arcane Prisons at: |notinsticky
[41.79,42.54]
[42.59,36.76]
step
use the Arcanometer##34669
|tip Next to the purple crack in the ground, next to the water.
Take the Cleftcliff Anomaly Reading |q 11576/1 |goto 34.36,42.06
step
Follow the path up |goto 39.96,42.04 < 30 |only if walking and subzone("The Westrift")
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Garren##25291
turnin Monitoring the Rift: Cleftcliff Anomaly##11576 |goto 44.98,33.38
accept Monitoring the Rift: Sundered Chasm##11582 |goto 44.98,33.38
step
talk Librarian Donathan##25262
turnin Prison Break##11587 |goto 45.26,33.35
accept Abduction##11590 |goto 45.26,33.35
step
kill Beryl Sorcerer##25316+
|tip They look like humans in purple robes.
|tip Don't kill them, just weaken them.
|tip You can find them all around the Beryl Point area.
use the Arcane Binder##34691
|tip Use it on the Beryl Sorcerer when it is low health.
Capture a Beryl Sorcerer |q 11590/1 |goto 42.66,38.06
step
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Donathan##25262
turnin Abduction##11590 |goto 45.26,33.35
accept The Borean Inquisition##11646 |goto 45.26,33.35
step
Enter the building |goto 46.11,33.12 < 10 |walk
talk Librarian Normantis##25480
|tip Upstairs inside the tower, on a middle floor.
turnin The Borean Inquisition##11646 |goto 46.33,32.85
accept The Art of Persuasion##11648 |goto 46.33,32.85
step
use the Neural Needler##34811
|tip Use it on the Imprisoned Beryl Sorcerer repeatedly.
|tip Upstairs inside the tower, on a middle floor.
Interrogate the Prisoner |q 11648/1 |goto 46.32,32.92
step
talk Librarian Normantis##25480
|tip Upstairs inside the tower, on a middle floor.
turnin The Art of Persuasion##11648 |goto 46.33,32.85
accept Sharing Intelligence##11663 |goto 46.33,32.85
step
Leave the building |goto 46.11,33.12 < 10 |walk |only if subzone("Amber Ledge") and _G.IsIndoors()
talk Librarian Donathan##25262
turnin Sharing Intelligence##11663 |goto 45.26,33.35
accept A Race Against Time##11671|goto 45.26,33.35
step
talk Librarian Hamilton##27141
|tip He walks around this area.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Librarian Hamilton##27141 |goto 45.27,33.94 |q 11671
step
use the Beryl Shield Detonator##34897
|tip If it won't let you, wait until Inquisitor Salrand appears again.
kill Inquisitor Salrand##25584
click Salrand's Lockbox##187875
|tip It appears on the ground after you kill Inquisitor Salrand.
collect Salrand's Broken Key##34909 |q 11671/1 |goto 41.80,39.16
step
Follow the path up into Amber Ledge |goto 43.72,37.46 < 15 |only if walking and not subzone("Amber Ledge")
talk Librarian Donathan##25262
turnin A Race Against Time##11671 |goto 45.26,33.35
accept Reforging the Key##11679 |goto 45.26,33.35
step
talk Surristrasz##24795
turnin Reforging the Key##11679 |goto 45.32,34.52
accept Taking Wing##11680 |goto 45.32,34.52
step
talk Warmage Anzim##25356
turnin Taking Wing##11680 |goto 46.38,37.31
accept Rescuing Evanor##11681 |goto 46.38,37.31
step
Watch the dialogue
|tip You will automatically be teleported back to Amber Ledge.
Return to Amber Ledge |goto 46.45,32.55 < 20 |noway |c |q 11681
step
talk Archmage Evanor##25785
|tip Inside the tower, on the top floor.
turnin Rescuing Evanor##11681 |goto 46.37,32.40
accept Dragonspeak##11682 |goto 46.37,32.40
step
Leave the building |goto 46.11,33.12 < 10 |walk |only if subzone("Amber Ledge") and _G.IsIndoors()
talk Surristrasz##24795
turnin Dragonspeak##11682 |goto 45.32,34.52
step
use the Arcanometer##34669
|tip Swim down to the pink chasm underwater.
Take the Sundered Chasm Reading |q 11582/1 |goto 43.98,28.49
stickystart "Kill_Beryl_Treasure_Hunters"
step
Follow the path back up to cliff |goto 45.44,31.11 < 15 |only if walking and subzone("The Westrift")
click "Elder Kesuk"##187662
Identify the Elder Kesuk |q 11605/1 |goto 50.87,32.39
step
click "Elder Takret"##187664
Identify the Elder Takret |q 11605/3 |goto 52.31,31.15
step
click "Elder Sagani"##187663
Identify the Elder Sagani |q 11605/2 |goto 52.82,34.03
step
label "Kill_Beryl_Treasure_Hunters"
kill 12 Beryl Treasure Hunter##25353 |q 11612/1 |goto 51.97,32.61
|tip They look like humans in purple robes.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
step
click Elder Atkanok##187565
turnin The Honored Ancestors##11605 |goto 54.62,35.74
accept The Lost Spirits##11607 |goto 54.62,35.74
step
talk Etaruk##25292
turnin Reclaiming the Quarry##11612 |goto 54.29,36.10
accept Hampering Their Escape##11617 |goto 54.29,36.10
stickystart "Free_Kaskala_Craftsman_Spirits"
stickystart "Free_Kaskala_Shaman_Spirits"
step
kill Beryl Reclaimer##25449+
|tip They look like gnomes.
|tip You can find them all around the Coldrock Quarry area.
collect 3 Gnomish Grenade##34772 |q 11617 |goto 51.62,35.90
step
use the Gnomish Grenade##34772
|tip Use it while standing near the floating platform.
Destroy the East Platform |q 11617/1 |goto 52.47,35.44
step
use the Gnomish Grenade##34772
|tip Use it while standing near the the floating platform.
Destroy the West Platform |q 11617/3 |goto 50.35,34.52
step
use the Gnomish Grenade##34772
|tip Use it while standing near the floating platform.
Destroy the North Platform |q 11617/2 |goto 52.26,31.80
step
label "Free_Kaskala_Craftsman_Spirits"
kill Beryl Hound##25355+
|tip They look like blue dogs.
collect Core of Malice##34711+ |n
use the Cores of Malice##34711
|tip Use them on Kaskala Craftsmen.
|tip They look like walrus people spirits holding hammers.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
Free #3# Kaskala Craftsman Spirits |q 11607/1 |goto 51.49,31.33
step
label "Free_Kaskala_Shaman_Spirits"
kill Beryl Hound##25355+
|tip They look like blue dogs.
collect Core of Malice##34711+ |n
use the Cores of Malice##34711
|tip Use them on Kaskala Shamans.
|tip They look like walrus people spirits holding staves.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
Free #3# Kaskala Shaman Spirits |q 11607/2 |goto 51.49,31.33
step
click Elder Atkanok##187565
turnin The Lost Spirits##11607 |goto 54.62,35.74
accept Picking Up the Pieces##11609 |goto 54.62,35.74
step
talk Etaruk##25292
turnin Hampering Their Escape##11617 |goto 54.29,36.10
accept A Visit to the Curator##11623 |goto 54.29,36.10
stickystart "Collect_Tuskarr_Ritual_Objects"
step
kill Curator Insivius##25448 |q 11623/1 |goto 50.09,32.56
|tip He walks around this area.
|tip Follow the path along the top of the cliff to get to him.
step
label "Collect_Tuskarr_Ritual_Objects"
click Tuskarr Ritual Object##187671+
|tip They look like stone fish and incense smoke bowls on the ground.
|tip You can find them all around the Coldrock Quarry area. |notinsticky
collect 6 Tuskarr Ritual Object##34713 |q 11609/1 |goto 51.95,32.94
step
click Elder Atkanok##187565
turnin Picking Up the Pieces##11609 |goto 54.62,35.74
accept Leading the Ancestors Home##11610 |goto 54.62,35.74
step
talk Etaruk##25292
turnin A Visit to the Curator##11623 |goto 54.29,36.10
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Sagani totem.
Complete Elder Sagani's Ceremony |q 11610/2 |goto 52.82,34.04
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Takret totem.
Complete Elder Takret's Ceremony |q 11610/3 |goto 52.31,31.15
step
use the Tuskarr Ritual Object##34715
|tip Next to the Elder Kesuk totem.
Complete Elder Kesuk's Ceremony |q 11610/1 |goto 50.87,32.39
step
click Elder Atkanok##187565
turnin Leading the Ancestors Home##11610 |goto 54.62,35.74
step
talk Zaza##25811
turnin The Culler Cometh##11868 |goto 56.80,44.04
step
talk Arch Druid Lathorius##25809
accept Khu'nok Will Know##11878 |goto 57.05,44.32
step
talk Hierophant Cenius##25810
turnin The Nefarious Clam Master...##11872 |goto 57.33,44.08
step
Deliver the Orphaned Mammoth Calf to Khu'nok |q 11878/1 |goto 59.44,30.37
|tip Make sure the Orphaned Mammoth Calf continues following you.
|tip The calf that follows you is slow.
|tip Don't move too fast, or you'll lose it.
step
talk Khu'nok the Behemoth##25862
turnin Khu'nok Will Know##11878 |goto 59.44,30.37
accept Kaw the Mammoth Destroyer##11879 |goto 59.44,30.37
step
clicknpc Wooly Mammoth Bull##25743
|tip They look like larger brown hairy elephants.
|tip You can find them all around this area.
Ride a Wooly Mammoth Bull |invehicle |goto 55.88,31.39 |q 11879
step
Watch the dialogue
|tip Kaw the Mammoth Destroyer will jump on Moria, the mammoth.
kill Kaw the Mammoth Destroyer##25802
|tip Use the abilities on your action bar.
click Kaw's War Halberd##188066
|tip It looks like an axe that appears on the ground after you kill Kaw the Mammoth Destroyer.
|tip You will have to stop riding the mammoth to be able to loot it.
|tip Click the red arrow on your action bar to stop riding the mammoth.
collect Kaw's War Halberd##35234 |q 11879/1 |goto 53.99,24.29
step
talk Arch Druid Lathorius##25809
turnin Kaw the Mammoth Destroyer##11879 |goto 57.05,44.32
step
talk Ataika##26169
turnin Cowards and Fools##11932 |goto 63.80,46.12
accept The Son of Karkut##12086 |goto 63.80,46.12
accept Not Without a Fight!##11949 |goto 63.80,46.12
step
talk Utaik##26213
accept Preparing for the Worst##11945 |goto 63.95,45.72
|only if subzone("Kaskala")
stickystart "Kill_Kvaldir_Raiders"
step
click Kaskala Supplies+
|tip They look like brown wicker baskets on the ground around this area.
|tip They can also be inside the buildings.
collect 8 Kaskala Supplies##35711 |q 11945 |goto 65.51,47.45
|only if haveq(11945)
step
label "Kill_Kvaldir_Raiders"
kill 12 Kvaldir Raider##25760 |q 11949/1 |goto 67.27,53.03
|tip They look like large green humans.
|tip You can find them all around the Kaskala area. |notinsticky
You can find more around [67.51,47.93]
step
talk Ataika##26169
turnin Not Without a Fight!##11949 |goto 63.80,46.12
accept Muahit's Wisdom##11950 |goto 63.80,46.12
step
talk Utaik##26213
turnin Preparing for the Worst##11945 |goto 63.95,45.72
|only if haveq(11945) or completedq(11945)
step
talk Elder Muahit##26218
turnin Muahit's Wisdom##11950 |goto 67.20,54.85
accept Spirits Watch Over Us##11961 |goto 67.20,54.85
step
clicknpc Iruk##26219
|tip Underwater.
Choose _<Search corpse for Issliruk's Totem.>_
collect Issliruk's Totem##35701 |q 11961/1 |goto 67.64,50.41
step
talk Elder Muahit##26218
turnin Spirits Watch Over Us##11961 |goto 67.20,54.85
accept The Tides Turn##11968 |goto 67.20,54.85
step
kill Heigarr the Horrible##26266 |q 11968/1 |goto 67.60,56.70
|tip He fights around this area.
step
talk Elder Muahit##26218
turnin The Tides Turn##11968 |goto 67.20,54.85
step
Enter the building |goto 78.00,52.04 < 10 |walk
talk Tonraq##27188
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Tonraq##27188 |goto 77.91,52.20 |q 12086
step
talk Bilko Driftspark##28195
fpath Unu'pe |goto 78.53,51.53
step
talk Corporal Venn##26187
turnin The Son of Karkut##12086 |goto 82.01,46.42
accept Surrounded!##11944 |goto 82.01,46.42
step
kill 7 Ziggurat Defender##26202 |q 11944/1 |goto 82.66,43.11
step
talk Corporal Venn##26187
turnin Surrounded!##11944 |goto 82.01,46.42
accept Thassarian, the Death Knight##12088 |goto 82.01,46.42
step
Run up the stairs and enter the building |goto 84.68,40.93 < 15 |walk
talk Thassarian##26170
|tip Inside the building.
turnin Thassarian, the Death Knight##12088 |goto 84.79,41.67
accept Finding the Phylactery##11956 |goto 84.79,41.67
step
click Frozen Phylactery##188141
|tip Underwater.
|tip You will be attacked.
kill Phylactery Guardian##26225+
collect Tanathal's Phylactery##35687 |q 11956/1 |goto 85.40,33.34
step
Run up the stairs and enter the building |goto 84.68,40.93 < 15 |walk
talk Thassarian##26170
|tip Inside the building.
turnin Finding the Phylactery##11956 |goto 84.79,41.67
accept Buying Some Time##11938 |goto 84.79,41.67
step
Enter the Temple City of En'kilah |goto 84.27,30.78 < 30 |only if walking and not subzone("Temple City of En'kilah")
Kill En'kilah enemies around this area
|tip You can find them all around the Temple City of En'kilah area. |notinsticky
Slay #20# En'kilah Casualties |q 11938/1 |goto 85.73,27.33
step
Follow the path to leave the Temple City of En'kilah |goto 85.07,28.76 < 40 |only if walking and (subzone("Temple City of En'kilah") or subzone("Spire of Pain") or subzone("Spire of Blood") or subzone("Spire of Decay"))
Run up the stairs and enter the building |goto 84.68,40.93 < 15 |walk
talk Thassarian##26170
|tip Inside the building.
turnin Buying Some Time##11938 |goto 84.79,41.67
accept Words of Power##11942 |goto 84.79,41.67
step
Enter the Temple City of En'kilah |goto 84.27,30.78 < 30 |only if walking and not subzone("Temple City of En'kilah")
Run up the stairs and enter the building |goto 88.64,28.33 < 15 |walk
kill High Priest Talet-Kha##26073
|tip Inside the building.
|tip You must kill the 2 cocoons next to him before you can attack him.
collect High Priest Talet-Kha's Scroll##35354 |q 11942/3 |goto 89.43,28.89
step
Run up the stairs |goto 89.02,26.70 < 30 |only if walking and subzone("Spire of Pain")
Run up the stairs |goto 87.54,22.36 < 30 |only if walking and not subzone("Spire of Blood")
Run up the stairs and enter the building |goto 88.56,21.31 < 15 |walk
kill High Priest Andorath##25392
|tip Upstairs inside the building.
collect High Priest Andorath's Scroll##35355 |q 11942/1 |goto 88.06,20.94
step
Enter the building |goto 84.24,21.82 < 15 |walk
kill High Priest Naferset##26076
|tip Inside the building.
|tip You must kill the 3 enemies channeling on him before you can attack him.
collect High Priest Naferset's Scroll##35353 |q 11942/2 |goto 83.88,20.46
step
Follow the path to leave the Temple City of En'kilah |goto 85.07,28.76 < 40 |only if walking and (subzone("Temple City of En'kilah") or subzone("Spire of Pain") or subzone("Spire of Blood") or subzone("Spire of Decay"))
Run up the stairs and enter the building |goto 84.68,40.93 < 15 |walk
talk Thassarian##26170
|tip Inside the building.
turnin Words of Power##11942 |goto 84.79,41.67
step
talk Librarian Garren##25291
turnin Monitoring the Rift: Sundered Chasm##11582 |goto Borean Tundra 44.98,33.38
accept Monitoring the Rift: Winterfin Cavern##12728 |goto Borean Tundra 44.98,33.38
step
talk Surristrasz##24795
accept Traversing the Rift##11733 |goto 45.32,34.52
step
talk Surristrasz##24795
Ask him _"May I use a drake to fly elsewhere?"_
|tip Choose to fly to "Transitus Shield, Coldarra".
Begin Flying to Transitus Shield |ontaxi |goto 45.32,34.52 |q 11733
step
Fly to Transitus Shield |offtaxi |goto 33.12,34.41 |notravel |q 11733
step
talk Warmage Adami##27046
fpath Transitus Shield |goto 33.13,34.44
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Traversing the Rift##11733 |goto 32.95,34.40
accept Reading the Meters##11900 |goto 32.95,34.40
accept Secrets of the Ancients##11910 |goto 32.95,34.40
step
talk Raelorasz##26117
accept Basic Training##11918 |goto 33.31,34.53
step
talk Librarian Serrah##26110
accept Nuts for Berries##11912 |goto 33.49,34.38
stickystart "Kill_Coldarra_Spellweavers"
step
kill Coldarra Spellbinder##25719+
|tip They look like large humans wearing purple robs.
collect Scintillating Fragment##35648 |n
use the Scintillating Fragment##35648
accept Puzzling...##11941 |goto 32.92,28.99
step
talk Raelorasz##26117
turnin Puzzling...##11941 |goto 33.31,34.53
accept The Cell##11943 |goto 33.31,34.53
stickystart "Collect_Glacial_Splinters"
stickystart "Collect_Magic_Bound_Splinters"
stickystart "Collect_Frostberries"
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Southern Coldarra Reading |q 11900/2 |goto 28.27,35.02
step
kill Warbringer Goredrak##25712
|tip He looks like a large blue humanoid dragon in brown armor.
collect Energy Core##35669 |q 11943/1 |goto 24.13,29.59
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 21.62,26.80 |q 11912
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Western Coldarra Reading |q 11900/4 |goto 22.62,23.45
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 23.86,21.70 |q 11912
step
_NOTE:_
Check for Frostberry Bushes
|tip There are usually a few Frostberry bushes around this area with the trees.
|tip They look like medium sized snow covered bushes with dark leaves on the ground around this area.
|tip Collect the few you can find here, and continue on.
Click Here to Continue |confirm |goto 25.41,19.93 |q 11912
step
kill General Cerulean##25716
|tip He looks like a large blue and white dragon.
collect Prison Casing##35668 |q 11943/2 |goto 27.32,20.40
step
label "Collect_Frostberries"
click Frostberry Bush##188113+
|tip They look like medium sized snow covered bushes with dark leaves on the ground.
|tip You should be able to finish up with these here. |notinsticky
|tip You can find them all around the Coldarra area. |notinsticky
collect 10 Frostberry##35492 |q 11912/1 |goto 29.53,20.54
step
click Coldarra Geological Monitor##188100
|tip Right inside the doorway of the building.
Take the Northern Coldarra Reading |q 11900/3 |goto 31.72,20.56
step
label "Collect_Glacial_Splinters"
kill Glacial Ancient##25709+
|tip They look like large white and brown walking trees.
|tip You can find them all around the Coldarra area. |notinsticky
collect 3 Glacial Splinter##35483 |q 11910/1 |goto 34.13,25.70
step
label "Collect_Magic_Bound_Splinters"
kill Magic-Bound Ancient##25707+
|tip They look like large purple and white walking trees.
|tip You can find them all around the Coldarra area. |notinsticky
collect 3 Magic-Bound Splinter##35484 |q 11910/2 |goto 34.13,25.70
step
label "Kill_Coldarra_Spellweavers"
kill 10 Coldarra Spellweaver##25722 |q 11918/1 |goto 31.45,29.44
|tip You can find them all around the Coldarra area. |notinsticky
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Secrets of the Ancients##11910 |goto 32.95,34.40
step
talk Archmage Berinand##25314
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Archmage Berinand##25314 |goto 32.97,34.38 |q 11918
step
talk Raelorasz##26117
turnin Basic Training##11918 |goto 33.31,34.53
accept Hatching a Plan##11936 |goto 33.31,34.53
step
talk Raelorasz##26117
turnin The Cell##11943 |goto 33.31,34.53
step
talk Librarian Serrah##26110
turnin Nuts for Berries##11912 |goto 33.49,34.38
accept Keep the Secret Safe##11914 |goto 33.49,34.38
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26206
|tip She appears next to you.
accept Keristrasza##11946 |goto 33.20,34.19
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26206
|tip She appears next to you.
turnin Keristrasza##11946
accept Bait and Switch##11951 |goto 33.20,34.19
stickystart "Collect_Crystallized_Mana_Shards"
step
kill Coldarra Wyrmkin##25728+
|tip They look like larger armored blue dragonkin.
|tip You can find them all around the Coldarra area. |notinsticky
|tip You need these axes to destroy dragon eggs in a few steps.
collect 5 Frozen Axe##35586 |goto 29.57,30.52 |q 11936
You can find more around: |notinsticky
[25.27,35.16]
[24.14,25.21]
step
label "Collect_Crystallized_Mana_Shards"
click Crystallized Mana##188140+
|tip They look like clusters of pink crystals on the ground.
|tip They are usually near the 3 purple cracks in the ground around the perimeter of the large trench surrounding the Nexus building.
|tip You can find them all around the Coldarra area. |notinsticky
collect 10 Crystallized Mana Shard##35685 |q 11951/1 |goto 24.64,24.34
You can find more around: |notinsticky
[29.93,22.39]
[29.12,31.77]
stickystart "Destroy_Dragon_Eggs"
stickystart "Collect_Nexus_Mana_Essences"
step
click Coldarra Geological Monitor##188100
|tip On the ground in the trench, outside of the Nexus building.
Take the Nexus Geological Reading |q 11900/1 |goto 28.32,28.48
step
label "Destroy_Dragon_Eggs"
click Blue Dragon Egg##188133+
|tip They look like large dark colored eggs with white crystals on them on the ground around this area.
|tip In the trench, all around the perimeter of the Nexus building. |notinsticky
Destroy #5# Dragon Eggs |q 11936/1 |goto 28.08,29.18
step
label "Collect_Nexus_Mana_Essences"
kill Arcane Serpent##25721+
|tip They look like pink flying snakes in the air.
|tip In the trench, all around the perimeter of the Nexus building. |notinsticky
collect 5 Nexus Mana Essence##35493 |q 11914/1 |goto 27.95,24.20
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26237
|tip She appears next to you.
turnin Bait and Switch##11951
accept Saragosa's End##11957
step
_Next to you:_
talk Keristrasza##26237
Tell her _"I am prepared to face Saragosa!"_
Teleport to Saragosa's Landing |complete subzone("Saragosa's Landing") |q 11957
step
use the Arcane Power Focus##35690
|tip In the middle of the floating platform.
Watch the dialogue
kill Saragosa##26232
|tip She will fly to the floating platform, and turn into her non-elite human form.
|tip You won't have to fight her elite dragon form.
collect Saragosa's Corpse##35709 |q 11957/1 |goto 21.59,22.55
step
use the Augmented Arcane Prison##35671
talk Keristrasza##26237
|tip She appears next to you.
turnin Saragosa's End##11957
accept Mustering the Reds##11967
step
_Next to you:_
talk Keristrasza##26237
Tell her _"Keristrasa, I am finished here. Please return me to the Transitus Shield."_
Return to Transitus Shield |complete subzone("Transitus Shield") |q 11967
step
talk Raelorasz##26117
turnin Hatching a Plan##11936 |goto 33.31,34.53
turnin Mustering the Reds##11967 |goto 33.31,34.53
step
talk Librarian Serrah##26110
turnin Keep the Secret Safe##11914 |goto 33.49,34.38
step
talk Archmage Berinand##25314
|tip Inside the building.
turnin Reading the Meters##11900 |goto 32.95,34.40
step
talk Archmage Berinand##25314
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Archmage Berinand##25314 |goto 32.97,34.38 |q 11707
step
talk Kara Thricestar##26602
fpath Fizzcrank Airstrip |goto Borean Tundra 56.58,20.06
step
Enter the building |goto 57.06,19.02 < 10 |walk
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
turnin Distress Call##11707 |goto 56.98,18.70
accept The Mechagnomes##11708 |goto 56.98,18.70
step
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
Tell him _"Tell me what's going on out here, Fizzcrank."_
Listen to Fizzcrank's Tale |q 11708/1 |goto 56.98,18.70
step
talk Jinky Wingnut##25747
turnin The Mechagnomes##11708 |goto 57.44,18.74
accept Re-Cursive##11712 |goto 57.44,18.74
step
talk Mordle Cogspinner##25702
accept What's the Matter with the Transmatter?##11710 |goto 57.51,18.61
accept King Mrgl-Mrgl##11704 |goto 57.51,18.61
step
talk Crafty Wobblesprocket##25477
|tip She walks around this area.
accept Dirty, Stinkin' Snobolds!##11645 |goto 57.93,18.80
stickystart "Collect_Craftys_Stuff"
step
Enter the cave |goto 54.01,13.48 < 30 |walk
Jump down carefully into the water here |goto 54.80,12.34 < 10 |walk
talk Bonker Togglevolt##25589
|tip Downstairs inside the cave.
accept Get Me Outa Here!##11673 |goto 55.57,12.57
step
Watch the dialogue
|tip Follow Bonker Togglevolt and protect him as he walks.
|tip Let him get attacked first, otherwise he won't stop to help you fight.
|tip He eventually walks to this location outside of the cave.
Escort Bonker Togglevolt to Safety |q 11673/1 |goto 53.83,13.82
step
label "Collect_Craftys_Stuff"
click Crafty's Stuff##187689+
|tip They look like brown wooden crates on the ground around this area.
collect 10 Crafty's Stuff##34787 |q 11645/1 |goto 53.70,14.20
You can find more around: |notinsticky
[55.57,15.61]
[56.77,13.91]
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 11645
step
Enter the building |goto 57.06,19.02 < 10 |walk
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
turnin Get Me Outa Here!##11673 |goto 56.98,18.71
step
talk Crafty Wobblesprocket##25477
|tip She walks around this area.
turnin Dirty, Stinkin' Snobolds!##11645 |goto 57.72,18.97
stickystart "Accept_The_Ultrasonic_Screwdriver"
stickystart "Collect_Fizzcrank_Spare_Parts"
step
kill Fizzcrank Mechagnome##25814+
use the Re-Cursive Transmatter Injection##34973
|tip Use it on their corpses.
Curse & Port #6# Fizzcrank Gnomes |q 11712/1 |goto 59.19,18.11
You can find more around: |notinsticky
[61.38,16.49]
[64.51,18.14]
[62.48,22.04]
[60.07,20.36]
step
label "Collect_Fizzcrank_Spare_Parts"
click Fizzcrank Spare Parts##187901+
|tip They look like various shaped grey metal objects on the ground around this area.
|tip You can find them all around in the Scalding Pools area.
collect 15 Fizzcrank Spare Parts##34972 |q 11710/1 |goto 61.78,21.75
step
label "Accept_The_Ultrasonic_Screwdriver"
Kill enemies around this area
collect The Ultrasonic Screwdriver##34984 |n
use The Ultrasonic Screwdriver##34984
accept The Ultrasonic Screwdriver##11729 |goto 61.78,21.75
step
talk Crafty Wobblesprocket##25477
|tip She walks around this area.
turnin The Ultrasonic Screwdriver##11729 |goto 57.63,18.99
accept Master and Servant##11730 |goto 57.63,18.99
step
talk Mordle Cogspinner##25702
turnin What's the Matter with the Transmatter?##11710 |goto 57.52,18.61
accept Check in With Bixie##11692 |goto 57.52,18.61
step
talk Jinky Wingnut##25747
turnin Re-Cursive##11712 |goto 57.44,18.74
accept Lefty Loosey, Righty Tighty##11788 |goto 57.44,18.74
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 11788
step
Enter the building |goto 57.06,19.02 < 10 |walk
talk "Charlie" Northtop##26596
|tip Inside the building.
home Fizzcrank Airstrip |goto 57.12,18.72
stickystart "Reprogram_Robots"
step
click West Point Station Valve##188106
kill Twonky##25830 |q 11788/1 |goto 60.23,20.39
step
click North Point Station Valve##188107
kill ED-210##25831 |q 11788/2 |goto 65.41,17.51
step
click Mid Point Station Valve##188108
kill Max Blasto##25832 |q 11788/3 |goto 63.68,22.50
step
click South Point Station Valve##188109
kill The Grinder##25833 |q 11788/4 |goto 65.25,28.78
step
label "Reprogram_Robots"
Kill enemies around this area
|tip Only the robot type enemies will work with the quest item.
|tip You can find them all around in the Scalding Pools area.
use The Ultrasonic Screwdriver##35116
|tip Use it on their corpses.
Reprogram #15# Robots |q 11730/1 |goto 67.29,26.36
step
talk Bixie Wrenchshanker##25705
turnin Check in With Bixie##11692 |goto 73.42,18.79
accept Oh Great... Plagued Magnataur!##11693 |goto 73.42,18.79
step
kill 10 Plagued Magnataur##25615 |q 11693/1 |goto 75.96,21.60
|tip They look like large blue centaurs.
step
talk Bixie Wrenchshanker##25705
turnin Oh Great... Plagued Magnataur!##11693 |goto 73.42,18.79
accept There's Something Going On In Those Caves##11694 |goto 73.42,18.79
step
Enter the cave |goto 74.42,14.88 < 20 |walk
use Bixie's Inhibiting Powder##34915
|tip Inside the small cave.
Neutralize the Plague Cauldron |q 11694/1 |goto 74.75,14.15
step
talk Bixie Wrenchshanker##25705
turnin There's Something Going On In Those Caves##11694 |goto 73.42,18.79
accept Rats, Tinky Went into the Necropolis!##11697 |goto 73.42,18.79
accept Might As Well Wipe Out the Scourge##11698 |goto 73.42,18.79
stickystart "Destroy_Talramas_Scourge"
step
Enter the building |goto 68.62,15.26 < 40 |walk
talk Tinky Wickwhistle##25714
|tip Inside the building.
turnin Rats, Tinky Went into the Necropolis!##11697 |goto 69.90,14.74
accept I'm Stuck in this Damned Cage... But Not For Long!##11699 |goto 69.90,14.74
stickystart "Collect_Engine_Core_Crystal"
step
Follow the winding path up to the very top of the building |goto 69.51,15.82 < 10 |only if walking
kill Lich-Lord Chillwinter##25682
|tip He walks around this area.
|tip On top of the building.
collect Piloting Scourgestone##34959 |q 11699/3 |goto 70.13,13.40
step
kill Doctor Razorgrin##25678
|tip He walks around this area inside the building.
|tip Jump down to him from on top of the building.
collect Magical Gyroscope##34958 |q 11699/2 |goto 69.70,12.87
step
label "Collect_Engine_Core_Crystal"
kill Festering Ghoul##25660+
collect Engine-Core Crystal##34957 |q 11699/1 |goto 68.24,19.13
step
Enter the building |goto 68.62,15.26 < 40 |walk
talk Tinky Wickwhistle##25714
|tip Inside the building.
turnin I'm Stuck in this Damned Cage... But Not For Long!##11699 |goto 69.90,14.74
accept Let Bixie Know##11700 |goto 69.90,14.74
step
label "Destroy_Talramas_Scourge"
Kill enemies around this area
Destroy #20# Talramas Scourge |q 11698/1 |goto 68.24,19.13
step
talk Bixie Wrenchshanker##25705
turnin Let Bixie Know##11700 |goto 73.42,18.79
turnin Might As Well Wipe Out the Scourge##11698 |goto 73.42,18.79
accept Back to the Airstrip##11701 |goto 73.42,18.79
step
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
turnin Back to the Airstrip##11701 |goto 56.98,18.71
accept Finding Pilot Tailspin##11725 |goto 56.98,18.71
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 11788
step
talk Jinky Wingnut##25747
turnin Lefty Loosey, Righty Tighty##11788 |goto 57.44,18.74
accept The Gearmaster##11798 |goto 57.44,18.74
step
talk Crafty Wobblesprocket##25477
|tip She walks around this area.
turnin Master and Servant##11730 |goto 57.62,19.05
step
talk Iggy "Tailspin" Cogtoggle##25807
turnin Finding Pilot Tailspin##11725 |goto 61.68,35.78
accept A Little Bit of Spice##11726 |goto 61.68,35.78
step
Kill Gorloc enemies around this area
collect 4 Gorloc Spice Pouch##34983 |q 11726/1 |goto 64.90,40.82
You can find more around [67.86,41.03]
step
talk Iggy "Tailspin" Cogtoggle##25807
turnin A Little Bit of Spice##11726 |goto 61.68,35.78
accept Lupus Pupus##11728 |goto 61.68,35.78
step
use the Wolf Bait##35121
|tip Use it on Oil-stained Wolves.
|tip They look like black wolves around this area.
click Wolf Droppings##187981+
|tip They look like small piles of poop that appear on the ground after the wolves eat the bait.
collect 8 Microfilm##35123 |q 11728/1 |goto 61.77,35.87
You can find more around: |notinsticky
[63.34,37.16]
[60.71,33.87]
[59.98,39.85]
step
talk Iggy "Tailspin" Cogtoggle##25807
turnin Lupus Pupus##11728 |goto 61.68,35.78
accept Emergency Protocol: Section 8.2, Paragraph C##11795 |goto 61.68,35.78
step
clicknpc Fizzcrank Recon Pilot##25841+
|tip They look like dead gnomes in black clothing laying on the ground.
|tip They are usually on the white parts of the ground next to water.
|tip You can find them all around the Scalding Pools area.
Choose _"Search for the pilot's insignia."_
collect 6 Fizzcrank Pilot's Insignia##35126 |q 11795/1 |goto 62.98,35.75
You can find more around: |notinsticky
[62.39,38.87]
[60.56,36.41]
step
talk Iggy "Tailspin" Cogtoggle##25807
turnin Emergency Protocol: Section 8.2, Paragraph C##11795 |goto 61.68,35.78
accept Emergency Protocol: Section 8.2, Paragraph D##11796 |goto 61.68,35.78
step
use the Emergency Torch##35224
Scuttle the Eastern Wreck |q 11796/1 |goto 63.32,37.02
step
use the Emergency Torch##35224
Scuttle a Southern Wreck |q 11796/2 |goto 61.08,40.08
step
use the Emergency Torch##35224
Scuttle a Northwestern Wreck |q 11796/3 |goto 60.86,33.61
step
talk Iggy "Tailspin" Cogtoggle##25807
turnin Emergency Protocol: Section 8.2, Paragraph D##11796 |goto 61.68,35.78
accept Give Fizzcrank the News##11873 |goto 61.68,35.78
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 11798
step
Enter the building |goto 57.06,19.02 < 10 |walk
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
turnin Give Fizzcrank the News##11873 |goto 56.98,18.71
step
talk Abner Fizzletorque##25780
accept Scouting the Sinkholes##11713 |goto 57.06,20.11
step
Run up the ramp and follow the path to the top of the platform |goto 65.55,23.03 < 15 |only if walking
Enter the building at the top of the platform |goto 64.59,23.15 < 10 |walk
click The Gearmaster's Manual##190335
|tip Inside the building at the top of the platform.
|tip Gearmaster Mechazod will appear and attack you after you click the book.
Research the Gearmaster's Manual |q 11798/1 |goto 64.53,23.40
step
Watch the dialogue
|tip Inside the building at the top of the platform.
kill Gearmaster Mechazod##25834
collect Mechazod's Head##35486 |q 11798/2 |goto 64.53,23.40
step
use the Map of the Geyser Fields##34920
Mark the Location of the Northwest Sinkhole |q 11713/3 |goto 66.41,32.01
step
use the Map of the Geyser Fields##34920
Mark the Location of the Northeast Sinkhole |q 11713/2 |goto 69.50,32.79
step
use the Map of the Geyser Fields##34920
Mark the Location of the South Sinkhole |q 11713/1 |goto 70.21,36.41
step
talk Fizzcrank Fullthrottle##25590
|tip Upstairs inside the building.
turnin The Gearmaster##11798 |goto 56.98,18.71
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 11713
step
talk Abner Fizzletorque##25780
turnin Scouting the Sinkholes##11713 |goto 57.06,20.11
accept Fueling the Project##11715 |goto 57.06,20.11
step
use the Portable Oil Collector##34975
|tip Use it next to the black oil spots on the ground in the water around this area.
Collect #8# Barrels of Oil |q 11715/1 |goto 57.60,25.19
You can find more around: |notinsticky
[59.68,24.72]
[61.11,28.65]
step
talk Abner Fizzletorque##25780
turnin Fueling the Project##11715 |goto 57.06,20.11
accept A Bot in Mammoth's Clothing##11718 |goto 57.06,20.11
step
Kill Mammoth enemies around this area
collect 6 Thick Mammoth Hide##34977 |q 11718/1 |goto 53.68,21.21
You can find more around [54.84,28.78]
step
talk Abner Fizzletorque##25780
turnin A Bot in Mammoth's Clothing##11718 |goto 57.06,20.11
step
talk Willis Wobblewheel##26599
|tip He walks around this area.
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Willis Wobblewheel##26599 |goto 57.04,19.82 |q 12728
step
talk King Mrgl-Mrgl##25197
turnin King Mrgl-Mrgl##11704 |goto 43.50,13.97
accept Learning to Communicate##11571 |goto 43.50,13.97
stickystart "Collect_Winterfin_Clams"
step
kill Scalder##25226
|tip He looks like a blue water elemental that swims along this purple trench underwater around this area.
use The King's Empty Conch##34598
|tip Use it on his corpse.
collect The King's Filled Conch##34623 |q 11571/1 |goto 42.78,17.07
step
label "Collect_Winterfin_Clams"
Kill Winterfin enemies around this area
|tip They look like murlocs.
click Winterfin Clam##187367+
|tip They look like small grey clams on the ground around this area.
collect 5 Winterfin Clam##34597 |goto 40.61,16.85 |q 11559 |future
|tip Be careful not to accidentally sell these to a vendor.
|tip You will need them for a quest soon.
step
talk King Mrgl-Mrgl##25197
turnin Learning to Communicate##11571 |goto 43.50,13.97
accept Winterfin Commerce##11559 |goto 43.50,13.97
step
talk Ahlurglgr##25206
turnin Winterfin Commerce##11559 |goto 43.04,13.81
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11560 |future
step
talk King Mrgl-Mrgl##25197
accept Oh Noes, the Tadpoles!##11560 |goto 43.50,13.97
step
talk Brglmurgl##25199
accept Them!##11561 |goto 42.83,13.65
stickystart "Rescue_Winterfin_Tadpoles"
stickystart "Slay_Winterfin_Murlocs"
step
use the Arcanometer##34669
|tip At the entrance of the cave.
Take the Winterfin Cavern Reading |q 12728/1 |goto 39.88,19.76
step
label "Rescue_Winterfin_Tadpoles"
click Cage##238791+
|tip They look like yellow wooden cages on the ground around this area.
Rescue #20# Winterfin Tadpoles |q 11560/1 |goto 40.61,16.85
You can find more inside the cave at [39.88,19.76]
step
label "Slay_Winterfin_Murlocs"
Kill Winterfin enemies around this area
Slay #15# Winterfin Murlocs |q 11561/1 |goto 40.61,16.85
You can find more inside the cave at [39.88,19.76]
step
Leave the cave |goto 39.92,19.98 < 40 |walk |only if subzone("Winterfin Caverns")
talk Brglmurgl##25199
turnin Them!##11561 |goto 42.83,13.65
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11560
step
talk King Mrgl-Mrgl##25197
turnin Oh Noes, the Tadpoles!##11560 |goto 43.50,13.97
accept I'm Being Blackmailed By My Cleaner##11562 |goto 43.50,13.97
step
talk Mrmrglmr##25205
turnin I'm Being Blackmailed By My Cleaner##11562 |goto 42.00,12.77
accept Grmmurggll Mrllggrl Glrggl!!!##11563 |goto 42.00,12.77
step
talk Cleaver Bmurglbrm##25211
accept Succulent Orca Stew##11564 |goto 42.03,13.15
stickystart "Collect_Succulent_Orca_Blubber"
step
kill Glrggl##25203
|tip It looks like a larger orca that swims on the surface of the water around this area.
collect Glrggl's Head##34617 |q 11563/1 |goto 36.47,8.23
step
label "Collect_Succulent_Orca_Blubber"
kill Glimmer Bay Orca##25204+
|tip Underwater around this area.
collect 7 Succulent Orca Blubber##34618 |q 11564/1 |goto 39.94,12.37
You can find more around: |notinsticky
[40.74,7.39]
[42.70,15.83]
step
talk Mrmrglmr##25205
turnin Grmmurggll Mrllggrl Glrggl!!!##11563 |goto 42.00,12.77
accept The Spare Suit##11565 |goto 42.00,12.77
step
talk Cleaver Bmurglbrm##25211
turnin Succulent Orca Stew##11564 |goto 42.03,13.15
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto Borean Tundra/0 43.04,13.81 |q 11565
step
talk King Mrgl-Mrgl##25197
turnin The Spare Suit##11565 |goto 43.50,13.97
accept Surrender... Not!##11566 |goto 43.50,13.97
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |goto 40.33,19.21 |q 11566
step
Enter the cave |goto 39.92,19.97 < 40 |walk
Follow the path |goto 38.06,22.72 < 10 |walk
talk Glrglrglr##28375
|tip Inside the cave, on the top floor.
accept Keymaster Urmgrgl##11569 |goto 37.84,23.19
step
Remove King Mrgl-Mrgl's Spare Suit |nobuff spell:45278 |q 11566
|tip Right-click the "King Mrgl-Mrgl's Spare Suit" buff near your minimap.
|tip Be careful, enemies will attack you.
step
Jump down and follow the path |goto 38.10,22.16 < 10 |walk
kill Keymaster Urmgrgl##25210
|tip He walks around this area.
|tip Inside the cave, on the bottom floor.
collect Urmgrgl's Key##34600 |q 11569/1 |goto 39.07,22.69
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |q 11566
step
Follow the path |goto 37.50,21.87 < 10 |walk
kill Claximus##25209
|tip Inside the cave, on the top floor.
|tip To reach him, hug the right wall as you follow the path.
collect Claw of Claximus##34621 |q 11566/1 |goto 37.55,27.51
step
use King Mrgl-Mrgl's Spare Suit##34620
Wear King Mrgl-Mrgl's Spare Suit |havebuff spell:45278 |q 11566
step
Hug the left wall as you walk and follow the path up |goto 37.49,21.57 < 10 |walk
Follow the path |goto 38.06,22.72 < 10 |walk
talk Glrglrglr##28375
|tip Inside the cave, on the top floor.
turnin Keymaster Urmgrgl##11569 |goto 37.84,23.19
step
Remove King Mrgl-Mrgl's Spare Suit |nobuff spell:45278 |goto 37.75,23.02 |q 11570 |future
|tip Right-click the "King Mrgl-Mrgl's Spare Suit" buff near your minimap.
|tip Be careful, enemies will attack you.
step
talk Lurgglbr##25208
|tip Inside the cave, on the top floor.
accept Escape from the Winterfin Caverns##11570 |goto 37.75,23.02
step
Escort Lurgglbr to Safety |q 11570/1 |goto 41.34,16.34
|tip Follow Lurgglbr and protect him as he walks.
|tip Let him get attacked first, otherwise he won't stop to help you fight.
|tip He eventually walks to this location outside the cave.
step
talk Ahlurglgr##25206
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Ahlurglgr##25206 |goto 43.04,13.81 |q 11570
step
talk King Mrgl-Mrgl##25197
turnin Surrender... Not!##11566 |goto 43.50,13.97
turnin Escape from the Winterfin Caverns##11570 |goto 43.50,13.97
step
use the Hearthstone##6948
Hearth to Fizzcrank Airstrip |goto 57.09,18.74 < 30 |noway |c |q 11723 |future
|only if subzone("Winterfin Retreat")
step
talk Librarian Garren##25291
turnin Monitoring the Rift: Winterfin Cavern##12728 |goto 44.98,33.38
step
talk Abner Fizzletorque##25780
accept Deploy the Shake-n-Quake!##11723 |goto 57.06,20.11
step
use the Shake-n-Quake 5000 Control Unit##34981
Watch the dialogue
|tip Lord Kryxix will appear nearby.
Deploy the Shake-n-Quake 5000 |q 11723/2 |goto 70.20,36.41
step
kill Lord Kryxix##25629 |q 11723/1 |goto 70.36,37.56
|tip He looks like a huge blue beetle that walks around this area.
step
talk Abner Fizzletorque##25780
turnin Deploy the Shake-n-Quake!##11723 |goto 57.06,20.11
step
talk Private Casey##26186
accept The Lost Courier##12157 |goto 82.16,46.40
step
talk Courier Lanson##27060
|tip Inside the tent.
turnin The Lost Courier##12157 |goto Dragonblight 28.83,56.17
step
talk Sentinel Amberline##27055
|tip Repair your items.
|tip Sell any items you don't need, to clear some bag space.
Visit the Vendor |vendor Sentinel Amberline##27055 |goto 29.03,55.09 |q 11733 |future
step
talk Palena Silvercloud##26881
fpath Stars' Rest |goto 29.18,55.33
]])
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Dragonblight (71-73)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Grizzly Hills (73-74)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Zul'Drak (74-76)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Sholazar Basin (76-77)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\The Storm Peaks (77-78)")
ZygorGuidesViewer:RegisterGuidePlaceholder("Leveling Guides\\Northrend (69-80)\\Icecrown (78-80)")
