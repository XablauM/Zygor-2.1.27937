local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if ZGV:DoMutex("DailiesCLEGION") then return end
ZygorGuidesViewer.GuideMenuTier = "TRI"
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Ogri'la\\Ogri'la Daily Quests")
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Daily Quests")
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Sha'tari Skyguard\\Sha'tari Skyguard Terokk Farming")
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Shattrath Cooking Dailies")
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Netherwing\\Netherwing Daily Quests")
ZygorGuidesViewer:RegisterGuidePlaceholder("Dailies Guides\\The Burning Crusade\\Netherwing\\Netherwing Eggs")
